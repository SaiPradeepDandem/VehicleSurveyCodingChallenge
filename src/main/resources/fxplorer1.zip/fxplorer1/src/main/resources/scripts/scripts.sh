#!/bin/sh
JENKINS_IP="<update_jenkins_ip_address_here>"
JAR_DIR=fxjar

function runFxplorer() {
  echo "Deploying Fxplorer..."
  deployJar $@
  
  export DISPLAY=:0.0
  FXPLORER_JAR=$JAR_DIR/fxplorer.jar
  JAVAFX_LIB=$JAVAFX_SDK/lib
  $JAVA_HOME/bin/java --module-path $JAVAFX_LIB:$FXPLORER_JAR --add-modules=javafx.controls,javafx.fxml,javafx.swing,jdk.attach,java.instrument,com.sai.javafx.fxplorer --module com.sai.javafx.fxplorer/com.sai.javafx.fxplorer.app.Fxplorer
}

function deployJar(){
  BRANCH=$1
  BUILD_NUMBER=$2
  ARTIFACT=fxplorer/build/libs/fxplorer.jar
  JENKINS_BUILD=1skyr1%252Ffeature%252F$BRANCH

  if [[ $BRANCH = 'main' ]]; then
    JENKINS_BUILD=1skyr1%252Fmain
    echo 'main branch'
  else
    echo "Feature branch : $JENKINS_BUILD"
  fi

  JAR_URL=http://$JENKINS_IP/job/apple.cmats/job/$JENKINS_BUILD/$BUILD_NUMBER/artifact/$ARTIFACT
  echo "Downloading Jar from :: $JAR_URL"

  (mkdir -p $JAR_DIR; cd $JAR_DIR && curl -s -O -f $JAR_URL)
}
