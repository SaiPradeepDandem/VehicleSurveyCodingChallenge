package com.sai.javafx.fxplorer.data;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Consumer;

import com.sai.javafx.fxplorer.connector.Dispatcher;
import com.sai.javafx.fxplorer.utils.Utils;

import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.PopupWindow;
import javafx.stage.Stage;
import javafx.stage.Window;

/**
 * Factory class for providing the details of a corresponding object.
 */
public class DetailsFactory {

    /** List of properties that need to be skipped from dispatching. */
    private static Set<String> SKIP_PROPERTIES = Set.of("virtual");

    /**
     * Provides the window details from the provided window instance.
     *
     * @param dispatcher dispatcher instance
     * @param appId VM id of the remote application
     * @param w window instance
     * @param dispatchType type of dispatch
     * @return window details
     */
    public static WindowDetails fromWindow(final Dispatcher dispatcher, final int appId, final Window w,
            final DispatchType dispatchType) {
        final WindowDetails wd = new WindowDetails(w);
        wd.setUId(w.hashCode());
        wd.setPopup(w instanceof PopupWindow);
        if (w instanceof final Stage stage) {
            wd.setTitle(stage.getTitle());
        } else if (w instanceof final PopupWindow popup) {
            wd.setTitle(Utils.nodeClass(popup));
        }
        wd.setVmId(appId);
        wd.setDispatchType(dispatchType);

        final Map<String, Observable> properties = loadProperties(w);
        final Consumer<PropertyDetails> pdConsumer =
                pd -> dispatcher.dispatchPropertyDetail(appId, wd.getUId(), wd.getUId(), pd);
        properties.forEach((propName, propDetails) -> {
            wd.getFullProperties().put(propName, new PropertyDetails(pdConsumer, propName, propDetails));
        });
        wd.setScene(fromScene(dispatcher, appId, wd.getUId(), w.getScene(), dispatchType));
        return wd;
    }

    /**
     * Provides the node details from the provided node instance.
     *
     * @param dispatcher dispatcher instance
     * @param appId VM id of the remote application
     * @param windowId id of the window
     * @param isPopup specifies if the node is from popup
     * @param n node instance
     * @param dispatchType type of dispatch
     * @return node details
     */
    private static NodeDetails fromNode(final Dispatcher dispatcher, final int appId, final int windowId,
            final boolean isPopup, final Node n, final DispatchType dispatchType) {
        final NodeDetails nodeDetails = new NodeDetails(n);
        nodeDetails.setVmId(appId);
        nodeDetails.setDispatchType(dispatchType);
        nodeDetails.setPopup(isPopup);

        final Map<String, Observable> properties = loadProperties(n);
        final Consumer<PropertyDetails> pdConsumer = pd -> {
            /* Dispatch the changes to the property */
            dispatcher.dispatchPropertyDetail(appId, windowId, nodeDetails.getUId(), pd);

            /* Dispatch the preview of node and its ancestors */
            sendNodePreview(dispatcher, appId, windowId, n);
        };
        properties.forEach((propName, propDetails) -> {
            nodeDetails.getFullProperties().put(propName, new PropertyDetails(pdConsumer, propName, propDetails));
        });

        if (n instanceof final Parent parent) {
            parent.getChildrenUnmodifiable().forEach(child -> {
                nodeDetails.getChildren().add(fromNode(dispatcher, appId, windowId, isPopup, child, dispatchType));
            });
            /* When children are added/deleted update the nodeDetails with new children details. */
            nodeDetails.setChildrenListener((ListChangeListener<? super Node>) p -> {
                nodeDetails.getChildren().forEach(NodeDetails::reset);
                nodeDetails.getChildren().clear();
                parent.getChildrenUnmodifiable().forEach(child -> {
                    nodeDetails.getChildren()
                        .add(fromNode(dispatcher, appId, windowId, isPopup, child, DispatchType.CHILDREN_UPDATED));
                });

                dispatcher.dispatchChildrenUpdate(appId, windowId, nodeDetails);
            });
        }
        return nodeDetails;
    }

    /**
     * Provides the scene details from the provided scene instance.
     *
     * @param dispatcher dispatcher instance
     * @param appId VM id of the remote application
     * @param windowId id of the window
     * @param s scene instance
     * @param dispatchType type of dispatch
     * @return scene details
     */
    private static SceneDetails fromScene(final Dispatcher dispatcher, final int appId, final int windowId,
            final Scene s, final DispatchType dispatchType) {
        final SceneDetails sd = new SceneDetails();
        sd.setUId(sd.hashCode());
        sd.setVmId(appId);
        sd.setDispatchType(dispatchType);
        sd.setPopup(s.getWindow() instanceof PopupWindow);
        sd.getStyleSheets().addAll(s.getStylesheets());
        final Map<String, Observable> properties = loadProperties(s);
        final Consumer<PropertyDetails> pdConsumer =
                pd -> dispatcher.dispatchPropertyDetail(appId, windowId, windowId, pd);
        properties.forEach((propName, propDetails) -> {
            sd.getFullProperties().put(propName, new PropertyDetails(pdConsumer, propName, propDetails));
        });
        sd.setRoot(fromNode(dispatcher, appId, windowId, sd.isPopup(), s.getRoot(), dispatchType));
        return sd;
    }

    /**
     * Returns the property name from provided method instance.
     *
     * @param method method instance
     * @return property name
     */
    private static String getPropertyName(final Method method) {
        if (method.getName().endsWith("Property")) {
            return method.getName().substring(0, method.getName().lastIndexOf("Property"));
        } else {
            final String name = method.getName().substring(3); /* skipping 'get' */
            return (name.charAt(0) + "").toLowerCase() + name.substring(1);
        }
    }

    /**
     * Checks if the provided method is a valid property method.
     *
     * @param method method instance
     * @return {@code true} if it is a valid property method
     */
    private static boolean isValidMethod(final Method method) {
        return method.getName().endsWith("Property")
            || method.getName().endsWith("StyleClass")
            ||
            method.getName().endsWith("Constraints")
            || method.getName().endsWith("PseudoClassStates");
    }

    /**
     * Loads all the observable properties of the provided object.
     *
     * @param object object
     * @return map of all observable properties
     */
    private static Map<String, Observable> loadProperties(final Object object) {
        final Map<String, Observable> properties = new TreeMap<>();
        final Method[] methods = object.getClass().getMethods();
        final int length = methods.length;
        for (int count = 0; count < length; ++count) {
            final Method method = methods[count];
            if (isValidMethod(method)) {
                try {
                    final Class<?> returnType = method.getReturnType();
                    if (Observable.class.isAssignableFrom(returnType)) {
                        final String propertyName = getPropertyName(method);
                        if (!SKIP_PROPERTIES.contains(propertyName)) {
                            method.setAccessible(true);
                            final Observable property = (Observable) method.invoke(object);
                            properties.put(propertyName, property);
                        }
                    }
                } catch (final Exception e) {
                    System.out.println("Error in loading the properties of the object ::  " + e.getMessage());
                }
            }
        }
        return properties;
    }

    /**
     * Sends the preview of the node.
     *
     * @param dispatcher dispatcher instance
     * @param appId VM id of the remote application
     * @param windowId id of the window
     * @param n node instance
     */
    private static void sendNodePreview(final Dispatcher dispatcher, final int appId, final int windowId,
            final Node n) {
        /* Send the node preview */
        dispatcher.dispatchPreview(appId, windowId, n);

        /* Send the parent ancestors preview */
        Parent p = n.getParent();
        while (p != null) {
            dispatcher.dispatchPreview(appId, windowId, p);
            p = p.getParent();
        }
    }
}
