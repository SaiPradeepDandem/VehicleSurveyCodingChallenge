package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javafx.scene.layout.Border;
import javafx.scene.layout.BorderImage;
import javafx.scene.layout.BorderStroke;

public class BorderValue implements Value, Serializable {

    private final List<BorderStrokeValue> strokes = new ArrayList<>();

    private final List<BorderImageValue> images = new ArrayList<>();

    private BorderValue() {
        /* private for snapshot */
    }

    public BorderValue(final Border border) {
        border.getStrokes().forEach(stroke -> strokes.add(new BorderStrokeValue(stroke)));
        border.getImages().forEach(image -> images.add(new BorderImageValue(image)));
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BorderValue that)) {
            return false;
        }
        return Objects.equals(strokes, that.strokes) && Objects.equals(images, that.images);
    }

    @Override
    public Border getValue() {
        final List<BorderStroke> bStrokes = new ArrayList<>();
        final List<BorderImage> bImages = new ArrayList<>();
        strokes.forEach(stroke -> bStrokes.add(stroke.getValue()));
        images.forEach(image -> bImages.add(image.getValue()));
        return new Border(bStrokes, bImages);
    }

    @Override
    public int hashCode() {
        return Objects.hash(strokes, images);
    }

    @Override
    public BorderValue snapshot() {
        final BorderValue snapshot = new BorderValue();
        strokes.forEach(stroke -> snapshot.strokes.add(stroke.snapshot()));
        images.forEach(image -> snapshot.images.add(image.snapshot()));
        return snapshot;
    }

    @Override
    public String toString() {
        return "BorderValue{"
            +
            "strokes="
            + strokes
            +
            ", images="
            + images
            +
            '}';
    }
}
