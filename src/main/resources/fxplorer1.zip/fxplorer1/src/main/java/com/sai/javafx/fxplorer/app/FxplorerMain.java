package com.sai.javafx.fxplorer.app;

/**
 * Application main class.
 */
public final class FxplorerMain {

    /**
     * Constructor.
     */
    public FxplorerMain() {
        /* Empty */
    }

    /**
     * Main method.
     *
     * @param args arguments
     */
    public static void main(final String[] args) {
        Fxplorer.main(args);
    }
}
