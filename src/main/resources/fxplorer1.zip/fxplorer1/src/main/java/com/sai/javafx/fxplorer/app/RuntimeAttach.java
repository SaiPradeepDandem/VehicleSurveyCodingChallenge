package com.sai.javafx.fxplorer.app;

import java.lang.instrument.Instrumentation;
import java.rmi.RemoteException;
import java.util.logging.Logger;

import com.sai.javafx.fxplorer.connector.Constants;
import com.sai.javafx.fxplorer.connector.RemoteAppImpl;

/**
 * Class to attach the agent to the remote application.
 */
public final class RuntimeAttach {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(RuntimeAttach.class.getName());

    /**
     * Constructor.
     */
    public RuntimeAttach() {
        /* Empty */
    }

    /**
     * Agent main method when attaching to remote.
     *
     * @param agentArgs arguments from the server
     * @param instrumentation instrumentation instance
     */
    public static void agentmain(final String agentArgs, final Instrumentation instrumentation) {
        LOGGER.info(
                () -> "Launching Fxplorer server on: <app_port>:<server_port>:<app_pid> : " + agentArgs);

        /* Set the server host name to the local IP address */
        System.setProperty("java.rmi.server.hostname", Constants.LOCAL_HOST);

        final String[] args = agentArgs.split(":");
        /* Port assigned to the remote */
        final int port = Integer.parseInt(args[0]);
        /* Port of the server */
        final int serverPort = Integer.parseInt(args[1]);
        /* PID of the remote */
        final int appID = Integer.parseInt(args[2]);

        final Thread remoteAppThread = new Thread(() -> {
            while (true) {
                try {
                    new RemoteAppImpl(port, serverPort, appID);
                    break;
                } catch (final IllegalStateException e) {
                    try {
                        Thread.sleep(500);
                    } catch (final InterruptedException ex) {
                    }
                } catch (final RemoteException e) {
                    throw new RuntimeException(e);
                }
            }
        }, "remote-app-thread");
        remoteAppThread.setDaemon(true);
        remoteAppThread.start();
    }
}
