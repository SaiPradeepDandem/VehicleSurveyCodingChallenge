package com.sai.javafx.fxplorer.ui.valuenode;

import java.awt.GraphicsEnvironment;
import java.util.List;
import java.util.stream.Stream;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.values.StringValue;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;

/**
 * Specifies the font value.
 */
public final class FontValueNode implements ValueNode {

    /** List of available fonts loaded in the system. */
    private static List<String> AVAILABLE_FONTS;

    /**
     * Loads all the available fonts in the graphics environment.
     */
    static {
        final GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        AVAILABLE_FONTS = List.of(ge.getAvailableFontFamilyNames());
    }

    /** Layout in which the font details are rendered. */
    private final GridPane layout = new GridPane();

    /** Label to display the font name. */
    private final Label name = new Label();

    /** Label to display the font family name. */
    private final Label family = new Label();

    /** Label to display the font style. */
    private final Label style = new Label();

    /** Label to display the font size. */
    private final Label size = new Label();

    /** Text to preview the font on sample text. */
    private final Text display = new Text();

    /** Preview text for visualizing the font. */
    private final String previewText = "ABCDEFGHIJKLMNOPQRSTUVWXYZ\nabcdefghijklmnopqrstuvwxyz\n0123456789";

    /**
     * Constructor.
     */
    public FontValueNode() {
        final Label nameLbl = new Label("Name");
        final Label familyLbl = new Label("Family");
        final Label styleLbl = new Label("Style");
        final Label sizeLbl = new Label("Size");
        GridPane.setMargin(display, new Insets(0, 0, 0, 20));
        layout.setVgap(3);
        layout.setHgap(5);
        layout.addRow(0, nameLbl, name);
        layout.addRow(1, familyLbl, family);
        layout.addRow(2, styleLbl, style);
        layout.addRow(3, sizeLbl, size);
        layout.add(display, 2, 0, 1, 4);
        Stream.of(nameLbl, familyLbl, styleLbl, sizeLbl).forEach(lbl -> lbl.getStyleClass().add("prop-label"));
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.LEFT);
        layout.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        layout.setMaxWidth(Region.USE_PREF_SIZE);
        layout.getStyleClass().add("font-value-node");
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        /* Empty */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        final String font = ((StringValue) propertyDetails.getValue()).getValue();
        final String[] props = font.replace("Font[", "").replace("]", "").split(", ");
        for (final String prop : props) {
            if (prop.startsWith("name=")) {
                name.setText(prop.replace("name=", ""));
            } else if (prop.startsWith("family=")) {
                family.setText(prop.replace("family=", ""));
            } else if (prop.startsWith("style=")) {
                style.setText(prop.replace("style=", ""));
                style.getStyleClass().clear();
                style.getStyleClass().addAll(style.getText().toLowerCase());
            } else if (prop.startsWith("size=")) {
                size.setText(prop.replace("size=", ""));
            }
        }

        final String fontFamily = family.getText();
        if (fontFamily.equals("System") || AVAILABLE_FONTS.contains(fontFamily)) {
            final String fontWeight = style.getText().toLowerCase().contains("bold") ? "bold" : "normal";
            final String fontStyle = style.getText().toLowerCase().contains("italic") ? "italic" : "normal";
            final String style = "-fx-font-family:\""
                + family.getText()
                + "\" !important; "
                +
                "-fx-font-weight:"
                + fontWeight
                + " !important; "
                +
                "-fx-font-style:"
                + fontStyle
                + " !important; "
                +
                "-fx-font-size:"
                + size.getText()
                + "px !important;-fx-fill:-fx-font-preview-color;";
            display.setText(previewText);
            display.setStyle(style);
        } else {
            display.setText("No Preview Available");
            display.setStyle(null);
        }
    }
}
