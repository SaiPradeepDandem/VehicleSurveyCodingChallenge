package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.paint.ImagePattern;

public class ImagePatternValue implements Value, Serializable {

    private ImageValue image;

    private double x;

    private double y;

    private double width;

    private double height;

    private boolean proportional;

    private ImagePatternValue() {
        /* private for snapshot */
    }

    public ImagePatternValue(final ImagePattern imagePattern) {
        image = new ImageValue(imagePattern.getImage());
        x = imagePattern.getX();
        y = imagePattern.getY();
        width = imagePattern.getWidth();
        height = imagePattern.getHeight();
        proportional = imagePattern.isProportional();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final ImagePatternValue that)) {
            return false;
        }
        return Double.compare(that.x, x) == 0
            && Double.compare(that.y, y) == 0
            && Double.compare(that.width, width) == 0
            && Double.compare(that.height, height) == 0
            && proportional == that.proportional
            && Objects.equals(image, that.image);
    }

    @Override
    public ImagePattern getValue() {
        return new ImagePattern(image.getValue(), x, y, width, height, proportional);
    }

    @Override
    public int hashCode() {
        return Objects.hash(image, x, y, width, height, proportional);
    }

    @Override
    public ImagePatternValue snapshot() {
        final ImagePatternValue snapshot = new ImagePatternValue();
        snapshot.x = x;
        snapshot.y = y;
        snapshot.proportional = proportional;
        snapshot.width = width;
        snapshot.height = height;
        snapshot.image = image == null ? null : image.snapshot();
        return snapshot;
    }

    @Override
    public String toString() {
        return "ImagePatternValue{"
            +
            "image="
            + image
            +
            ", x="
            + x
            +
            ", y="
            + y
            +
            ", width="
            + width
            +
            ", height="
            + height
            +
            ", proportional="
            + proportional
            +
            '}';
    }
}
