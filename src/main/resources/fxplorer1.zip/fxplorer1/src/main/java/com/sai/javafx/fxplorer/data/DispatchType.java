package com.sai.javafx.fxplorer.data;

/**
 * Specifies the type of dispatch event.
 */
public enum DispatchType {
    /** Dispatch type when a new window is added. */
    WINDOW_ADDED,

    /** Dispatch type when a window is deleted. */
    WINDOW_DELETED,

    /** Dispatch type when a node are updated. */
    DETAILS_UPDATED,

    /** Dispatch type when children are added or deleted to a parent node. */
    CHILDREN_UPDATED
}
