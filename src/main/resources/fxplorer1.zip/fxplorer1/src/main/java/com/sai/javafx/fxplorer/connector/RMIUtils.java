package com.sai.javafx.fxplorer.connector;

import static com.sai.javafx.fxplorer.connector.Constants.LOCAL_HOST;
import static com.sai.javafx.fxplorer.connector.Constants.REMOTE_AGENT;
import static com.sai.javafx.fxplorer.connector.Constants.REMOTE_CONNECTOR;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Logger;

/**
 * Utility class.
 */
public final class RMIUtils {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(RMIUtils.class.getName());

    /** Local registry instance. */
    private static Registry localRegistry;

    /** Default port for the rmi. */
    private static AtomicInteger rmiPort = new AtomicInteger(6900);

    /**
     * Constructor.
     */
    public RMIUtils() {
        /* Empty */
    }

    /**
     * Registers the provided remote application in the registry.
     *
     * @param remoteAgent remote agent
     * @param port port number of the remote agent
     * @throws RemoteException
     */
    public static final void bindApplication(final IRemoteApp remoteAgent, final int port)
            throws RemoteException {
        /* Create the registry and bind the name and object */
        localRegistry = LocateRegistry.createRegistry(port);
        localRegistry.rebind(REMOTE_AGENT, remoteAgent);
    }

    /**
     * Registers the fxplorer to the registry.
     *
     * @param fxplorer fxplorer instance
     * @param port fxplorer port number
     * @throws RemoteException
     */
    public static final void bindFxplorer(final IFxplorer fxplorer, final int port)
            throws RemoteException {
        /* Create the registry and bind the name and object */
        final Registry registry = LocateRegistry.createRegistry(port);
        registry.rebind(REMOTE_CONNECTOR, fxplorer);
    }

    /**
     * Finds the remote application for the given port and sends to the provided consumer.
     *
     * @param port port number of the remote agent
     * @param consumer consumer to pass the remote agent
     */
    public static final void findApplication(final int port, final Consumer<IRemoteApp> consumer) {
        final Thread remoteBrowserFinder = new Thread(REMOTE_AGENT + ".Finder") {

            @Override
            public final void run() {
                IRemoteApp application = null;

                while (application == null) {
                    try {
                        application = findApplication(LOCAL_HOST, port);
                        if (application != null) {
                            sleep(50);
                        }
                    } catch (final Exception e) {
                        e.printStackTrace();
                    }
                }
                consumer.accept(application);
            }
        };
        remoteBrowserFinder.start();
    }

    /**
     * Finds the fxplorer for the given port and sends to the provided consumer.
     *
     * @param port port number of the fxplorer
     * @param consumer consumer to pass the fxplorer
     */
    public static final void findFxplorer(final int port, final Consumer<IFxplorer> consumer) {
        new Thread(REMOTE_CONNECTOR + ".Finder") {

            @Override
            public final void run() {
                IFxplorer fxplorerInterface = null;

                while (fxplorerInterface == null) {
                    try {
                        LOGGER.info(() -> "Finding " + REMOTE_CONNECTOR + " connection for agent...");
                        fxplorerInterface = findFxplorer(LOCAL_HOST, port);
                        if (fxplorerInterface == null) {
                            sleep(50);
                        }
                    } catch (final Exception e) {

                    }
                }
                consumer.accept(fxplorerInterface);
            }
        }.start();
    }

    /**
     * Get the unique port number for the client.
     *
     * @return port number
     */
    public static int getClientPort() {
        return rmiPort.incrementAndGet();
    }

    /**
     * Un-registers the application.
     *
     * @param port of the remote agent
     * @throws RemoteException
     */
    public static final void unbindApplication(final int port) throws RemoteException {
        try {
            localRegistry.unbind(REMOTE_AGENT);
            UnicastRemoteObject.unexportObject(localRegistry, true);
        } catch (final NotBoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Un-registers the fxplorer.
     *
     * @param port of the fxplorer
     * @throws RemoteException
     */
    public static final void unbindFxplorer(final int port) throws RemoteException, NotBoundException {
        /* Create the registry and bind the name and object */
        final Registry registry = LocateRegistry.getRegistry(port);
        registry.unbind(REMOTE_CONNECTOR);
    }

    /**
     * Finds the application in the registry.
     *
     * @param remoteAppAdress remote app address
     * @param remoteAppPort remote app port
     * @return remote app interface
     * @throws Exception
     */
    private static final IRemoteApp findApplication(final String remoteAppAdress, final int remoteAppPort)
            throws Exception {
        final Registry registry = LocateRegistry.getRegistry(remoteAppAdress, remoteAppPort);
        /* Look up the remote object */
        return (IRemoteApp) registry.lookup(REMOTE_AGENT);
    }

    /**
     * Finds the fxplorer in the registry.
     *
     * @param serverAdress server address
     * @param serverPort server port
     * @return fxplorer interface
     * @throws Exception
     */
    private static final IFxplorer findFxplorer(final String serverAdress, final int serverPort)
            throws Exception {
        final Registry registry = LocateRegistry.getRegistry(serverAdress, serverPort);
        /* Look up the remote object */
        return (IFxplorer) registry.lookup(REMOTE_CONNECTOR);
    }
}
