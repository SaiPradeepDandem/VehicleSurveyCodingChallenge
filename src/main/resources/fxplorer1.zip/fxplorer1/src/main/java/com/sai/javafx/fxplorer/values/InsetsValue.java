package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.geometry.Insets;

public class InsetsValue implements Value, Serializable {

    private double top;

    private double right;

    private double bottom;

    private double left;

    private InsetsValue() {
        /* private for snapshot */
    }

    public InsetsValue(final Insets insets) {
        top = insets.getTop();
        right = insets.getRight();
        bottom = insets.getBottom();
        left = insets.getLeft();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final InsetsValue that)) {
            return false;
        }
        return Double.compare(that.top, top) == 0
            && Double.compare(that.right, right) == 0
            && Double.compare(that.bottom, bottom) == 0
            && Double.compare(that.left, left) == 0;
    }

    @Override
    public Insets getValue() {
        return new Insets(top, right, bottom, left);
    }

    @Override
    public int hashCode() {
        return Objects.hash(top, right, bottom, left);
    }

    @Override
    public InsetsValue snapshot() {
        final InsetsValue snapshot = new InsetsValue();
        snapshot.top = top;
        snapshot.right = right;
        snapshot.bottom = bottom;
        snapshot.left = left;
        return snapshot;
    }

    @Override
    public String toString() {
        return "InsetsValue{"
            +
            "top="
            + top
            +
            ", right="
            + right
            +
            ", bottom="
            + bottom
            +
            ", left="
            + left
            +
            '}';
    }
}
