package com.sai.javafx.fxplorer.connector;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;
import com.sai.javafx.fxplorer.ui.LayoutController;

/**
 * Loader class to find and connect to all running JavaFX applications.
 */
public final class AgentLoader {

    /**
     * Logger.
     */
    private static final Logger LOGGER = Logger.getLogger(AgentLoader.class.getName());

    /**
     * Agent jar that attaches to the remote.
     */
    private final File agentJar;

    /**
     * Port for the fxplorer server.
     */
    private final int port;

    /**
     * Implementation instance of fxplorer interface that communicates with the remotes.
     */
    private final FxplorerImpl fxplorerImpl;

    /**
     * List of all loaded applications.
     */
    private final List<String> appsRepo = new ArrayList<>();

    /**
     * Constructor.
     *
     * @throws RemoteException
     */
    public AgentLoader() throws Exception {
        super();
        agentJar = findAgent();
        port = getValidPort();
        fxplorerImpl = new FxplorerImpl();
        RMIUtils.bindFxplorer(fxplorerImpl, port);
    }

    /**
     * Starts the thread to search for the remote JavaFX applications.
     *
     * @param layoutController layout controller to load the applications
     */
    public final void connect(final LayoutController layoutController) {
        fxplorerImpl.setUIController(layoutController);
        final Thread appsFinderThread = new Thread(() -> {
            final boolean flag = true;
            while (flag) {
                findApps();
                try {
                    Thread.sleep(1000);
                } catch (final InterruptedException e) {
                    /* Keep running to find the applications */
                    LOGGER.severe("InterruptedException while sleeping in RemoteAppsFinderThread !!");
                }
            }
        });
        appsFinderThread.setName("RemoteAppsFinderThread");
        appsFinderThread.setDaemon(true);
        appsFinderThread.start();
    }

    /**
     * Returns the agent jar file.
     *
     * @return jar file
     */
    public final File getAgentFile() {
        return agentJar;
    }

    /**
     * Extracts the agent JAR from the resources and saves it to a temp file.
     *
     * @return the temp file pointing to the extracted agent jar
     * @throws IOException if the resource is not found or write fails
     */
    public static File findAgentForExe() throws IOException {
        final String prefix = "fxplorer-agent";
        final String ext = ".jar";
        final String jarFileName = prefix + ext;
        deleteTempFilesIfExists(prefix);
        final Path tempAgent = Files.createTempFile(prefix, ext);
        try (InputStream is = AgentLoader.class.getResourceAsStream("/agent/" + jarFileName)) {
            if (is == null) {
                throw new FileNotFoundException("Agent JAR not found in resources: /agent/" + jarFileName);
            }
            Files.copy(is, tempAgent, StandardCopyOption.REPLACE_EXISTING);
        }
        LOGGER.info("Temp jar created at : " + tempAgent.toFile().getAbsolutePath());
        return tempAgent.toFile();
    }

    /**
     * Deletes the existing temp files if already created.
     *
     * @param prefix file name prefix
     */
    private static void deleteTempFilesIfExists(String prefix) {
        // Get the system temp directory
        File tempDir = new File(System.getProperty("java.io.tmpdir"));

        // Delete old temp files that start with "fxplorer-agent"
        File[] oldAgentFiles = tempDir.listFiles((dir, name) -> name.startsWith(prefix));
        if (oldAgentFiles != null) {
            for (File file : oldAgentFiles) {
                if (file.delete()) {
                    System.out.println("Deleted old temp agent file: " + file.getAbsolutePath());
                } else {
                    System.err.println("Failed to delete temp agent file: " + file.getAbsolutePath());
                }
            }
        }
    }

    /**
     * Loads the agent jar.
     *
     * @return agent jar file
     */
    private File findAgent() throws IOException {
        File tempAgent = null;

        /* Find jar file in the class path */
        final String classPath = System.getProperty(Constants.JAVA_CLASSPATH);
        final String pathSeparator = System.getProperty(Constants.PATH_SEPARATOR);
        if (classPath != null && !classPath.isEmpty()) {
            final String[] files = classPath.split(pathSeparator);
            for (final String file : files) {
                if (file.toLowerCase().indexOf(Constants.JAR_NAME) != -1) {
                    tempAgent = new File(file);
                    break;
                }
            }
        }

        if (tempAgent == null || !tempAgent.exists()) {
            /* Find jar file in the module path */
            final String modulePath = System.getProperty(Constants.JDK_MODULE_PATH);
            if (modulePath != null && !modulePath.isEmpty()) {
                final String[] files = modulePath.split(pathSeparator);
                for (final String file : files) {
                    if (file.toLowerCase().indexOf(Constants.JAR_NAME) != -1) {
                        tempAgent = new File(file);
                        break;
                    }
                }
            }
        }

        if (tempAgent == null || !tempAgent.exists()) {
            /* If we are here, lets check the development location, and try to get the jar from there */
            final File buildLibsDir = new File(Constants.LIBS_PATH);
            if (buildLibsDir.exists()) {
                final File[] jarFiles = buildLibsDir.listFiles((f, name) -> name.endsWith(Constants.JAR_EXT));
                for (final File jarFile : jarFiles) {
                    if (tempAgent == null || jarFile.length() > tempAgent.length()) {
                        tempAgent = jarFile;
                    }
                }
            }
        }

        if (tempAgent == null) {
            tempAgent = findAgentForExe();
        }
        if (tempAgent == null) {
            LOGGER.severe("Error: Unable to find agent jar file. Exiting Fxplorer.");
            System.exit(-1);
        } else {
            LOGGER.info("Loading agent from: " + tempAgent.getAbsolutePath());
        }
        return tempAgent;
    }

    /**
     * Finds all JavaFX applications.
     */
    private void findApps() {
        final List<VirtualMachine> machines = getRunningJavaFXApplications();
        final List<String> allFxAppIds = machines.stream().map(VirtualMachine::id).collect(Collectors.toList());

        /* Find all deleted apps. */
        final List<String> deletedApps =
                appsRepo.stream().filter(vmId -> !allFxAppIds.contains(vmId)).collect(Collectors.toList());
        deletedApps.forEach(appId -> {
            LOGGER.info(() -> "Removing VM : " + appId);
            appsRepo.remove(appId);
            fxplorerImpl.deleteApp(appId);
        });

        final File agent = getAgentFile();
        /* Find all new apps and load agents on them. */
        machines.stream().filter(vm -> !appsRepo.contains(vm.id())).forEach(newVM -> {
            LOGGER.info(() -> "New JavaFX application found : " + newVM.id());
            appsRepo.add(newVM.id());
            final Thread agentThread = new Thread(() -> loadAgent(newVM, agent));
            agentThread.setDaemon(true);
            agentThread.setName("LoadAgentThread_VM" + newVM.id());
            agentThread.start();
        });
    }

    /**
     * Returns all running JavaFX applications.
     *
     * @return list of virtual machines
     */
    private List<VirtualMachine> getRunningJavaFXApplications() {
        /* Alternate approach: But this approach not working when running from command line. */
        /* final List<VirtualMachineDescriptor> machines = VirtualMachine.list(); */
        final List<VirtualMachine> fxVMs = new ArrayList<>();
        final long currentPid = ProcessHandle.current().pid();
        ProcessHandle.allProcesses().filter(p -> p.pid() != currentPid).forEach(p -> {
            p.info().command().filter(this::isJavaCommand).ifPresent(cmd -> {
                try {
                    final VirtualMachine vm = VirtualMachine.attach(p.pid() + "");
                    final Properties sysPropertiesMap = vm.getSystemProperties();
                    if (sysPropertiesMap != null
                            && sysPropertiesMap.containsKey(Constants.JAVAFX_SYSTEM_PROPERTIES_KEY)
                            && Double.parseDouble(
                            sysPropertiesMap.get(Constants.JAVA_CLASS_VERSION_KEY)
                                    .toString()) > Constants.JAVA_CLASS_VERSION_VALUE) {
                        fxVMs.add(vm);
                    } else {
                        vm.detach();
                    }
                } catch (final IOException e) {
                    LOGGER.fine("Exception occured while finding VMs " + e);
                } catch (final AttachNotSupportedException e) {
                    LOGGER.fine("Exception occured while attaching agent " + e);
                } catch (final Exception e) {
                    LOGGER.fine("General Exception occured while finding VMs " + e);
                }
            });
        });
        return fxVMs;
    }

    /**
     * Returns a valid port.
     *
     * @return port
     */
    private int getValidPort() {
        int port = RMIUtils.getClientPort();
        boolean valid;
        do {
            try {
                final Socket socket = new Socket();
                socket.connect(new InetSocketAddress(Constants.LOCAL_HOST, port), 100);
                socket.close();
                valid = true;
                port = RMIUtils.getClientPort();
            } catch (final Exception e) {
                valid = false;
            }

        } while (valid);
        return port;
    }

    /**
     * Checks if the provided command is a java command or not.
     *
     * @param cmd command string
     * @return {@code true} if it is a java command
     */
    private boolean isJavaCommand(final String cmd) {
        return cmd.endsWith("java.exe")
                || cmd.endsWith("javaw.exe")
                || cmd.endsWith("java")
                || cmd.endsWith("javaw");
    }

    /**
     * Loads the agent to the provided virtual machine.
     *
     * @param machine  virtual machine
     * @param agentJar agent jar
     */
    private void loadAgent(final VirtualMachine machine, final File agentJar) {
        try {
            final long start = System.currentTimeMillis();
            final int port = getValidPort();
            LOGGER.info(() -> "Loading agent for:"
                    + machine
                    + " ID:"
                    + machine.id()
                    + " on port:"
                    + port
                    + " took:"
                    + (System.currentTimeMillis() - start)
                    + "ms using agent defined in "
                    + agentJar.getAbsolutePath());
            machine.loadAgent(agentJar.getAbsolutePath(), port + ":" + this.port + ":" + machine.id());
            machine.detach();
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }
}
