package com.sai.javafx.fxplorer.data;

import java.io.Serializable;

/**
 * Enum to specify the type of the value.
 */
public enum ValueType implements Serializable {
    /** Specifies null value. */
    NULL,
    /** Specifies string value. */
    STRING,
    /** Specifies insets value */
    INSETS,
    /** Specifies background value. */
    BACKGROUND,
    /** Specifies border value. */
    BORDER,
    /** Specifies image value. */
    IMAGE,
    /** Specifies bounds value. */
    BOUNDS,
    /** Specifies constraints value. */
    CONSTRAINTS
}
