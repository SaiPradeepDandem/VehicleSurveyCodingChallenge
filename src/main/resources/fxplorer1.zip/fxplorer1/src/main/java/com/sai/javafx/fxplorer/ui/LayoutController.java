package com.sai.javafx.fxplorer.ui;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.sai.javafx.fxplorer.data.AppDetails;
import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.SceneDetails;
import com.sai.javafx.fxplorer.data.TreeData;
import com.sai.javafx.fxplorer.data.WindowDetails;
import com.sai.javafx.fxplorer.utils.TriConsumer;
import com.sai.javafx.fxplorer.widgets.ScreenshotStage;
import com.sai.javafx.fxplorer.widgets.SearchBox;
import com.sai.javafx.fxplorer.widgets.SnapshotButton;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Popup;
import javafx.stage.Screen;

/**
 * Controller for the layout fxml.
 */
public final class LayoutController {

	@FXML
	private BorderPane root;

	@FXML
	private ToolBar topToolBar;

	@FXML
	private CheckBox selectNodeCB;

	@FXML
	private CheckBox popupHidingCB;

	@FXML
	private HBox monitorsBtnPane;

	@FXML
	private SnapshotButton snapshotBtn;

	@FXML
	private SplitPane splitPane;

	@FXML
	private StackPane leftContainer;

	@FXML
	private StackPane progressPane;

	@FXML
	private VBox leftPane;

	@FXML
	private FxplorerTree treeView;

	@FXML
	private SearchBox<FxplorerTreeItem> searchBox;

	@FXML
	private TabPane tabPane;

	@FXML
	private Tab detailsTab;

	@FXML
	private Tab cssTab;

	@FXML
	private Tab snapshotTab;

	@FXML
	private StackPane detailsTabContent;

	@FXML
	private ListView<String> styleSheetsTabContent;

	@FXML
	private StackPane snapshotTabContent;

	/** Consumer for the popup hiding. */
	private Consumer<Boolean> popupHideConsumer;

	/** Consumer for selecting node. */
	private Consumer<Boolean> selectNodeConsumer;

	/** Consumer for highlighting the node. */
	private TriConsumer<Details, Integer, Boolean> highlightNodeConsumer;

	/** Consumer for previewing the node. */
	private TriConsumer<Integer, Integer, Integer> previewNodeConsumer;

	/** Details controller instance. */
	private DetailsController detailsController;

	/** Snapshots controller instance. */
	private SnapshotController snapshotsController;

	/** Current selected object details. */
	private Details current;

	private Popup monitorIndentifier;

	/**
	 * Constructor.
	 */
	public LayoutController() {
		/* Empty */
	}

	/**
	 * Adds the application tree item to the treeView.
	 *
	 * @param appDetails application details
	 */
	public final void addApp(final AppDetails appDetails) {
		final FxplorerTreeItem appItem = new FxplorerTreeItem(appDetails);
		treeView.addAppItem(appItem);
	}

	/**
	 * Adds the node tree item.
	 *
	 * @param nodeDetails node details
	 * @param parentItem  parent tree item
	 * @return newly added tree item
	 */
	public final FxplorerTreeItem addNode(final NodeDetails nodeDetails, final FxplorerTreeItem parentItem) {
		/* Add node at last */
		return addNode(nodeDetails, parentItem, -1);
	}

	/**
	 * Adds the node tree item at the provided index.
	 *
	 * @param nodeDetails node details
	 * @param parentItem  parent tree item
	 * @param index       index at which the item needs to be added
	 * @return newly added tree item
	 */
	public final FxplorerTreeItem addNode(final NodeDetails nodeDetails, final FxplorerTreeItem parentItem,
			final int index) {
		final FxplorerTreeItem nodeItem = new FxplorerTreeItem(nodeDetails);
		if (index == -1) {
			parentItem.getChildren().add(nodeItem);
		} else {
			parentItem.getChildren().add(index, nodeItem);
		}
		for (final NodeDetails child : nodeDetails.getChildren()) {
			addNode(child, nodeItem);
		}
		return nodeItem;
	}

	/**
	 * Adds the tree item for the provided scene.
	 *
	 * @param sceneDetails scene details
	 * @param windowItem   window tree item
	 */
	public final void addScene(final SceneDetails sceneDetails, final FxplorerTreeItem windowItem) {
		final FxplorerTreeItem sceneItem = new FxplorerTreeItem(sceneDetails);
		sceneItem.setExpanded(true);
		windowItem.getChildren().add(sceneItem);
		final FxplorerTreeItem rootItem = addNode(sceneDetails.getRoot(), sceneItem);
		rootItem.setExpanded(true);
	}

	/**
	 * Adds the window tree item.
	 *
	 * @param windowDetails window details
	 */
	public final void addWindow(final WindowDetails windowDetails) {
		final FxplorerTreeItem appTreeItem = treeView.getAppTreeItem(windowDetails.getVmId());
		/* Check if the window item already exists. */
		int index = -1;
		for (final TreeItem<TreeData> win : appTreeItem.getChildren()) {
			if (win.getValue().getUId() == windowDetails.getUId()) {
				index = appTreeItem.getChildren().indexOf(win);
			}
		}
		final FxplorerTreeItem windowItem = new FxplorerTreeItem(windowDetails);
		windowItem.setExpanded(true);
		/* Replace the item if already exists. */
		if (index > -1) {
			appTreeItem.getChildren().set(index, windowItem);
		} else {
			appTreeItem.getChildren().add(windowItem);
		}
		addScene(windowDetails.getScene(), windowItem);
	}

	/**
	 * Returns the root of the layout.
	 *
	 * @return root
	 */
	public final BorderPane getRoot() {
		return root;
	}

	/**
	 * Highlights the current selected node.
	 */
	public final void highlightNode() {
		if (current != null) {
			final int windowId = treeView.getWindowId(current);
			if (windowId > -1) {
				highlightNodeConsumer.accept(current, windowId, true);
			}
		}
	}

	/**
	 * Specifies if the blocking popup hide is activated or not.
	 *
	 * @return {@code true} if blocking popup hide
	 */
	public final boolean isBlockPopupHide() {
		return popupHidingCB.isSelected();
	}

	/**
	 * Specifies if the node selection is activated or not.
	 *
	 * @return {@code true} if node can be selected
	 */
	public final boolean isSelectNode() {
		return selectNodeCB.isSelected();
	}

	/**
	 * Loads the layout.
	 */
	public final void load() {
		try {
			final FXMLLoader loader = new FXMLLoader(getClass().getResource("layout.fxml"));
			loader.setController(this);
			loader.load();
		} catch (final Exception e) {
			e.printStackTrace();
			throw new IllegalStateException("Unable to load the layout fxml");
		}
	}

	/**
	 * Remove the provided application from the treeView.
	 *
	 * @param appDetails application details
	 */
	public final void removeApp(final AppDetails appDetails) {
		FxplorerTreeItem appItem = null;
		for (final TreeItem<TreeData> item : treeView.getRoot().getChildren()) {
			if (item.getValue().getUId() == appDetails.getUId()) {
				appItem = (FxplorerTreeItem) item;
				break;
			}
		}
		treeView.getRoot().getChildren().remove(appItem);
	}

	/**
	 * Removes the current highlight.
	 */
	public final void removeHighlight() {
		if (current != null) {
			final int windowId = treeView.getWindowId(current);
			if (windowId > -1) {
				highlightNodeConsumer.accept(current, windowId, false);
			}
		}
	}

	/**
	 * Removes all popup tree items.
	 */
	public final void removePopups() {
		for (final TreeItem<TreeData> appItem : treeView.getRoot().getChildren()) {
			final List<TreeItem<TreeData>> winItems = appItem.getChildren();
			for (final Iterator<TreeItem<TreeData>> iterator = winItems.iterator(); iterator.hasNext();) {
				final TreeItem<TreeData> winItem = iterator.next();
				final WindowDetails window = (WindowDetails) winItem.getValue();
				if (window.isPopup()) {
					iterator.remove();
				}
			}
		}
	}

	/**
	 * Removes the tree item of the provided window details.
	 *
	 * @param appId  application id
	 * @param window window details
	 */
	public final void removeWindow(final int appId, final WindowDetails window) {
		final FxplorerTreeItem appTreeItem = treeView.getAppTreeItem(appId);
		FxplorerTreeItem windowItem = null;
		for (final TreeItem<TreeData> item : appTreeItem.getChildren()) {
			if (item.getValue().getUId() == window.getUId()) {
				windowItem = (FxplorerTreeItem) item;
				break;
			}
		}
		final FxplorerTreeItem selectedItem = (FxplorerTreeItem) treeView.getSelectionModel().getSelectedItem();
		appTreeItem.getChildren().remove(windowItem);
		treeView.getSelectionModel().select(selectedItem);
	}

	/**
	 * Select the provided node in the tree view.
	 *
	 * @param appId    application id
	 * @param windowId window id
	 * @param nodeId   node id
	 */
	public final void selectNodeInTree(final int appId, final int windowId, final int nodeId) {
		Platform.runLater(() -> {
			/* De select the checkbox first */
			selectNodeCB.setSelected(false);
			treeView.selectNode(appId, windowId, nodeId);
		});
	}

	/**
	 * Sets the consumer for the highlight action.
	 *
	 * @param highlightNodeConsumer consumer
	 */
	public final void setHighlightNodeConsumer(final TriConsumer<Details, Integer, Boolean> highlightNodeConsumer) {
		this.highlightNodeConsumer = highlightNodeConsumer;
	}

	/**
	 * Sets the consumer for the popup hide action.
	 *
	 * @param popupHideConsumer consumer
	 */
	public final void setPopupHideConsumer(final Consumer<Boolean> popupHideConsumer) {
		this.popupHideConsumer = popupHideConsumer;
	}

	/**
	 * Sets the consumer for the preview action.
	 *
	 * @param previewNodeConsumer consumer
	 */
	public final void setPreviewNodeConsumer(final TriConsumer<Integer, Integer, Integer> previewNodeConsumer) {
		this.previewNodeConsumer = previewNodeConsumer;
	}

	/**
	 * Sets the consumer for the select node action.
	 *
	 * @param selectNodeConsumer consumer
	 */
	public final void setSelectNodeConsumer(final Consumer<Boolean> selectNodeConsumer) {
		this.selectNodeConsumer = selectNodeConsumer;
	}

	/**
	 * Displays the details tab for the provided tree item.
	 *
	 * @param details  details
	 * @param treeItem tree item
	 */
	public final void showDetails(final Details details, final TreeItem<TreeData> treeItem) {
		current = details;
		detailsController.showDetails(details);

		updateStyleSheetsTab(treeItem);
	}

	/**
	 * Updates the children from the provide node details.
	 *
	 * @param appId          application id
	 * @param windowId       window id
	 * @param newNodeDetails node details
	 */
	public final void updateChildren(final int appId, final int windowId, final NodeDetails newNodeDetails) {
		Platform.runLater(() -> {
			TreeItem<TreeData> selectedItem = null;
			if (treeView.getSelectionModel().getSelectedItem() != null) {
				selectedItem = treeView.getSelectionModel().getSelectedItem();
			}
			final FxplorerTreeItem nodeTreeItem = treeView.getNodeTreeItem(appId, windowId, newNodeDetails.getUId());
			nodeTreeItem.setValue(newNodeDetails);

			final List<Integer> currentChildIds = nodeTreeItem.getChildren().stream()
					.map(treeItem -> treeItem.getValue().getUId()).collect(Collectors.toList());
			final List<Integer> newChildIds = newNodeDetails.getChildren().stream().map(NodeDetails::getUId)
					.collect(Collectors.toList());

			/* Remove deleted items */
			for (final Iterator<TreeItem<TreeData>> iterator = nodeTreeItem.getChildren().iterator(); iterator
					.hasNext();) {
				final TreeItem<TreeData> treeItem = iterator.next();
				if (!newChildIds.contains(treeItem.getValue().getUId())) {
					iterator.remove();
				}
			}
			currentChildIds.retainAll(newChildIds);

			int index = 0;
			/* Add newly added items */
			for (final NodeDetails child : newNodeDetails.getChildren()) {
				/* Already existed child */
				if (currentChildIds.contains(child.getUId())) {
					final int currentChildIndex = findChildIndex(nodeTreeItem, child.getUId());
					/* Update the tree item with new details. */
					nodeTreeItem.getChildren().get(currentChildIndex).setValue(child);
					/* If the tree item needs a position change, then change it. */
					if (currentChildIndex != index) {
						Collections.swap(nodeTreeItem.getChildren(), currentChildIndex, index);
					}
				} else {
					/* New Child */
					addNode(child, nodeTreeItem, index);
				}
				index++;
			}
			if (selectedItem != null) {
				treeView.getSelectionModel().select(selectedItem);
			}
		});
	}

	/**
	 * Updates the property details for the provided owner item.
	 *
	 * @param appId       application id
	 * @param windowId    window id
	 * @param ownerId     owner id
	 * @param propDetails property details
	 */
	public final void updateProperty(final int appId, final int windowId, final int ownerId,
			final PropertyDetails propDetails) {
		/* Updating the details in the tree object. */
		treeView.updateProperty(appId, windowId, ownerId, propDetails);

		/*
		 * If it is the currently selected item, then reflecting in the details' pane as
		 * well.
		 */
		if (current != null && current.getUId() == ownerId) {
			detailsController.updateProperty(propDetails);
		}
	}

	/**
	 * Updates the snapshots tab.
	 *
	 * @param count no of snapshots
	 */
	public final void updateSnapshotsTab(final int count) {
		Platform.runLater(() -> {
			snapshotTab.setDisable(count == 0);
			snapshotTab.setText("Snapshots (" + count + ")");
			if (snapshotTab.isDisable() && snapshotTab.isSelected()) {
				tabPane.getSelectionModel().select(detailsTab);
			}
		});
	}

	@FXML
	final void initialize() {
		detailsController = new DetailsController(this);
		detailsTabContent.getChildren().add(detailsController.getDetailsContainer());

		snapshotsController = new SnapshotController(this);
		snapshotTabContent.getChildren().add(snapshotsController.getSnapshotsRoot());

		treeView.setLayoutController(this);
		treeView.getSelectionModel().selectedItemProperty().addListener((obs, old, item) -> {
			registerPreviewNode(old, item);
			snapshotBtn.update(item == null || item.getValue() instanceof AppDetails);
			snapshotsController.update((FxplorerTreeItem) item);
		});

		progressPane.visibleProperty().bind(Bindings.createBooleanBinding(
				() -> treeView.getRoot().getChildren().isEmpty(), treeView.getRoot().getChildren()));
		leftPane.disableProperty().bind(progressPane.visibleProperty());

		selectNodeCB.selectedProperty().addListener((obs, old, selectNode) -> selectNodeConsumer.accept(selectNode));
		popupHidingCB.selectedProperty().addListener((obs, old, blockHiding) -> popupHideConsumer.accept(blockHiding));

		searchBox.setSearchFilter(this::filterTreeItems);
		searchBox.setSelectItem(treeItem -> {
			treeView.getSelectionModel().select(treeItem);
			treeView.scrollTo(treeView.getSelectionModel().getSelectedIndex());
			treeView.requestFocus();
		});

		snapshotBtn.setActionHandler(() -> {
			if (!snapshotBtn.isDisable()) {
				final FxplorerTreeItem item = (FxplorerTreeItem) treeView.getSelectionModel().getSelectedItem();
				item.createSnapshot();
				snapshotsController.update(item);
			}
		});

		root.sceneProperty().addListener((obs, old, scene) -> {
			if (scene != null) {
				((FxplorerWindow) scene.getWindow()).themeProperty().addListener((obs1, old1, theme) -> {
					detailsController.onThemeUpdate(theme);
					snapshotsController.onThemeUpdate(theme);
				});
			}
		});

		styleSheetsTabContent.setCellFactory(param -> new ListCell<>() {

			@Override
			protected final void updateItem(final String item, final boolean empty) {
				super.updateItem(item, empty);
				if (item != null) {
					setText(item.startsWith("-") ? item.substring(1) : "    " + item);
					if (item.startsWith("-") && !getStyleClass().contains("bold")) {
						getStyleClass().add("bold");
					}
				} else {
					setText(null);
					getStyleClass().remove("bold");
				}
			}
		});

		loadMonitorsButtons();
	}

	/**
	 * Loads the buttons for the available monitors to take screenshots.
	 */
	private void loadMonitorsButtons() {
		final double negSpace = -30000;
		final double borderWidth = 2; /* Check in fxplorer.css */
		monitorIndentifier = new Popup();
		Rectangle box = new Rectangle(8, 8);
		box.setMouseTransparent(true);
		box.getStyleClass().add("monitorIdentifier");
		monitorIndentifier.getContent().add(box);
		/*
		 * We show the popup at negative space and move it when required. This is to
		 * avoid the mouse exit issue on buttons.
		 */
		Platform.runLater(() -> monitorIndentifier.show(root.getScene().getWindow(), negSpace, negSpace));
		AtomicInteger i = new AtomicInteger(1);
		Screen.getScreens().forEach(screen -> {
			final Button button = new Button(i.getAndIncrement() + "");
			button.setOnMouseEntered(e -> {
				Rectangle2D screenBounds = screen.getVisualBounds();
				box.setWidth(screenBounds.getWidth() - (2 * borderWidth));
				box.setHeight(screenBounds.getHeight() - (2 * borderWidth));
				monitorIndentifier.setAnchorX(screenBounds.getMinX());
				monitorIndentifier.setAnchorY(screenBounds.getMinY());
				monitorIndentifier.setX(screenBounds.getMinX());
				monitorIndentifier.setY(screenBounds.getMinY());
			});
			button.setOnMouseExited(e -> {
				box.setWidth(8);
				box.setHeight(8);
				monitorIndentifier.setAnchorX(negSpace);
				monitorIndentifier.setAnchorY(negSpace);
			});
			button.setOnAction(e -> {
				try {
					ScreenshotStage s = new ScreenshotStage(screen, new URI("file:///C:/jhmi/Backup-3/"));
					s.show();
				} catch (URISyntaxException ex) {
					throw new RuntimeException(ex);
				}
			});
			monitorsBtnPane.getChildren().add(button);
		});
	}

	/**
	 * Filters the nodes matching with the provided condition and adds them to the
	 * provided list.
	 *
	 * @param item         tree item to check
	 * @param key          property key
	 * @param searchText   search key
	 * @param matchedItems list of filtered items
	 */
	private void filterNodes(final FxplorerTreeItem item, final String key, final String searchText,
			final List<FxplorerTreeItem> matchedItems) {
		if (item.getValue().isMatched(key, searchText)) {
			matchedItems.add(item);
		}
		item.getChildren().stream().map(child -> (FxplorerTreeItem) child)
				.forEach(child -> filterNodes(child, key, searchText, matchedItems));
	}

	/**
	 * Finds the index of the child in the provided tree item.
	 *
	 * @param treeItem    tree item
	 * @param childNodeId child node id
	 * @return index of the child node
	 */
	private int findChildIndex(final FxplorerTreeItem treeItem, final int childNodeId) {
		int index = 0;
		for (final TreeItem<TreeData> child : treeItem.getChildren()) {
			if (child.getValue().getUId() == childNodeId) {
				return index;
			}
			index++;
		}
		return -1;
	}

	/**
	 * Registers the preview details of the provided new tree item.
	 *
	 * @param prevItem old tree item
	 * @param newItem  new tree item
	 */
	private void registerPreviewNode(final TreeItem<TreeData> prevItem, final TreeItem<TreeData> newItem) {
		/* Remove the previous selection node from preview polling */
		if (prevItem != null) {
			final Details details = (Details) prevItem.getValue();
			final int windowId = treeView.getWindowId(details);
			if (windowId > -1) {
				previewNodeConsumer.accept(details.getVmId(), windowId, -1);
			}
		}

		/* Register the new selection node from preview polling */
		if (newItem != null) {
			final Details details = (Details) newItem.getValue();
			final int windowId = treeView.getWindowId(details);
			if (windowId > -1) {
				previewNodeConsumer.accept(details.getVmId(), windowId, details.getUId());
			}
		}
	}

	/**
	 * Updates the style sheets tab details based on the provided tree item.
	 *
	 * @param treeItem tree item
	 */
	private void updateStyleSheetsTab(final TreeItem<TreeData> treeItem) {
		styleSheetsTabContent.getItems().clear();
		if (treeItem != null) {
			final LinkedHashMap<String, List<String>> styleSheets = FxplorerTree.getStyleSheetHierarchy(treeItem);
			final List<String> reverseOrderedKeys = new ArrayList<>(styleSheets.keySet());
			Collections.reverse(reverseOrderedKeys);
			for (final String key : reverseOrderedKeys) {
				final List<String> list = styleSheets.get(key);
				styleSheetsTabContent.getItems().add("-" + key);
				list.forEach(url -> styleSheetsTabContent.getItems().add(url));
			}
		}
	}

	/**
	 * Filters the tree items based on the provided text.
	 * 
	 * @param text text to filter
	 * @return list of tree items
	 */
	private List<FxplorerTreeItem> filterTreeItems(String text) {
		final List<FxplorerTreeItem> matchedItems = new ArrayList<>();
		if (text.isEmpty() || !(text.startsWith(".") || text.startsWith("#") || text.contains(":"))) {
			return matchedItems;
		}

		String searchText = "";
		String key = "";
		if (text.startsWith(".")) {
			key = "styleClass";
			searchText = text.substring(1);
		} else if (text.startsWith("#")) {
			key = "id";
			searchText = text.substring(1);
		} else {
			key = text.substring(0, text.indexOf(":"));
			searchText = text.substring(text.indexOf(":") + 1);
		}

		if (searchText.isEmpty() || key.isEmpty()) {
			return matchedItems;
		}

		filterNodes((FxplorerTreeItem) treeView.getRoot(), key, searchText, matchedItems);
		return matchedItems;
	}
}
