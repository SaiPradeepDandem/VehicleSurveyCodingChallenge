package com.sai.javafx.fxplorer.connector;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Interface for communication to the remote application from the Fxplorer.
 */
public interface IRemoteApp extends Remote {

    /**
     * Confirms the remote application for the connection establishment and start the dispatcher.
     *
     * @throws RemoteException
     */
    void handShake() throws RemoteException;

    /**
     * Highlights the provided node in the remote application.
     *
     * @param windowId window id
     * @param nodeId node id
     * @throws RemoteException
     */
    void highlightNode(int windowId, int nodeId) throws RemoteException;

    /**
     * Removes the highlight of any node in the provided window.
     *
     * @param windowId window id
     * @throws RemoteException
     */
    void removeHighlight(int windowId) throws RemoteException;

    /**
     * Sets the identifier to block/enable the pop up hiding dispatching.
     *
     * @param blockHiding specifies to block/enable the pop up hiding dispatching
     * @throws RemoteException
     */
    void setBlockPopupHiding(boolean blockHiding) throws RemoteException;

    /**
     * Sets the current preview node in the server to the remote application. This is to update the preview
     * instantly if the updated node is in preview mode.
     *
     * @param windowId window id
     * @param nodeId node id
     * @throws RemoteException
     */
    void setPreviewNode(int windowId, int nodeId) throws RemoteException;

    /**
     * Specifies if a node to be highlighted on mouse over in the remote application and get selected in the tree
     * when clicked.
     *
     * @param selectNode {@code true} to select the node
     * @throws RemoteException
     */
    void setSelectNode(boolean selectNode) throws RemoteException;
}
