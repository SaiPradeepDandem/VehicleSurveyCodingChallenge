package com.sai.javafx.fxplorer.ui.valuenode;

import static com.sai.javafx.fxplorer.utils.Utils.px;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.values.BoundsValue;

import javafx.geometry.Bounds;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.HLineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.VLineTo;

/**
 * Specifies the bounds value.
 */
public final class BoundsValueNode implements ValueNode {

    /** Label to display the string value of bounds. */
    private final Label label = new Label();

    /** Layout to show the bounds details. */
    private final GridPane layout = new GridPane();

    /** Graphic to display the bounds. */
    private final StackPane graphic = new StackPane();

    /** Label to display the min values. */
    private final Label minLabel = new Label("(24, 235)");

    /** Label to display the max values. */
    private final Label maxLabel = new Label("(124, 335)");

    /** Label to display the width. */
    private final Label widthLabel = new Label("100px");

    /** Label to display the height. */
    private final Label heightLabel = new Label("100px");

    /**
     * Constructor.
     */
    public BoundsValueNode() {
        label.setMaxWidth(900);
        label.setWrapText(true);
        label.setMinHeight(Region.USE_PREF_SIZE);
        layout.addRow(0, label);

        graphic.getStyleClass().add("bounds-graphic");
        graphic.setAlignment(Pos.TOP_LEFT);
        final Group group = new Group(graphic);
        layout.addRow(1, group);
        GridPane.setMargin(group, new Insets(10, 0, 0, 10));

        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHgrow(Priority.ALWAYS);
        cc.setFillWidth(true);
        cc.setHalignment(HPos.LEFT);
        layout.getColumnConstraints().add(cc);

        buildGraphic();
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        label.getStyleClass().add("highlight");
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        final Bounds bounds = ((BoundsValue) propertyDetails.getValue()).getValue();
        label.setText(bounds.toString());
        widthLabel.setText(px(bounds.getWidth()));
        heightLabel.setText(px(bounds.getHeight()));
        minLabel.setText("(" + bounds.getMinX() + ", " + bounds.getMinY() + ")");
        maxLabel.setText("(" + bounds.getMaxX() + ", " + bounds.getMaxY() + ")");
    }

    /**
     * Builds the graphical representation of the bounds.
     */
    private void buildGraphic() {
        final Path axis = new Path();
        axis.getStyleClass().add("bounds-axis");
        axis.getElements().addAll(new MoveTo(0, 0), new HLineTo(300), new MoveTo(0, 0), new VLineTo(200));
        axis.setTranslateX(4.5);
        axis.setTranslateY(4.5);

        final Pane xArrow = new Pane();
        xArrow.getStyleClass().add("bounds-xarrow");
        final Group xGrp = new Group(xArrow);
        xGrp.setTranslateX(300);

        final Pane yArrow = new Pane();
        yArrow.getStyleClass().add("bounds-yarrow");
        final Group yGrp = new Group(yArrow);
        yGrp.setTranslateY(200);

        minLabel.setTranslateX(20);
        minLabel.setTranslateY(25);
        maxLabel.setTranslateX(220);
        maxLabel.setTranslateY(160);

        final Label xLabel = new Label("X");
        xLabel.getStyleClass().add("axis-label");
        xLabel.setTranslateX(285);
        xLabel.setTranslateY(10);
        final Label yLabel = new Label("Y");
        yLabel.getStyleClass().add("axis-label");
        yLabel.setTranslateX(15);
        yLabel.setTranslateY(175);

        final StackPane node = new StackPane(widthLabel, heightLabel);
        node.getStyleClass().add("bounds-node");
        node.setMinSize(200, 100);
        node.setMaxSize(200, 100);
        node.setTranslateX(50);
        node.setTranslateY(50);
        StackPane.setAlignment(widthLabel, Pos.TOP_CENTER);
        StackPane.setAlignment(heightLabel, Pos.CENTER_RIGHT);

        final Circle minDot = new Circle(4);
        minDot.getStyleClass().add("dot");
        minDot.setTranslateX(node.getTranslateX() - minDot.getRadius() + 1);
        minDot.setTranslateY(node.getTranslateY() - minDot.getRadius() + 1);

        final Circle maxDot = new Circle(4);
        maxDot.getStyleClass().add("dot");
        maxDot.setTranslateX(node.getTranslateX() + node.getMinWidth() - maxDot.getRadius() - 1);
        maxDot.setTranslateY(node.getTranslateY() + node.getMinHeight() - maxDot.getRadius() - 1);

        graphic.getChildren().addAll(axis, xGrp, yGrp, node, minDot, maxDot, minLabel, maxLabel, xLabel, yLabel);
    }
}
