package com.sai.javafx.fxplorer.app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.Consumer;
import java.util.logging.Logger;

import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;
import com.sun.tools.attach.spi.AttachProvider;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.ValueType;
import com.sai.javafx.fxplorer.ui.FxplorerWindow;
import com.sai.javafx.fxplorer.ui.valuenode.BackgroundValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.BorderValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.BoundsValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.ConstraintsValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.FontValueNode;
import com.sai.javafx.fxplorer.utils.MyScenicView;
import com.sai.javafx.fxplorer.values.BackgroundValue;
import com.sai.javafx.fxplorer.values.BorderValue;
import com.sai.javafx.fxplorer.values.BoundsValue;
import com.sai.javafx.fxplorer.values.NullValue;
import com.sai.javafx.fxplorer.values.StringValue;
import com.sai.javafx.fxplorer.widgets.SnapshotButton;

import javafx.application.Application;
import javafx.geometry.BoundingBox;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * Test class for developing widgets or implementation in the application.
 */
public final class AppLab extends Application {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(AppLab.class.getName());

    /**
     * Constructor.
     */
    public AppLab() {
        /* Empty */
    }

    /**
     * Main method.
     *
     * @param args
     */
    public static void main(final String[] args) {
        launch(args);
    }

    @Override
    public final void start(final Stage primaryStage) throws Exception {
        findVMs();
        final TabPane tabPane = new TabPane();
        final FxplorerWindow window = new FxplorerWindow(tabPane, 1100, 900);
        window.setTitle("Fxplorer - Lab");
        window.showWindow();
        MyScenicView.show(window.getScene());

        addTab("Bounds", tabPane, content -> buildBoundsNode(content));
        addTab("Font", tabPane, content -> buildFontNode(content));
        addTab("SplitMenu", tabPane, content -> buildSplitMenuButton(content));
        addTab("Background", tabPane, content -> buildBackgroundNode(content));
        addTab("Border", tabPane, content -> buildBorderNode(content));
        addTab("Constraints", tabPane, content -> buildConstraintsNode(content));
    }

    /**
     * Adds a tab to the provided tab pane and runs the consumer to build the inner node.
     *
     * @param text text of the tab
     * @param tabPane tab pane instance
     * @param consumer consumer to accept the content and set the child node
     */
    private void addTab(final String text, final TabPane tabPane, final Consumer<StackPane> consumer) {
        final StackPane content = new StackPane();
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_LEFT);
        consumer.accept(content);

        final ScrollPane sp = new ScrollPane();
        VBox.setVgrow(sp, Priority.ALWAYS);
        sp.setContent(content);
        sp.setFitToHeight(true);
        sp.setFitToWidth(true);

        final Tab tab = new Tab(text);
        tab.setClosable(false);
        tab.setContent(sp);
        tabPane.getTabs().add(tab);
    }

    /**
     * Builds the background node for a button and sets in the provided node.
     *
     * @param root node to which the background node to set
     */
    private void buildBackgroundNode(final StackPane root) {
        final BackgroundValueNode bgNode = new BackgroundValueNode();
        final Button button = new Button("Test");
        final String style = String.format(
                "-fx-background-image:url(\"%s\"), url(\"%s\");-fx-background-repeat:no-repeat;-fx-background-position: 0 0, 4 center;",
                getClass().getResource("/images/camera.png").toExternalForm(),
                getClass().getResource("/images/Gadget.png").toExternalForm());
        button.setStyle(style);
        button.backgroundProperty().addListener((obs, old, val) -> {
            if (val != null) {
                final BackgroundValue bgValue = new BackgroundValue(val);
                bgNode.setValue(new PropertyDetails("background", ValueType.BACKGROUND, bgValue));
            } else {
                bgNode.setValue(new PropertyDetails("background", ValueType.NULL, new NullValue()));
            }
        });
        final TextField tf = new TextField();
        final HBox row = new HBox(button, tf);
        row.setSpacing(10);

        final VBox pane = new VBox(row, bgNode.getNode());
        pane.setSpacing(10);
        pane.setPadding(new Insets(10));
        root.getChildren().add(pane);
    }

    /**
     * Builds the border node for a StackPane and sets in the provided node.
     *
     * @param root node to which the border node to set
     */
    private void buildBorderNode(final StackPane root) {
        final BorderValueNode borderNode = new BorderValueNode();
        final StackPane stackPane = new StackPane();
        stackPane.setMinSize(250, 100);
        stackPane.setMaxSize(250, 100);
        stackPane.borderProperty().addListener((obs, old, val) -> {
            if (val != null) {
                final BorderValue borderValue = new BorderValue(val);
                borderNode.setValue(new PropertyDetails("border", ValueType.BORDER, borderValue));
            } else {
                borderNode.setValue(new PropertyDetails("border", ValueType.NULL, new NullValue()));
            }
        });
        final String s = "-fx-border-width:1px, 1px, 2px;"
            + "-fx-border-color:red, grey, linear-gradient(to bottom, red, gray);"
            + "-fx-border-radius:5px, 8px, 8px;"
            + "-fx-border-insets:0px, 2px, 3px;"
            + "-fx-border-style:solid, segments(5, 5, 5, 5)  line-cap round, solid;"
            + "-fx-border-image-source:url(\""
            + getClass().getResource("/images/Gadget.png").toExternalForm()
            + "\");"
            + "-fx-border-image-slice:16 16 16 16 fill;"
            + "-fx-border-image-width:16 8 8 16;"
            + "-fx-border-image-insets:10px;"
            + "-fx-border-image-repeat:repeat;"
            + "-fx-background-color:orange;"
            + "-fx-background-radius:5px;";
        stackPane.setStyle(s);

        final VBox pane = new VBox(stackPane, borderNode.getNode());
        pane.setSpacing(10);
        pane.setPadding(new Insets(10));
        root.getChildren().add(pane);

    }

    /**
     * Builds the bounds node for a bounding box and sets in the provided node.
     *
     * @param root node to which the bounds node to set
     */
    private void buildBoundsNode(final StackPane root) {
        final BoundsValueNode valueNode = new BoundsValueNode();
        final BoundingBox bb = new BoundingBox(85, 35, 150, 200);
        final PropertyDetails propertyDetails =
                new PropertyDetails("layoutBounds", ValueType.BOUNDS, new BoundsValue(bb));
        valueNode.setValue(propertyDetails);
        root.getChildren().add(valueNode.getNode());
    }

    /**
     * Builds the constraints node for a GridPane and sets in the provided node.
     *
     * @param root node to which the constraints node to set
     */
    private void buildConstraintsNode(final StackPane content) {
        final GridPane grid = new GridPane();
        VBox.setVgrow(grid, Priority.ALWAYS);
        grid.setVgap(20);
        grid.setHgap(20);
        final ColumnConstraints cc0 = new ColumnConstraints();
        cc0.setMinWidth(200);
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHgrow(Priority.ALWAYS);
        cc.setFillWidth(true);
        grid.getColumnConstraints().addAll(cc0, cc);
        final RowConstraints erc = new RowConstraints();
        final RowConstraints rc = new RowConstraints();
        rc.setFillHeight(true);
        rc.setVgrow(Priority.ALWAYS);
        grid.getRowConstraints().addAll(erc, erc, erc, erc, rc);

        final ConstraintsValueNode colValNode = new ConstraintsValueNode();
        colValNode.setValue(new PropertyDetails(null, "columnConstraints", grid.getColumnConstraints()));

        final ConstraintsValueNode rowValNode = new ConstraintsValueNode();
        rowValNode.setValue(new PropertyDetails(null, "rowConstraints", grid.getRowConstraints()));

        final VBox pane = new VBox(colValNode.getNode(), rowValNode.getNode());
        pane.setSpacing(20);
        pane.setPadding(new Insets(20));
        content.getChildren().add(pane);
    }

    /**
     * Builds the font node for a font property and sets in the provided node.
     *
     * @param root node to which the font node to set
     */
    private void buildFontNode(final StackPane root) {
        final Font font = new Font("System Italic", 18.0);
        final FontValueNode valueNode = new FontValueNode();
        final PropertyDetails propertyDetails =
                new PropertyDetails("font", ValueType.STRING, new StringValue(font.toString()));
        valueNode.setValue(propertyDetails);
        root.getChildren().add(valueNode.getNode());
    }

    /**
     * Builds the split menu button and sets in the provided node.
     *
     * @param root node to which the split menu button node to set
     */
    private void buildSplitMenuButton(final StackPane root) {
        final SnapshotButton snapshotBtn = new SnapshotButton();
        snapshotBtn.setActionHandler(() -> LOGGER.info(() -> "Action executed !!"));

        final Button disable = new Button("Disable");
        disable.setOnAction(e -> snapshotBtn.update(true));
        root.getChildren().add(new HBox(snapshotBtn, disable));
    }

    /**
     * Finds all the VMs in the system.
     */
    private void findVMs() {
        final List<VirtualMachineDescriptor> machines = VirtualMachine.list();
        LOGGER.info(() -> "Number of running Java vms : " + machines.size());
        final List<AttachProvider> providers = AttachProvider.providers();
        LOGGER.info(() -> "Number of running Java providers : " + providers.size());

        final long currentPid = ProcessHandle.current().pid();
        LOGGER.info(() -> "Current PID : " + currentPid);
        LOGGER.info(() -> "\n");
        final List<Long> validVMs = new ArrayList<>();
        ProcessHandle.allProcesses().filter(p -> p.pid() != currentPid).forEach(p -> {
            p.info().command().filter(cmd -> cmd.endsWith("java.exe")).ifPresent(cmd -> {
                try {
                    LOGGER.info(() -> "Attaching...." + p.info().command());
                    final VirtualMachine vm = VirtualMachine.attach(p.pid() + "");
                    final Properties sysPropertiesMap = vm.getSystemProperties();
                    LOGGER.info(() -> "classVersion : " + sysPropertiesMap.get("java.class.version"));
                    LOGGER.info(() -> "fxVersion : " + sysPropertiesMap.get("javafx.version"));
                    LOGGER.info(() -> "Detaching...");
                    vm.detach();
                    validVMs.add(p.pid());
                } catch (final IOException e) {
                    LOGGER.severe(() -> "  IO Exception");
                } catch (final AttachNotSupportedException e) {
                    LOGGER.severe(() -> "  AttachNotSupportedException");
                }
            });
        });
        LOGGER.info(() -> "Valid VMs " + validVMs);
    }
}
