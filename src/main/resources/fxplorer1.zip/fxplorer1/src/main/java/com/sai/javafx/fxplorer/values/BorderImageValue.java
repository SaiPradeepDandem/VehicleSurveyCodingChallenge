package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BorderImage;
import javafx.scene.layout.BorderRepeat;

public class BorderImageValue implements Value, Serializable {

    private ImageValue image;

    private BorderWidthsValue widths;

    private InsetsValue insets;

    private BorderWidthsValue slices;

    private boolean filled;

    private BorderRepeat repeatX;

    private BorderRepeat repeatY;

    private BorderImageValue() {
        /* private for snapshot */
    }

    public BorderImageValue(final BorderImage bi) {
        image = new ImageValue(bi.getImage());
        widths = new BorderWidthsValue(bi.getWidths());
        insets = new InsetsValue(bi.getInsets());
        slices = new BorderWidthsValue(bi.getSlices());
        filled = bi.isFilled();
        repeatX = bi.getRepeatX();
        repeatY = bi.getRepeatY();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BorderImageValue that)) {
            return false;
        }
        return filled == that.filled
            && Objects.equals(image, that.image)
            && Objects.equals(widths, that.widths)
            && Objects.equals(insets, that.insets)
            && Objects.equals(slices, that.slices)
            && repeatX == that.repeatX
            && repeatY == that.repeatY;
    }

    @Override
    public BorderImage getValue() {
        return new BorderImage(image.getValue(), widths.getValue(), insets.getValue(), slices.getValue(), filled,
                               repeatX, repeatY);
    }

    @Override
    public int hashCode() {
        return Objects.hash(image, widths, insets, slices, filled, repeatX, repeatY);
    }

    @Override
    public BorderImageValue snapshot() {
        final BorderImageValue snapshot = new BorderImageValue();
        snapshot.image = image == null ? null : image.snapshot();
        snapshot.widths = widths == null ? null : widths.snapshot();
        snapshot.insets = insets == null ? null : insets.snapshot();
        snapshot.slices = slices == null ? null : slices.snapshot();
        snapshot.filled = filled;
        snapshot.repeatX = repeatX;
        snapshot.repeatY = repeatY;
        return snapshot;
    }

    @Override
    public String toString() {
        return "BorderImageValue{"
            +
            "image="
            + image
            +
            ", widths="
            + widths
            +
            ", insets="
            + insets
            +
            ", slices="
            + slices
            +
            ", filled="
            + filled
            +
            ", repeatX="
            + repeatX
            +
            ", repeatY="
            + repeatY
            +
            '}';
    }
}
