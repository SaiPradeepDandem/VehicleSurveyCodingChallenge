package com.sai.javafx.fxplorer.ui;

/**
 * Represents the theme of the application.
 */
public enum Theme {
    /** Specifies the light theme. */
    LIGHT,
    /** Specifies the dark theme. */
    DARK;
}
