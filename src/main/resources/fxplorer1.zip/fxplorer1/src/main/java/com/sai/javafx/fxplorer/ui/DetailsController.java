package com.sai.javafx.fxplorer.ui;

import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.values.ImageValue;

import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/**
 * Controller for the details layout.
 */
public class DetailsController {

    /** Pseudo class for dark background. */
    private static final PseudoClass DARK_PSEUDOCLASS = PseudoClass.getPseudoClass("dark");

    /** Pseudo class for showing the boundary. */
    private static final PseudoClass SHOW_PSEUDOCLASS = PseudoClass.getPseudoClass("show");

    @FXML
    private VBox detailsContainer;

    @FXML
    private TitledPane previewTP;

    @FXML
    private StackPane previewPane;

    @FXML
    private ImageView previewImageView;

    @FXML
    private Group imagePane;

    @FXML
    private StackPane boundaryPane;

    @FXML
    private Label previewLabel;

    @FXML
    private TitledPane fullPropertiesTP;

    @FXML
    private StackPane fullPropertiesPane;

    @FXML
    private TitledPane nodeDetailsTP;

    @FXML
    private StackPane nodeDetailsPane;

    @FXML
    private TitledPane backgroundTP;

    @FXML
    private StackPane backgroundPropertiesPane;

    @FXML
    private StackPane borderPropertiesPane;

    @FXML
    private HBox titleGraphicPane;

    @FXML
    private CheckBox boundaryCB;

    @FXML
    private CheckBox darkCB;

    @FXML
    private Button showBoundsBtn;

    @FXML
    private ScrollPane previewScrollPane;

    /** Layout controller instance. */
    private final LayoutController layoutController;

    /** Layout builder utility. */
    private LayoutBuilder layoutBuilder;

    /**
     * Constructor.
     *
     * @param layoutController layout controller instance
     */
    public DetailsController(final LayoutController layoutController) {
        this.layoutController = layoutController;
        load();
    }

    /**
     * Returns the titled pane of background.
     *
     * @return titledPane
     */
    public final TitledPane getBackgroundTP() {
        return backgroundTP;
    }

    /**
     * Returns the details container.
     *
     * @return container node
     */
    public final VBox getDetailsContainer() {
        return detailsContainer;
    }

    /**
     * Updates the layout with the new theme.
     *
     * @param theme new theme to update
     */
    public final void onThemeUpdate(final Theme theme) {
        darkCB.setSelected(theme == Theme.DARK);
    }

    /**
     * Displays the details in the layout.
     *
     * @param details details instance
     */
    public final void showDetails(final Details details) {
        Platform.runLater(() -> {
            if (layoutController != null) {
                showBoundsBtn.setVisible(details instanceof NodeDetails);
            }
            boolean hasPreview = false;
            if (details != null) {
                if (details instanceof final NodeDetails node && node.getPreview() != null) {
                    previewImageView.setImage(node.getPreview().getValue());
                    hasPreview = true;
                }
                displayProperties(details);
            } else {
                layoutBuilder.clearLayout();
            }
            imagePane.setVisible(hasPreview);
        });
    }

    /**
     * Updates the provided property in the layout.
     *
     * @param propDetails details instance
     */
    public final void updateProperty(final PropertyDetails propDetails) {
        if (propDetails.getName().equals("preview")) {
            Platform.runLater(() -> {
                imagePane.setVisible(true);
                previewImageView.setImage(((ImageValue) propDetails.getValue()).getValue());
            });
        } else {
            layoutBuilder.updateProperty(propDetails);
        }
    }

    @FXML
    final void initialize() {
        layoutBuilder = new LayoutBuilder(this);
        titleGraphicPane.minWidthProperty().bind(previewTP.widthProperty().subtract(20));
        boundaryCB.visibleProperty().bind(previewTP.expandedProperty());
        darkCB.visibleProperty().bind(boundaryCB.visibleProperty());
        boundaryCB.selectedProperty()
            .addListener((obs, old, show) -> boundaryPane.pseudoClassStateChanged(SHOW_PSEUDOCLASS, show));
        darkCB.selectedProperty()
            .addListener((obs, old, dark) -> previewPane.pseudoClassStateChanged(DARK_PSEUDOCLASS, dark));
        showBoundsBtn.managedProperty().bind(showBoundsBtn.visibleProperty());

        previewTP.managedProperty().bind(previewTP.visibleProperty());
        imagePane.managedProperty().bind(imagePane.visibleProperty());
        previewLabel.visibleProperty().bind(imagePane.visibleProperty().not());
        previewLabel.managedProperty().bind(previewLabel.visibleProperty());
        backgroundTP.managedProperty().bind(backgroundTP.visibleProperty());

        nodeDetailsPane.getChildren().add(layoutBuilder.getNodeDetailsLayout());
        borderPropertiesPane.getChildren().add(layoutBuilder.getBorderPropertiesLayout());
        backgroundPropertiesPane.getChildren().add(layoutBuilder.getBackgroundPropertiesLayout());
        fullPropertiesPane.getChildren().add(layoutBuilder.getFullPropertiesLayout());

        previewScrollPane.setMinHeight(Region.USE_PREF_SIZE);

        showBoundsBtn.setOnMousePressed(e -> layoutController.highlightNode());
        showBoundsBtn.setOnMouseReleased(e -> layoutController.removeHighlight());
    }

    /**
     * Displays the provided details.
     *
     * @param details details instance
     */
    private void displayProperties(final Details details) {
        layoutBuilder.displayProperties(details);
    }

    /**
     * Loads the details layout.
     */
    private void load() {
        try {
            final FXMLLoader loader = new FXMLLoader(getClass().getResource("details.fxml"));
            loader.setController(this);
            loader.load();
        } catch (final Exception e) {
            e.printStackTrace();
            throw new IllegalStateException("Unable to load the details fxml");
        }
    }
}
