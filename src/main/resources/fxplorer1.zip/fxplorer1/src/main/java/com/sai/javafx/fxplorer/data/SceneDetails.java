package com.sai.javafx.fxplorer.data;

import java.io.Serializable;

/**
 * Details object for the scene.
 */
public final class SceneDetails extends Details implements Serializable {

    /** Root node details. */
    private NodeDetails root;

    /**
     * Constructor.
     */
    public SceneDetails() {
        /* Empty */
    }

    @Override
    public final String getDisplayName() {
        return "@Scene - " + getUId();
    }

    /**
     * Returns the scene's root node details.
     *
     * @return root node details
     */
    public final NodeDetails getRoot() {
        return root;
    }

    @Override
    public final void reset() {
        super.reset();
        root.reset();
        /* Remove if any listener defined in this class */
    }

    /**
     * Sets the scene's root node details.
     *
     * @param root root node details
     */
    public final void setRoot(final NodeDetails root) {
        this.root = root;
    }

    @Override
    public final Details snapshot() {
        final SceneDetails snapshot = new SceneDetails();
        super.snapshot(snapshot);
        return snapshot;
    }
}
