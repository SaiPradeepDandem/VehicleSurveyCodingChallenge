package com.sai.javafx.fxplorer.ui.valuenode;

import static com.sai.javafx.fxplorer.utils.Utils.px;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.utils.ColorUtils;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TitledPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderImage;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.paint.RadialGradient;
import javafx.scene.text.Text;

/**
 * Specifies the border value.
 */
public final class BorderValueNode implements ValueNode {

    /** Layout to show the border details. */
    private final GridPane layout = new GridPane();

    /** Layout to show the border stroke details. */
    private final GridPane strokesGrid = new GridPane();

    /** Layout to show the border image details */
    private final GridPane imagesGrid = new GridPane();

    /** Layout to preview the border. */
    private final StackPane preview = new StackPane(new Label("Border Preview"));

    /** Label to represent the no border. */
    private final Label noBorderLabel = label("No border");

    /** Row constraint with top alignment. */
    private final RowConstraints topAlignRow = new RowConstraints();

    /** Row constraint with vgrow alignment. */
    private final RowConstraints vGrowAlignRow = new RowConstraints();

    /** Column constraint with center alignment. */
    private final ColumnConstraints centerAlignCol = new ColumnConstraints();

    /** Column constraint with center alignment. */
    private final ColumnConstraints hGrowCenterCol = new ColumnConstraints();

    /**
     * Constructor.
     */
    public BorderValueNode() {
        strokesGrid.setHgap(15);
        strokesGrid.setVgap(6);
        imagesGrid.setHgap(15);
        imagesGrid.setVgap(6);

        topAlignRow.setValignment(VPos.TOP);
        vGrowAlignRow.setVgrow(Priority.ALWAYS);
        vGrowAlignRow.setFillHeight(true);
        centerAlignCol.setHalignment(HPos.CENTER);
        hGrowCenterCol.setHgrow(Priority.ALWAYS);
        hGrowCenterCol.setFillWidth(true);
        hGrowCenterCol.setHalignment(HPos.CENTER);

        final ColumnConstraints cc = new ColumnConstraints();
        cc.setMinWidth(50);
        strokesGrid.getColumnConstraints().add(cc);
        imagesGrid.getColumnConstraints().add(cc);

        preview.setPrefSize(400, 150);
        preview.setMinHeight(150);

        layout.setVgap(10);
        layout.getChildren().add(noBorderLabel);
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        /* Empty block. */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        final Border border = (Border) propertyDetails.getValue().getValue();

        /* Reset layout and constraints */
        layout.getChildren().clear();
        strokesGrid.getChildren().clear();
        strokesGrid.getRowConstraints().clear();
        imagesGrid.getChildren().clear();
        imagesGrid.getRowConstraints().clear();

        /* If no border, then show the label and return */
        if (border == null) {
            layout.getChildren().add(noBorderLabel);
            return;
        }

        /* Set border to preview */
        preview.setBorder(border);
        layout.addRow(0, preview);

        /* Build strokes grid if exists */
        if (!border.getStrokes().isEmpty()) {
            layoutStorkesGrid(border);
        }

        /* Build images grid if exists */
        if (!border.getImages().isEmpty()) {
            layoutImagesGrid(border);
        }
    }

    /**
     * Builds a bold label with provided text.
     *
     * @param text text in label
     * @return label
     */
    private Label boldLabel(final String text) {
        final Label lbl = label(text);
        lbl.setStyle("-fx-font-weight:bold;");
        return lbl;
    }

    /**
     * Builds the grid layout for showing the Insets value with the provided label at the center.
     *
     * @param insets Insets to be shown
     * @param lbl Info label to be displayed at center
     * @return GridPane layout
     */
    private GridPane buildInsetsGrid(final Insets insets, final String lbl) {
        final Label lblText = label(lbl);
        lblText.setStyle("-fx-font-size:12px;-fx-fill:black");
        final GridPane insetGrid = new GridPane();
        insetGrid.setVgap(2);
        insetGrid.setHgap(2);
        insetGrid.addRow(0, new Label(), label(insets.getTop() + ""), new Label());
        insetGrid.addRow(1, label(insets.getLeft() + ""), lblText, label(insets.getRight() + ""));
        insetGrid.addRow(2, new Label(), label(insets.getBottom() + ""), new Label());
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.CENTER);
        insetGrid.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        return insetGrid;
    }

    /**
     * Builds the layout for displaying the corder radius details.
     *
     * @param radii Instance of CornerRadii
     * @return GridPane
     */
    private GridPane buildRadiiGrid(final CornerRadii radii) {
        final Label lblText = label("corner-radius");
        lblText.setStyle("-fx-font-size:12px;-fx-fill:black");
        final GridPane insetGrid = new GridPane();
        insetGrid.setVgap(2);
        insetGrid.setHgap(2);
        insetGrid
            .addRow(0, label(radii.getTopLeftHorizontalRadius() + ""), new Label(),
                    label(radii.getTopRightHorizontalRadius() + ""));
        insetGrid.addRow(1, new Label(), lblText, new Label());
        insetGrid
            .addRow(2, label(radii.getBottomLeftHorizontalRadius() + ""), new Label(),
                    label(radii.getBottomRightHorizontalRadius() + ""));
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.CENTER);
        insetGrid.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        return insetGrid;
    }

    /**
     * Builds the layout for the border strokes.
     *
     * @param stroke border stroke
     * @return layout for stroke styles
     */
    private TitledPane buildStyles(final BorderStroke stroke) {
        final BorderStrokeStyle top = stroke.getTopStyle();
        final BorderStrokeStyle right = stroke.getRightStyle();
        final BorderStrokeStyle bottom = stroke.getBottomStyle();
        final BorderStrokeStyle left = stroke.getLeftStyle();

        final GridPane styleGrid = new GridPane();
        styleGrid.setVgap(5);
        styleGrid.setHgap(10);
        styleGrid.addRow(0, new Text(), boldLabel("Top"), boldLabel("Right"), boldLabel("Bottom"),
                boldLabel("Left"));
        styleGrid.addRow(1, boldLabel("Type"), label(top.getType().name()), label(right.getType().name()),
                label(bottom.getType().name()), label(left.getType().name()));
        styleGrid.addRow(2, boldLabel("LineCap"), label(top.getLineCap().name()), label(right.getLineCap().name()),
                label(bottom.getLineCap().name()), label(left.getLineCap().name()));
        styleGrid.addRow(3, boldLabel("LineJoin"), label(top.getLineJoin().name()),
                label(right.getLineJoin().name()), label(bottom.getLineJoin().name()),
                label(left.getLineJoin().name()));
        styleGrid.addRow(4, boldLabel("MiterLimit"), label(top.getMiterLimit() + ""),
                label(right.getMiterLimit() + ""), label(bottom.getMiterLimit() + ""),
                label(left.getMiterLimit() + ""));
        styleGrid.addRow(5, boldLabel("DashOffset"), label(top.getDashOffset() + ""),
                label(right.getDashOffset() + ""), label(bottom.getDashOffset() + ""),
                label(left.getDashOffset() + ""));
        styleGrid.addRow(6, boldLabel("DashArray"), label(top.getDashArray().toString()),
                label(right.getDashArray().toString()), label(bottom.getDashArray().toString()),
                label(left.getDashArray().toString()));

        final ColumnConstraints cc = new ColumnConstraints();
        cc.setMinWidth(100);
        styleGrid.getColumnConstraints().addAll(cc, cc, cc, cc, cc);
        final TitledPane stylesTP = new TitledPane("Stroke Style", styleGrid);
        stylesTP.setExpanded(false);
        stylesTP.getStyleClass().add("stroke-style-titled-pane");
        return stylesTP;
    }

    /**
     * Builds a center aligned label with the provided text .
     *
     * @param text text
     * @return center aligned label
     */
    private Label centerLabel(final String text) {
        final Label lbl = paintLabel(text);
        lbl.setAlignment(Pos.CENTER);
        return lbl;
    }

    /**
     * Builds a label with the provided text .
     *
     * @param text text
     * @return label
     */
    private Label label(final String text) {
        final Label lbl = new Label(text);
        lbl.setMinWidth(Region.USE_PREF_SIZE);
        return lbl;
    }

    /**
     * Builds the layout for the border images.
     *
     * @param border border
     */
    private void layoutImagesGrid(final Border border) {
        int count = 0;
        int rowIndex = 0;
        for (final BorderImage image : border.getImages()) {
            final int firstRow = rowIndex++;
            final Label imageText = label("Image#" + count + ":");
            final ImageView imageView = new ImageView(image.getImage());
            imagesGrid.add(imageText, 0, firstRow);
            imagesGrid.add(imageView, 1, firstRow);

            final GridPane repeatGrid = new GridPane();
            repeatGrid.setVgap(5);
            repeatGrid.setHgap(5);
            repeatGrid.add(boldLabel("Repeat"), 0, 0, 2, 1);
            repeatGrid.addRow(1, label("repeatX:"), label(image.getRepeatX().name()));
            repeatGrid.addRow(2, label("repeatY:"), label(image.getRepeatX().name()));
            imagesGrid.add(repeatGrid, 2, firstRow);

            final GridPane insetsGrid = buildInsetsGrid(image.getInsets(), "insets");
            imagesGrid.add(insetsGrid, 3, firstRow);

            imagesGrid.add(new Separator(), 0, rowIndex++, 4, 1);
            imagesGrid.getRowConstraints().addAll(topAlignRow, topAlignRow);
            count++;
        }
        layout.addRow(2, imagesGrid);
    }

    /**
     * Builds the layout for the border strokes.
     *
     * @param border border
     */
    private void layoutStorkesGrid(final Border border) {
        int count = 0;
        int rowIndex = 0;
        for (final BorderStroke stroke : border.getStrokes()) {
            final Label strokeNoText = label("Stroke#" + count + ":");
            final Paint topStroke = stroke.getTopStroke();
            final Paint rightStroke = stroke.getRightStroke();
            final Paint bottomStroke = stroke.getBottomStroke();
            final Paint leftStroke = stroke.getLeftStroke();

            final double topWidth = stroke.getWidths().getTop();
            final double rightWidth = stroke.getWidths().getRight();
            final double bottomWidth = stroke.getWidths().getBottom();
            final double leftWidth = stroke.getWidths().getLeft();

            final GridPane strokeBox = new GridPane();
            strokeBox.setMinSize(250, 75);
            strokeBox.setMaxSize(250, 75);
            strokeBox.setPadding(new Insets(3));
            strokeBox.setBorder(new Border(stroke));
            strokeBox.add(label(px(topWidth)), 1, 0);
            strokeBox.add(label(px(leftWidth)), 0, 1);
            strokeBox.add(label(px(rightWidth)), 2, 1);
            strokeBox.add(label(px(bottomWidth)), 1, 2);
            strokeBox.getColumnConstraints().addAll(new ColumnConstraints(), hGrowCenterCol);
            strokeBox.getRowConstraints().addAll(new RowConstraints(), vGrowAlignRow);

            final GridPane grid = new GridPane();
            grid.setHgap(6);
            grid.setVgap(3);
            grid.addRow(0, new Text(), centerLabel(paintToStr(topStroke)), new Text());
            grid.addRow(1, rightLabel(paintToStr(leftStroke)), strokeBox, leftLabel(paintToStr(rightStroke)));
            grid.addRow(2, new Text(), centerLabel(paintToStr(bottomStroke)), new Text());
            grid.getColumnConstraints().addAll(new ColumnConstraints(), centerAlignCol);

            final int firstRow = rowIndex++;
            strokesGrid.add(strokeNoText, 0, firstRow);
            strokesGrid.add(grid, 1, firstRow);
            strokesGrid.add(buildInsetsGrid(stroke.getInsets(), "insets"), 2, firstRow);
            strokesGrid.add(buildRadiiGrid(stroke.getRadii()), 3, firstRow);

            final TitledPane styleTP = buildStyles(stroke);
            strokesGrid.add(styleTP, 1, rowIndex++, 3, 1);

            strokesGrid.add(new Separator(), 0, rowIndex++, 4, 1);
            strokesGrid.getRowConstraints().addAll(topAlignRow, topAlignRow, topAlignRow);
            count++;
        }
        layout.addRow(1, strokesGrid);
    }

    /**
     * Builds a left aligned label with the provided text .
     *
     * @param text text
     * @return left aligned label
     */
    private Label leftLabel(final String text) {
        final Label lbl = paintLabel(text);
        lbl.setAlignment(Pos.CENTER_LEFT);
        return lbl;
    }

    /**
     * Builds a label with the provided text .
     *
     * @param text text
     * @return label
     */
    private Label paintLabel(final String text) {
        final Label lbl = new Label(text);
        lbl.setWrapText(true);
        lbl.setMaxWidth(200);
        lbl.setMinWidth(200);
        lbl.setMinHeight(Region.USE_PREF_SIZE);
        return lbl;
    }

    /**
     * Converts the provided paint instance to the string value.
     *
     * @param paint paint instance
     * @return
     */
    private String paintToStr(final Paint paint) {
        if (paint instanceof LinearGradient || paint instanceof RadialGradient) {
            return paint.toString().replaceAll("0x", "#");
        } else if (paint instanceof Color) {
            final String hexColor = ColorUtils.getHexColor(paint);
            final String rgbaColor = ColorUtils.getRGBAColor(paint);
            return rgbaColor + "\nHex : " + hexColor;
        }
        return paint.toString();
    }

    /**
     * Builds a right aligned label with the provided text .
     *
     * @param text text
     * @return right aligned label
     */
    private Label rightLabel(final String text) {
        final Label lbl = paintLabel(text);
        lbl.setAlignment(Pos.CENTER_RIGHT);
        return lbl;
    }
}
