package com.sai.javafx.fxplorer.utils;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.sai.javafx.fxplorer.data.NodeDetails;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.image.Image;

/**
 * Common utility class.
 */
public class Utils {

    /** A dummy class name for VM. */
    public static String VM_CLASS_NAME = "Java";

    /** A dummy class name for window. */
    public static String WINDOW_CLASS_NAME = "Stage";

    /** URL string for custom node image. */
    private static String CUSTOM_NODE_IMAGE;

    /** Cache for all loaded images. */
    private static final Map<String, Image> loadedImages = new HashMap<>();

    /** Cache for all class names. */
    private static final Map<Class<?>, String> classNames = new ConcurrentHashMap<>();

    /**
     * Finds a node with the provided id in the given node/parent.
     *
     * @param node node in which the search to be performed
     * @param nodeId id of the node
     * @return matched node
     */
    public static Node findNode(final Node node, final int nodeId) {
        if (node.hashCode() == nodeId) {
            return node;
        }

        if (node instanceof final Parent parent) {
            for (final Node child : parent.getChildrenUnmodifiable()) {
                final Node n = findNode(child, nodeId);
                if (n != null) {
                    return n;
                }
            }
        }
        return null;
    }

    /**
     * Returns the list of all application icons of different sizes.
     *
     * @return list of icons
     */
    public static List<Image> getAppIcons() {
        final List<Image> images = new ArrayList<>();
        images.add(new Image(Utils.class.getResourceAsStream("/images/tree_explorer.png")));
        return images;
    }

    /**
     * Returns the corresponding icon for the provided class name.
     *
     * @param className class name
     * @return Image
     */
    public static Image getIcon(final String className) {
        Image image = loadedImages.get(className);
        if (image == null) {
            final URL resource = Utils.getNodeIcon(className);
            String url;
            if (resource != null) {
                url = resource.toString();
            } else {
                url = getCustomImage();
            }
            image = new Image(url);
            loadedImages.put(className, image);
        }
        return image;
    }

    /**
     * Returns the class name of the provided object.
     *
     * @param node node object
     * @return class name
     */
    public static String nodeClass(final Object node) {
        final String value = classNames.get(node.getClass());
        if (value == null) {
            @SuppressWarnings("rawtypes")
            Class cls = node.getClass();
            String name = cls.getSimpleName();
            while (name.isEmpty() || name.contains("anon$")) {
                cls = cls.getSuperclass();
                name = cls.getSimpleName();
            }
            classNames.put(node.getClass(), name);
            return name;
        }
        return value;
    }

    /**
     * Builds the display string of the provided node details.
     *
     * @param node node details
     * @param showId specifies whether to include id in the display string or not
     * @return display string
     */
    public static String nodeDisplay(final NodeDetails node, final boolean showId) {
        return node.getClassName() + (showId && node.getFxId() != null ? " \"" + node.getFxId() + "\"" : "");
    }

    /**
     * Returns the provided value in string format by appending "px" unit.
     *
     * @param value value
     * @return string value
     */
    public static String px(final double value) {
        return value + "px";
    }

    /**
     * Returns the custom node image URL string.
     *
     * @return image URL string
     */
    private static String getCustomImage() {
        if (CUSTOM_NODE_IMAGE == null) {
            CUSTOM_NODE_IMAGE = Utils.getNodeIcon("CustomNode").toString();
        }
        return CUSTOM_NODE_IMAGE;
    }

    /**
     * Gets the appropriate icon for the given node.
     *
     * @param node node name
     * @return image url
     */
    private static URL getNodeIcon(final String node) {
        return Utils.class.getResource("/images/" + node + ".png");
    }
}
