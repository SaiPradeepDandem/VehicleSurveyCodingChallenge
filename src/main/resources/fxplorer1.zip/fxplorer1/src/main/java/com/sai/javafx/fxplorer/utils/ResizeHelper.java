package com.sai.javafx.fxplorer.utils;

import com.sai.javafx.fxplorer.ui.FxplorerWindow;

import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;

/**
 * Helper class to set the resizing implementation for any given undecorated stage.
 */
public final class ResizeHelper {

    /**
     * Handler to process the resizing of the given stage.
     */
    static final class ResizeHandler implements EventHandler<MouseEvent> {

        private final FxplorerWindow fxplorerWindow;

        /**
         * Current cursor reference to the scene
         */
        private Cursor cursor = Cursor.DEFAULT;

        /**
         * X position of the drag start
         */
        private double startX = 0;

        /**
         * Y position of the drag start
         */
        private double startY = 0;

        /**
         * Constructor.
         *
         * @param fxplorerWindow FxplorerWindow to which resizing to be set.
         */
        ResizeHandler(final FxplorerWindow fxplorerWindow) {
            this.fxplorerWindow = fxplorerWindow;
        }

        @Override
        public final void handle(final MouseEvent event) {
            final boolean canDrag = fxplorerWindow.canDrag(event);
            final EventType<? extends MouseEvent> eventType = event.getEventType();
            final Scene scene = fxplorerWindow.getScene();
            final double mouseEventX = event.getSceneX();
            final double mouseEventY = event.getSceneY();
            final double sceneWidth = scene.getWidth();
            final double sceneHeight = scene.getHeight();

            if (MouseEvent.MOUSE_MOVED.equals(eventType)
                &&
                fxplorerWindow.getCurrentWindowState() != FxplorerWindow.WindowState.MAXIMIZED) {
                assignCursor(scene, event, mouseEventX, mouseEventY, sceneWidth, sceneHeight);

            } else if (MouseEvent.MOUSE_PRESSED.equals(eventType) && canDrag) {
                startX = fxplorerWindow.getWidth() - mouseEventX;
                startY = fxplorerWindow.getHeight() - mouseEventY;
                consumeEventIfNotDefaultCursor(event);

            } else if (MouseEvent.MOUSE_DRAGGED.equals(eventType) && !Cursor.DEFAULT.equals(cursor) && canDrag) {
                consumeEventIfNotDefaultCursor(event);
                if (!Cursor.W_RESIZE.equals(cursor) && !Cursor.E_RESIZE.equals(cursor)) {
                    handleHeightResize(event);
                }

                if (!Cursor.N_RESIZE.equals(cursor) && !Cursor.S_RESIZE.equals(cursor)) {
                    handleWidthResize(event);
                }
            }
        }

        /**
         * Determines and sets the appropriate cursor based on the mouse position in relative to scene bounds.
         *
         * @param scene FxplorerWindow scene
         * @param event MouseEvent instance
         * @param mouseEventX X position of mouse in the scene
         * @param mouseEventY Y position of mouse in the scene
         * @param sceneWidth Width of the scene
         * @param sceneHeight Height of the scene
         */
        private void assignCursor(final Scene scene, final MouseEvent event, final double mouseEventX,
                final double mouseEventY, final double sceneWidth, final double sceneHeight) {
            final Cursor cursor1;

            if (mouseEventX < DRAG_AREA && mouseEventY < DRAG_AREA) {
                cursor1 = Cursor.NW_RESIZE;
            } else if (mouseEventX < DRAG_AREA && mouseEventY > sceneHeight - DRAG_AREA) {
                cursor1 = Cursor.SW_RESIZE;
            } else if (mouseEventX > sceneWidth - DRAG_AREA
                && mouseEventY < DRAG_AREA
                && !fxplorerWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.NE_RESIZE;
            } else if (mouseEventX > sceneWidth - DRAG_AREA && mouseEventY > sceneHeight - DRAG_AREA) {
                cursor1 = Cursor.SE_RESIZE;
            } else if (mouseEventX < DRAG_AREA) {
                cursor1 = Cursor.W_RESIZE;
            } else if (mouseEventX > sceneWidth - DRAG_AREA && !fxplorerWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.E_RESIZE;
            } else if (mouseEventY < DRAG_AREA && !fxplorerWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.N_RESIZE;
            } else if (mouseEventY > sceneHeight - DRAG_AREA) {
                cursor1 = Cursor.S_RESIZE;
            } else {
                cursor1 = Cursor.DEFAULT;
            }
            cursor = cursor1;
            scene.setCursor(cursor);
        }

        /**
         * Consumes the mouse event if the cursor is not the DEFAULT cursor.
         *
         * @param event MouseEvent instance
         */
        private void consumeEventIfNotDefaultCursor(final MouseEvent event) {
            if (!cursor.equals(Cursor.DEFAULT)) {
                event.consume();
            }
        }

        /**
         * Processes the vertical drag movement and resizes the window height.
         *
         * @param event MouseEvent instance
         */
        private void handleHeightResize(final MouseEvent event) {
            final double mouseEventY = event.getSceneY();
            final double minHeight = fxplorerWindow.getWindowTitleBar().prefHeight(Region.USE_COMPUTED_SIZE);
            if (Cursor.NW_RESIZE.equals(cursor)
                || Cursor.N_RESIZE.equals(cursor)
                || Cursor.NE_RESIZE.equals(cursor)) {
                if (fxplorerWindow.getHeight() > minHeight || mouseEventY < 0) {
                    final double newHeight = fxplorerWindow.getY()
                        - event.getScreenY()
                        + fxplorerWindow.getHeight()
                        + SHADOW_AREA;
                    fxplorerWindow.setHeight(max(newHeight, minHeight));
                    fxplorerWindow.setY(event.getScreenY() - SHADOW_AREA);
                }
            } else if (fxplorerWindow.getHeight() > minHeight
                || mouseEventY + startY - fxplorerWindow.getHeight() > 0) {
                final double newHeight = mouseEventY + startY;
                fxplorerWindow.setHeight(max(newHeight, minHeight));
            }
        }

        /**
         * Processes the horizontal drag movement and resizes the window width.
         *
         * @param event MouseEvent instance
         */
        private void handleWidthResize(final MouseEvent event) {
            final double mouseEventX = event.getSceneX();
            final double minWidth = fxplorerWindow.getButtonPane().prefWidth(Region.USE_COMPUTED_SIZE);
            if (Cursor.NW_RESIZE.equals(cursor)
                || Cursor.W_RESIZE.equals(cursor)
                || Cursor.SW_RESIZE.equals(cursor)) {
                if (fxplorerWindow.getWidth() > minWidth || mouseEventX < 0) {
                    final double newWidth = fxplorerWindow.getX()
                        - event.getScreenX()
                        + fxplorerWindow.getWidth()
                        + SHADOW_AREA;
                    fxplorerWindow.setWidth(max(newWidth, minWidth));
                    fxplorerWindow.setX(event.getScreenX() - SHADOW_AREA);
                }
            } else if (fxplorerWindow.getWidth() > minWidth
                || mouseEventX + startX - fxplorerWindow.getWidth() > 0) {
                final double newWidth = mouseEventX + startX;
                fxplorerWindow.setWidth(max(newWidth, minWidth));
            }
        }

        /**
         * Determines the max value among the provided two values.
         *
         * @param value1 First value
         * @param value2 Second value
         * @return Maximum value of the given two values.
         */
        private double max(final double value1, final double value2) {
            return value1 > value2 ? value1 : value2;
        }
    }

    /**
     * Space to consider around the stage for shadow
     */
    public static final double SHADOW_AREA = 20;

    /**
     * Space to consider around the stage border for resizing
     */
    private static final double DRAG_AREA = SHADOW_AREA + 2;

    /**
     * Reference to the earlier handler to remove if required
     */
    private static ResizeHandler resizeHandler = null;

    /**
     * Constructor.
     */
    private ResizeHelper() {
        /* Empty block. */
    }

    /**
     * Adds the resize handler to the provided stage.
     *
     * @param window FxplorerWindow to which the resizing should be implemented
     */
    public static void addResizeHandler(final FxplorerWindow window) {
        resizeHandler = new ResizeHandler(window);
        window.getScene().addEventFilter(MouseEvent.ANY, resizeHandler);
    }
}
