package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.geometry.Side;
import javafx.scene.layout.BackgroundPosition;

public class BackgroundPositionValue implements Value, Serializable {

    private Side horizontalSide;

    private Side verticalSide;

    private double horizontalPosition;

    private double verticalPosition;

    private boolean horizontalPercent;

    private boolean verticalPercent;

    private BackgroundPositionValue() {
        /* private for snapshot */
    }

    public BackgroundPositionValue(final BackgroundPosition bp) {
        horizontalSide = bp.getHorizontalSide();
        horizontalPosition = bp.getHorizontalPosition();
        horizontalPercent = bp.isHorizontalAsPercentage();
        verticalSide = bp.getVerticalSide();
        verticalPosition = bp.getVerticalPosition();
        verticalPercent = bp.isVerticalAsPercentage();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BackgroundPositionValue that)) {
            return false;
        }
        return Double.compare(that.horizontalPosition, horizontalPosition) == 0
            && Double.compare(that.verticalPosition, verticalPosition) == 0
            && horizontalPercent == that.horizontalPercent
            && verticalPercent == that.verticalPercent
            && horizontalSide == that.horizontalSide
            && verticalSide == that.verticalSide;
    }

    @Override
    public BackgroundPosition getValue() {
        return new BackgroundPosition(horizontalSide, horizontalPosition, horizontalPercent,
                                      verticalSide, verticalPosition, verticalPercent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(horizontalSide, verticalSide, horizontalPosition, verticalPosition, horizontalPercent,
                verticalPercent);
    }

    @Override
    public BackgroundPositionValue snapshot() {
        final BackgroundPositionValue snapshot = new BackgroundPositionValue();
        snapshot.horizontalSide = horizontalSide;
        snapshot.horizontalPosition = horizontalPosition;
        snapshot.horizontalPercent = horizontalPercent;
        snapshot.verticalSide = verticalSide;
        snapshot.verticalPosition = verticalPosition;
        snapshot.verticalPercent = verticalPercent;
        return snapshot;
    }

    @Override
    public String toString() {
        return "BackgroundPositionValue{"
            +
            "horizontalSide="
            + horizontalSide
            +
            ", verticalSide="
            + verticalSide
            +
            ", horizontalPosition="
            + horizontalPosition
            +
            ", verticalPosition="
            + verticalPosition
            +
            ", horizontalPercent="
            + horizontalPercent
            +
            ", verticalPercent="
            + verticalPercent
            +
            '}';
    }
}
