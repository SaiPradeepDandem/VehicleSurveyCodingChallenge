package com.sai.javafx.fxplorer.data;

import java.io.Serializable;
import java.util.Map;

import com.sai.javafx.fxplorer.utils.Utils;

import javafx.event.EventDispatcher;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import javafx.util.Pair;

/**
 * Details object for the window.
 */
public final class WindowDetails extends Details implements Serializable {

    /** UID. */
    private static final long serialVersionUID = -2556951288718105815L;

    /** Title of the window. */
    private String title;

    /** Scene details of the window. */
    private SceneDetails scene;

    /** Specifies if the window is a popup or not. */
    private boolean popup;

    /** Actual window object instance. */
    private transient Window window;

    /** Original event dispatcher of the window. */
    private transient EventDispatcher origEventDispatcher;

    /** Pressed event handler of the window. */
    private transient EventHandler<MouseEvent> pressedHandler;

    /** Moved event handler of the window. */
    private transient EventHandler<MouseEvent> movedHandler;

    /** Exit event handler of the window. */
    private transient EventHandler<MouseEvent> exitHandler;

    /** Hide event handler of the window. */
    private transient EventHandler<WindowEvent> hideHandler;

    /**
     * Constructor.
     *
     * @param w window instance
     */
    public WindowDetails(final Window w) {
        window = w;
    }

    /**
     * Constructor.
     */
    private WindowDetails() {
        /* private for snapshot */
    }

    @Override
    public final void compare(final Details other,
            final Map<String, Pair<PropertyDetails, PropertyDetails>> result) {
        /* Empty block. */
    }

    @Override
    public final String getClassName() {
        return Utils.WINDOW_CLASS_NAME;
    }

    @Override
    public final String getDisplayName() {
        return title;
    }

    /**
     * Returns the scene details of the window.
     *
     * @return scene details of the window
     */
    public final SceneDetails getScene() {
        return scene;
    }

    /**
     * Returns the title of the window.
     *
     * @return title of the window
     */
    public final String getTitle() {
        return title;
    }

    /**
     * Returns the window instance.
     *
     * @return window instance
     */
    public final Window getWindow() {
        return window;
    }

    @Override
    public final boolean isPopup() {
        return popup;
    }

    @Override
    public final void reset() {
        super.reset();
        if (origEventDispatcher != null) {
            window.setEventDispatcher(origEventDispatcher);
        }
        final Scene fxScene = window.getScene();
        fxScene.removeEventFilter(MouseEvent.MOUSE_PRESSED, pressedHandler);
        fxScene.removeEventFilter(MouseEvent.MOUSE_MOVED, movedHandler);
        fxScene.removeEventFilter(MouseEvent.MOUSE_EXITED, exitHandler);
        window.removeEventFilter(WindowEvent.WINDOW_HIDING, hideHandler);
        pressedHandler = null;
        movedHandler = null;
        exitHandler = null;
        hideHandler = null;

        scene.reset();
    }

    /**
     * Sets the exit handler of the window.
     *
     * @param exitHandler exit handler
     */
    public final void setExitHandler(final EventHandler<MouseEvent> exitHandler) {
        this.exitHandler = exitHandler;
        window.getScene().addEventFilter(MouseEvent.MOUSE_EXITED, exitHandler);
    }

    /**
     * Sets the hide handler of the window.
     *
     * @param hideHandler hide handler
     */
    public final void setHideHandler(final EventHandler<WindowEvent> hideHandler) {
        this.hideHandler = hideHandler;
        window.addEventFilter(WindowEvent.WINDOW_HIDING, hideHandler);
    }

    /**
     * Sets the moved handler of the window.
     *
     * @param movedHandler moved handler
     */
    public final void setMovedHandler(final EventHandler<MouseEvent> movedHandler) {
        this.movedHandler = movedHandler;
        window.getScene().addEventFilter(MouseEvent.MOUSE_MOVED, movedHandler);
    }

    /**
     * Sets the original event dispatcher of the window.
     *
     * @param origEventDispatcher event dispatcher
     */
    public final void setOrigEventDispatcher(final EventDispatcher origEventDispatcher) {
        this.origEventDispatcher = origEventDispatcher;
    }

    @Override
    public final void setPopup(final boolean popup) {
        this.popup = popup;
    }

    /**
     * Sets the pressed handler of the window.
     *
     * @param pressedHandler pressed handler
     */
    public final void setPressedHandler(final EventHandler<MouseEvent> pressedHandler) {
        this.pressedHandler = pressedHandler;
        window.getScene().addEventFilter(MouseEvent.MOUSE_PRESSED, pressedHandler);
    }

    /**
     * Sets the scene details of the window.
     *
     * @param scene scene details
     */
    public final void setScene(final SceneDetails scene) {
        this.scene = scene;
    }

    /**
     * Sets the title of the window.
     *
     * @param title title of the window
     */
    public final void setTitle(final String title) {
        this.title = title;
    }

    @Override
    public final WindowDetails snapshot() {
        final WindowDetails snapshot = new WindowDetails();
        super.snapshot(snapshot);
        snapshot.title = title;
        snapshot.popup = popup;
        return snapshot;
    }
}
