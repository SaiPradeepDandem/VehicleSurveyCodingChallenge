package com.sai.javafx.fxplorer.ui;

import com.sai.javafx.fxplorer.data.TreeData;
import com.sai.javafx.fxplorer.utils.Utils;

import javafx.scene.control.Label;
import javafx.scene.control.TreeCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;

/**
 * Tree cell implementation for the fxplorer tree.
 */
public final class FxplorerTreeCell extends TreeCell<TreeData> {

    /** Label in the tree cell. */
    private final Label label;

    /** Icon for the tree cell. */
    private final ImageView imageView;

    /**
     * Constructor.
     */
    public FxplorerTreeCell() {
        label = new Label();
        imageView = new ImageView();
        imageView.setFitHeight(16);
        imageView.setFitWidth(16);
        final StackPane imagePane = new StackPane(imageView);
        label.setGraphic(imagePane);
    }

    @Override
    protected final void updateItem(final TreeData item, final boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        label.getStyleClass().removeAll("vm-label", "window-label", "no-title-label");
        if (item != null && !empty) {
            imageView.setImage(Utils.getIcon(item.getClassName()));
            label.setText(getDisplayText(item));
            applyStyle(item);
            setGraphic(label);
        } else {
            setGraphic(null);
        }
    }

    /**
     * Applies the appropriate style class based on the provided item class name.
     *
     * @param item tree item
     */
    private void applyStyle(final TreeData item) {
        if (Utils.VM_CLASS_NAME.equals(item.getClassName())) {
            label.getStyleClass().add("vm-label");
        } else if (Utils.WINDOW_CLASS_NAME.equals(item.getClassName())) {
            label.getStyleClass().add("window-label");
        }
    }

    /**
     * Returns the display text of the provided tree item.
     *
     * @param item tree item
     * @return text to display
     */
    private String getDisplayText(final TreeData item) {
        String text = item.getDisplayName();
        if (text == null || text.isEmpty()) {
            if (Utils.WINDOW_CLASS_NAME.equals(item.getClassName())) {
                text = "No Title";
                label.getStyleClass().add("no-title-label");
            }
        }
        return text;
    }
}
