package com.sai.javafx.fxplorer.connector;

import java.rmi.AccessException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.ValueType;
import com.sai.javafx.fxplorer.data.WindowDetails;
import com.sai.javafx.fxplorer.utils.ImageUtils;
import com.sai.javafx.fxplorer.values.ImageValue;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;

/**
 * Dispatcher thread class for remote application to communicate with server.
 */
public final class Dispatcher extends Thread implements IFxplorer {

    /**
     * Event to dispatch the property updates of a node to the server.
     */
    private class PropertyEvent {

        /**
         * Specifies the property details.
         */
        private final String desc;

        /**
         * Event to dispatch in the queue.
         */
        private final Runnable event;

        /**
         *
         * Constructor.
         *
         * @param runnable Event to dispatch in the queue
         * @param aDesc property details
         */
        public PropertyEvent(final Runnable runnable, final String aDesc) {
            desc = aDesc;
            event = runnable;
        }

        @Override
        public final String toString() {
            return desc;
        }
    }

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(Dispatcher.class.getName());

    /** Port number for the remote application. */
    private final int port;

    /** Interface to communication with server. */
    private final IFxplorer fxplorer;

    /** Interface implementation that receives communication from server. */
    private final RemoteAppImpl remoteAgent;

    /** List of property events to execute. */
    private final List<PropertyEvent> propertyEvents = new LinkedList<>();

    /** Map of preview events to execute. */
    private final Map<String, Runnable> previewEvents = new LinkedHashMap<>();

    /** Specifies the current running state of the remote application. */
    private boolean running = true;

    /**
     * Constructor.
     *
     * @param port port number of the remote application
     * @param fxplorer interface to communication with server
     * @param remoteAgent interface implementation that receives communication from server
     */
    public Dispatcher(final int port, final IFxplorer fxplorer,
            final RemoteAppImpl remoteAgent) {
        this.port = port;
        this.fxplorer = fxplorer;
        this.remoteAgent = remoteAgent;
        setDaemon(true);
    }

    /**
     * Clears the list of preview events. This will prevent dispatching all the preview events in the list.
     */
    public final void clearPreviewEvents() {
        synchronized (previewEvents) {
            previewEvents.clear();
        }
    }

    @Override
    public final void close() {
        try {
            synchronized (propertyEvents) {
                propertyEvents.clear();
            }
            clearPreviewEvents();
            remoteAgent.removeListeners();
            RMIUtils.unbindApplication(port);
            UnicastRemoteObject.unexportObject(remoteAgent, true);
            running = false;
            LOGGER.info(() -> "Closed Fxplorer connection and cleared all listeners !!");
        } catch (final NoSuchObjectException e) {
            LOGGER.severe(() -> "Connection already closed");
        } catch (final AccessException e) {
            LOGGER.severe(() -> "AccessException when closing ::");
            e.printStackTrace();
        } catch (final RemoteException e) {
            LOGGER.severe(() -> "RemoteException when closing ::");
            e.printStackTrace();
        }
    }

    @Override
    public final void dispatchChildrenUpdate(final int appId, final int windowId, final NodeDetails nodeDetails) {
        try {
            fxplorer.dispatchChildrenUpdate(appId, windowId, nodeDetails);
        } catch (final RemoteException e) {
            LOGGER.severe(() -> "RemoteException thrown in dispatchWindow ::");
            e.printStackTrace();
            close();
        }
    }

    /**
     * Dispatches the preview of the node in the popup.
     *
     * @param appId application id
     * @param windowId window id
     * @param node node to be dispatched
     */
    public final void dispatchPopupPreview(final int appId, final int windowId, final Node node) {
        LOGGER.info(() -> "Dispatching popup preview....");
        dispatchPreview(appId, windowId, true, node);
        if (node instanceof final Parent p) {
            p.getChildrenUnmodifiable().forEach(child -> dispatchPopupPreview(appId, windowId, child));
        }
    }

    /**
     * Dispatch the preview of the node.
     *
     * @param appId application id
     * @param windowId window id
     * @param force forces to dispatch irrespective of the current selected node
     * @param node node whose preview needs to be dispatched
     */
    public final void dispatchPreview(final int appId, final int windowId, final boolean force, final Node node) {
        /*
         * Not registering the preview event if there is no nodeId set or the current node is not the registered
         * one.
         */
        if (!force
            && (remoteAgent.getPreviewNodeId() == -1 || remoteAgent.getPreviewNodeId() != node.hashCode())) {
            return;
        }
        final String key = String.format("%s-%s-%s", appId + "", windowId + "", node.hashCode() + "");
        /* Queuing the preview events to send to fxplorer. */
        synchronized (previewEvents) {
            LOGGER.fine(() -> "Registering preview event : " + key);
            final Runnable runnable = () -> {
                Platform.runLater(() -> {
                    try {
                        fxplorer.dispatchPropertyDetail(appId, windowId, node.hashCode(),
                                buildPreviewDetails(node));
                    } catch (final RemoteException e) {
                        LOGGER.severe(() -> "RemoteException thrown in dispatching preview ::");
                        e.printStackTrace();
                        close();
                    }catch (final Exception e) {
                        LOGGER.severe(() -> "Exception thrown in dispatching preview :: Not closing the application");
                        e.printStackTrace();
                    }
                });
            };
            previewEvents.put(key, runnable);
        }
    }

    /**
     * Dispatch the preview of the node.
     *
     * @param appId application id
     * @param windowId window id
     * @param node node whose preview needs to be dispatched
     */
    public final void dispatchPreview(final int appId, final int windowId, final Node node) {
        dispatchPreview(appId, windowId, false, node);
    }

    @Override
    public final void dispatchPropertyDetail(final int appId, final int windowId, final int ownerId,
            final PropertyDetails propDetails) {
        final String desc = String.format("%s-%s-%s-%s", appId + "", windowId + "", ownerId + "", propDetails);
        /* Queuing the property events to send to fxplorer. */
        synchronized (propertyEvents) {
            LOGGER.fine(() -> "Adding event : " + desc);
            propertyEvents.add(new PropertyEvent(() -> {
                try {
                    fxplorer.dispatchPropertyDetail(appId, windowId, ownerId, propDetails);
                } catch (final RemoteException e) {
                    LOGGER.severe(() -> "RemoteException thrown in dispatchPropertyDetail ::");
                    e.printStackTrace();
                    close();
                }
            }, desc));
        }
    }

    @Override
    public final void dispatchWindow(final int appId, final WindowDetails windowDetails) {
        try {
            fxplorer.dispatchWindow(appId, windowDetails);
        } catch (final RemoteException e) {
            LOGGER.severe(() -> "RemoteException thrown in dispatchWindow ::");
            e.printStackTrace();
            close();
        }
    }

    @Override
    public final void onAgentStarted(final int port, final int appID) {
        try {
            fxplorer.onAgentStarted(port, appID);
        } catch (final RemoteException e) {
            LOGGER.severe(() -> "RemoteException thrown in onAgentStarted ::");
            e.printStackTrace();
            close();
        }
    }

    @Override
    public final void run() {
        while (running) {
            try {
                Thread.sleep(60); /* Syncing with pulse @60fps */
            } catch (final InterruptedException e) {
                LOGGER.severe(() -> "Exception occurred while sleeping in event queue !!");
            }

            PropertyEvent propEvent = null;
            while (!propertyEvents.isEmpty()) {
                synchronized (propertyEvents) {
                    propEvent = propertyEvents.remove(0);
                }
                if (propEvent != null) {
                    LOGGER.fine("Releasing event : " + propEvent);
                    propEvent.event.run();
                }
            }

            Runnable previewEvent = null;
            while (!previewEvents.isEmpty()) {
                String key;
                synchronized (previewEvents) {
                    final Map.Entry<String, Runnable> entry = previewEvents.entrySet().iterator().next();
                    key = entry.getKey();
                    previewEvent = previewEvents.remove(key);
                }
                if (previewEvent != null) {
                    LOGGER.fine(() -> "Releasing preview event : " + key);
                    previewEvent.run();
                }
            }
        }
    }

    @Override
    public final void selectNode(final int appId, final int windowId, final int nodeId) {
        try {
            fxplorer.selectNode(appId, windowId, nodeId);
        } catch (final RemoteException e) {
            LOGGER.severe(() -> "RemoteException thrown in selectNode ::");
            e.printStackTrace();
            close();
        }
    }

    /**
     * Builds the property details for preview of the provided node.
     *
     * @param n node to which the preview needs to be taken
     * @return property details
     */
    private PropertyDetails buildPreviewDetails(final Node n) {
        final ImageValue preview = new ImageValue(n.snapshot(ImageUtils.getSnapshotParameters(), null));
        return new PropertyDetails("preview", ValueType.IMAGE, preview);
    }
}
