package com.sai.javafx.fxplorer.utils;

import javafx.scene.control.Label;
import javafx.scene.layout.Region;

/**
 * Utility for labels.
 */
public final class LabelUtils {

    /**
     * Constructor.
     */
    public LabelUtils() {
        /* Empty */
    }

    /**
     * Returns a Label with bold styling.
     *
     * @param s label text
     * @return label
     */
    public static Label bold(final String s) {
        final Label lbl = new Label(s);
        lbl.getStyleClass().add("bold");
        return lbl;
    }

    /**
     * Returns a Label with bold styling and has a minimum width of its content.
     *
     * @param s label text
     * @return label
     */
    public static Label fitWidthBoldLabel(final String s) {
        final Label lbl = new Label(s);
        lbl.getStyleClass().add("bold");
        lbl.setMinWidth(Region.USE_PREF_SIZE);
        return lbl;
    }

    /**
     * Returns a Label with italic styling and has a minimum width of its content.
     *
     * @param s label text
     * @return label
     */
    public static Label fitWidthItalicLabel(final String s) {
        final Label lbl = new Label(s);
        lbl.getStyleClass().add("italic");
        lbl.setMinWidth(Region.USE_PREF_SIZE);
        return lbl;
    }

    /**
     * Returns a Label which has a minimum width of its content.
     *
     * @param s label text
     * @return label
     */
    public static Label fitWidthLabel(final String s) {
        final Label lbl = new Label(s);
        lbl.setMinWidth(Region.USE_PREF_SIZE);
        return lbl;
    }

    /**
     * Returns a Label with italic styling.
     *
     * @param s label text
     * @return label
     */
    public static Label italic(final String s) {
        final Label lbl = new Label(s);
        lbl.getStyleClass().add("italic");
        return lbl;
    }
}
