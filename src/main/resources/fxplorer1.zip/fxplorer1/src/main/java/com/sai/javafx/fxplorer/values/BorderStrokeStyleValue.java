package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.shape.StrokeType;

public class BorderStrokeStyleValue implements Value, Serializable {

    private StrokeType type;

    private StrokeLineJoin lineJoin;

    private StrokeLineCap lineCap;

    private double miterLimit;

    private double dashOffset;

    private List<Double> dashArray;

    private BorderStrokeStyleValue() {
        /* private for snapshot */
    }

    public BorderStrokeStyleValue(final BorderStrokeStyle bss) {
        type = bss.getType();
        lineJoin = bss.getLineJoin();
        lineCap = bss.getLineCap();
        miterLimit = bss.getMiterLimit();
        dashOffset = bss.getDashOffset();
        dashArray = bss.getDashArray();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BorderStrokeStyleValue that)) {
            return false;
        }
        return Double.compare(that.miterLimit, miterLimit) == 0
            && Double.compare(that.dashOffset, dashOffset) == 0
            && type == that.type
            && lineJoin == that.lineJoin
            && lineCap == that.lineCap
            && Objects.equals(dashArray, that.dashArray);
    }

    @Override
    public BorderStrokeStyle getValue() {
        return new BorderStrokeStyle(type, lineJoin, lineCap, miterLimit, dashOffset, dashArray);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, lineJoin, lineCap, miterLimit, dashOffset, dashArray);
    }

    @Override
    public BorderStrokeStyleValue snapshot() {
        final BorderStrokeStyleValue snapshot = new BorderStrokeStyleValue();
        snapshot.type = type;
        snapshot.lineJoin = lineJoin;
        snapshot.lineCap = lineCap;
        snapshot.miterLimit = miterLimit;
        snapshot.dashOffset = dashOffset;
        snapshot.dashArray = dashArray;
        return snapshot;
    }

    @Override
    public String toString() {
        return "BorderStrokeStyleValue{"
            +
            "type="
            + type
            +
            ", lineJoin="
            + lineJoin
            +
            ", lineCap="
            + lineCap
            +
            ", miterLimit="
            + miterLimit
            +
            ", dashOffset="
            + dashOffset
            +
            ", dashArray="
            + dashArray
            +
            '}';
    }
}
