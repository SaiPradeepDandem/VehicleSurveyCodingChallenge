package com.sai.javafx.fxplorer.ui.valuenode;

import static com.sai.javafx.fxplorer.utils.LabelUtils.fitWidthBoldLabel;
import static com.sai.javafx.fxplorer.utils.LabelUtils.fitWidthItalicLabel;
import static com.sai.javafx.fxplorer.utils.LabelUtils.fitWidthLabel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.values.StringValue;

import javafx.scene.Node;
import javafx.scene.layout.GridPane;

/**
 * Specifies the constraints value.
 */
public final class ConstraintsValueNode implements ValueNode {

    /** Layout for displaying the constraints details. */
    private final GridPane layout = new GridPane();

    /**
     * Constructor.
     */
    public ConstraintsValueNode() {
        layout.setVgap(6);
        layout.setHgap(15);
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        /* Empty */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        layout.getChildren().clear();
        final String val = ((StringValue) propertyDetails.getValue()).getValue();
        final List<Map<String, String>> propsList = parseValue(val);
        if (val == null || val.trim().isEmpty()) {
            return;
        }
        final List<String> props = new ArrayList<>(propsList.get(0).keySet());
        if (val.startsWith("ColumnConstraints")) {
            buildColumnConstraints(props, propsList);
        } else {
            buildRowConstraints(props, propsList);
        }
    }

    /**
     * Builds the layout for displaying the column constraints.
     *
     * @param props list of constraint properties
     * @param propsList list of values to the constraint properties
     */
    private void buildColumnConstraints(final List<String> props, final List<Map<String, String>> propsList) {
        for (int colIndex = 0; colIndex < propsList.size(); colIndex++) {
            layout.add(fitWidthBoldLabel("Col " + colIndex), colIndex + 1, 0);
        }
        for (int rowIndex = 0; rowIndex < props.size(); rowIndex++) {
            final String property = props.get(rowIndex);
            layout.add(fitWidthItalicLabel(property), 0, rowIndex + 1);
            for (int colIndex = 0; colIndex < propsList.size(); colIndex++) {
                layout.add(fitWidthLabel(propsList.get(colIndex).get(property)), colIndex + 1, rowIndex + 1);
            }
        }
    }

    /**
     * Builds the layout for displaying the row constraints.
     *
     * @param props list of constraint properties
     * @param propsList list of values to the constraint properties
     */
    private void buildRowConstraints(final List<String> props, final List<Map<String, String>> propsList) {
        for (int colIndex = 0; colIndex < props.size(); colIndex++) {
            layout.add(fitWidthItalicLabel(props.get(colIndex)), colIndex + 1, 0);
        }
        for (int rowIndex = 0; rowIndex < propsList.size(); rowIndex++) {
            layout.add(fitWidthBoldLabel("Row " + rowIndex), 0, rowIndex + 1);
            final Map<String, String> keyValues = propsList.get(rowIndex);
            for (int colIndex = 0; colIndex < props.size(); colIndex++) {
                layout.add(fitWidthLabel(keyValues.get(props.get(colIndex))), colIndex + 1, rowIndex + 1);
            }
        }
    }

    /**
     * Parses the string value to determine for column or row constraints.
     *
     * @param val string value of constraints
     * @return list of constraint property details
     */
    private List<Map<String, String>> parseValue(final String val) {
        final List<Map<String, String>> list = new ArrayList<>();
        final String[] arr = val.split(",");
        Stream.of(arr).forEach(c -> {
            c = c.replaceAll("ColumnConstraints", "").replaceAll("RowConstraints", "").trim();
            if (!c.isEmpty()) {
                final Map<String, String> m = new LinkedHashMap<>();
                Stream.of(c.split(" ")).forEach(kv -> {
                    final String[] propVal = kv.split("=");
                    if (propVal.length == 2) {
                        m.put(propVal[0], propVal[1]);
                    } else {
                        throw new IllegalArgumentException("Not a valid constraints string to parse !!");
                    }
                });
                list.add(m);
            }
        });
        return list;
    }
}
