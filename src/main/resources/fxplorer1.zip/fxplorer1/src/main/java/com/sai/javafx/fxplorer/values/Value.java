package com.sai.javafx.fxplorer.values;

import java.io.Serializable;

public interface Value extends Serializable {

    public Object getValue();

    public Value snapshot();
}
