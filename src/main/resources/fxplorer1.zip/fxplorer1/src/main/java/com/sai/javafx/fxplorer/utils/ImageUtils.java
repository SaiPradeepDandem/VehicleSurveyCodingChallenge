package com.sai.javafx.fxplorer.utils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

/**
 * Utility class for the image.
 */
public final class ImageUtils {

    /** Snapshot parameters instance. */
    private static SnapshotParameters snapshotParameters;

    /**
     * Constructor.
     */
    public ImageUtils() {
        /* Empty */
    }

    /**
     * Converts the provided byte array to image.
     *
     * @param bytes byte array
     * @param formatName image format
     * @return image instance
     * @throws IOException
     */
    public static Image fromByteArray(final byte[] bytes, final String formatName) throws IOException {
        final ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        final BufferedImage bufferedImage = ImageIO.read(in);
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    /**
     * Returns the snapshot parameters.
     *
     * @return snapshot parameters
     */
    public static SnapshotParameters getSnapshotParameters() {
        if (snapshotParameters == null) {
            snapshotParameters = new SnapshotParameters();
            snapshotParameters.setFill(Color.TRANSPARENT);
        }
        return snapshotParameters;
    }

    /**
     * Converts the image to the byte array.
     *
     * @param image image instance
     * @param formatName image format name
     * @return byte array
     * @throws IOException
     */
    public static byte[] toByteArray(final Image image, final String formatName) throws IOException {
        final BufferedImage bufferedImage = SwingFXUtils.fromFXImage(image, null);
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(bufferedImage, formatName, out);
        return out.toByteArray();
    }
}
