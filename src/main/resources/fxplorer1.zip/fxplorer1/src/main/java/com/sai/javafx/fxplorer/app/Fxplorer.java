package com.sai.javafx.fxplorer.app;

import java.io.IOException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.sai.javafx.fxplorer.connector.AgentLoader;
import com.sai.javafx.fxplorer.connector.Constants;
import com.sai.javafx.fxplorer.ui.FxplorerWindow;
import com.sai.javafx.fxplorer.ui.LayoutController;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Application main class.
 */
public final class Fxplorer extends Application {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(Fxplorer.class.getName());

    /**
     * Constructor.
     */
    public Fxplorer() {
        /* Empty */
    }

    /**
     * Main method.
     *
     * @param args arguments
     */
    public static void main(final String[] args) {
        Logger rootLogger = LogManager.getLogManager().getLogger("");
        rootLogger.setLevel(Level.INFO); // Set root logger level to ALL

        for (Handler handler : rootLogger.getHandlers()) {
            handler.setLevel(Level.INFO); // Set each handler to ALL
        }

        launch(args);
    }

    @Override
    public final void start(final Stage primaryStage) throws Exception {
        /* Set the server hostname as the local ip */
        System.setProperty("java.rmi.server.hostname", Constants.LOCAL_HOST);

        final LayoutController layoutController = new LayoutController();
        layoutController.load();

        final FxplorerWindow window = new FxplorerWindow(layoutController.getRoot());
        window.setTitle("Fxplorer");
        window.setOnHidden(e -> System.exit(0));
        window.showWindow();

        try {
            final AgentLoader agentLoader = new AgentLoader();
            agentLoader.connect(layoutController);
        }catch (Exception e){
            e.printStackTrace();
            throw new IOException(e);
        }
    }
}
