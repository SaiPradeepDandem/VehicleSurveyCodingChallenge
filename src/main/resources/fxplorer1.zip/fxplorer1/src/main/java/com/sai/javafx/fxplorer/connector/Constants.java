package com.sai.javafx.fxplorer.connector;

/**
 * Constants for the application.
 */
public interface Constants {

    /** System properties key for JavaFX version. */
    String JAVAFX_SYSTEM_PROPERTIES_KEY = "javafx.version";

    /** System properties key for java class version. */
    String JAVA_CLASS_VERSION_KEY = "java.class.version";

    /** System properties key for java class path. */
    String JAVA_CLASSPATH = "java.class.path";

    /** Minimum java class version required. This is the value that starts from JDK 9. */
    double JAVA_CLASS_VERSION_VALUE = 52.0;

    /** System properties key for JDK module path. */
    String JDK_MODULE_PATH = "jdk.module.path";

    /** Path separator key. */
    String PATH_SEPARATOR = "path.separator";

    /** Extension for jar file. */
    String JAR_EXT = ".jar";

    /**
     * Name of the application jar. Ensure that this name is same as the one defined in build.gradle -> jar ->
     * archiveFileName
     */
    String JAR_NAME = "fxplorer" + JAR_EXT;

    /** Path for the libs directory. */
    String LIBS_PATH = "build/libs/";

    /** Id for remote connector. */
    String REMOTE_CONNECTOR = "RemoteConnector";

    /** Id for the remote agent. */
    String REMOTE_AGENT = "AgentServer";

    /** Localhost IP address. */
    String LOCAL_HOST = "127.0.0.1";
}
