package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BackgroundSize;

public class BackgroundSizeValue implements Value, Serializable {

    private double width;

    private double height;

    private boolean widthAsPercentage;

    private boolean heightAsPercentage;

    private boolean contain;

    private boolean cover;

    private BackgroundSizeValue() {
        /* private for snapshot */
    }

    public BackgroundSizeValue(final BackgroundSize bs) {
        width = bs.getWidth();
        height = bs.getHeight();
        widthAsPercentage = bs.isWidthAsPercentage();
        heightAsPercentage = bs.isHeightAsPercentage();
        contain = bs.isContain();
        cover = bs.isCover();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BackgroundSizeValue that)) {
            return false;
        }
        return Double.compare(that.width, width) == 0
            && Double.compare(that.height, height) == 0
            && widthAsPercentage == that.widthAsPercentage
            && heightAsPercentage == that.heightAsPercentage
            && contain == that.contain
            && cover == that.cover;
    }

    @Override
    public BackgroundSize getValue() {
        return new BackgroundSize(width, height, widthAsPercentage, heightAsPercentage, contain, cover);
    }

    @Override
    public int hashCode() {
        return Objects.hash(width, height, widthAsPercentage, heightAsPercentage, contain, cover);
    }

    @Override
    public BackgroundSizeValue snapshot() {
        final BackgroundSizeValue snapshot = new BackgroundSizeValue();
        snapshot.width = width;
        snapshot.height = height;
        snapshot.widthAsPercentage = widthAsPercentage;
        snapshot.heightAsPercentage = heightAsPercentage;
        snapshot.contain = contain;
        snapshot.cover = cover;
        return snapshot;
    }

    @Override
    public String toString() {
        return "BackgroundSizeValue{"
            +
            "width="
            + width
            +
            ", height="
            + height
            +
            ", widthAsPercentage="
            + widthAsPercentage
            +
            ", heightAsPercentage="
            + heightAsPercentage
            +
            ", contain="
            + contain
            +
            ", cover="
            + cover
            +
            '}';
    }
}
