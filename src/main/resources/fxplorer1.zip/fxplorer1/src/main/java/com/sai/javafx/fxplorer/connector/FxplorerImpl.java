package com.sai.javafx.fxplorer.connector;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Logger;

import com.sai.javafx.fxplorer.data.AppDetails;
import com.sai.javafx.fxplorer.data.DispatchType;
import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.WindowDetails;
import com.sai.javafx.fxplorer.ui.LayoutController;

import javafx.application.Platform;

/**
 * Implementation for the interface for fxplorer to communicate with remote applications.
 */
public final class FxplorerImpl extends UnicastRemoteObject implements IFxplorer {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(FxplorerImpl.class.getName());

    /** All remote agents mapped with the VM ids. */
    private static final Map<Integer, IRemoteApp> appInterfacesMap = new HashMap<>();

    /** All remote agents details mapped with the VM ids. */
    private static final Map<Integer, AppDetails> appDetailsMap = new HashMap<>();

    /** The main layout controller. */
    private LayoutController layoutController;

    /**
     * Constructor.
     *
     * @throws RemoteException
     */
    public FxplorerImpl() throws RemoteException {
        /* Empty */
    }

    @Override
    public final void close() {
        /* Empty */
    }

    /**
     * Deletes the provided application from the layout and the map.
     *
     * @param appId id of the remote application
     */
    public final void deleteApp(final String appId) {
        LOGGER.info(() -> "Deleting the application : " + appId);
        final int appID = Integer.parseInt(appId);
        final AppDetails appDetails = appDetailsMap.remove(appID);
        appInterfacesMap.remove(appID);
        layoutController.removeApp(appDetails);
    }

    @Override
    public final void dispatchChildrenUpdate(final int appId, final int windowId, final NodeDetails nodeDetails)
            throws RemoteException {
        LOGGER.fine(
                () -> String.format("Children update requested for app: %s, window: %s, node: %s, childCount: %s",
                        appId + "", windowId + "", nodeDetails.getUId() + "",
                        nodeDetails.getChildren().size() + ""));
        layoutController.updateChildren(appId, windowId, nodeDetails);
    }

    @Override
    public final void dispatchPropertyDetail(final int appId, final int windowId, final int ownerId,
            final PropertyDetails propDetails) throws RemoteException {
        LOGGER.fine(() -> String.format("Prop updated in app: %s, window: %s, owner: %s ::  %s", appId + "",
                windowId + "",
                ownerId + "", propDetails));
        layoutController.updateProperty(appId, windowId, ownerId, propDetails);
    }

    @Override
    public final void dispatchWindow(final int appId, final WindowDetails window) throws RemoteException {
        LOGGER.info(() -> String.format("Window updated : %s for the the app : %s :: Title : %s, EventType : %s",
                window.getUId() + "", appId + "", window.getTitle(), window.getDispatchType()));

        Platform.runLater(() -> {
            /* Create the VM/App tree item if it does not exist */
            if (appDetailsMap.get(appId) == null) {
                final AppDetails appDetails = new AppDetails(appId);
                appDetailsMap.put(appId, appDetails);
                layoutController.addApp(appDetails);
            }

            if (window.getDispatchType() == DispatchType.WINDOW_ADDED) {
                layoutController.addWindow(window);
            } else {
                layoutController.removeWindow(appId, window);
            }
        });
    }

    @Override
    public final void onAgentStarted(final int port, final int appID) throws RemoteException {
        LOGGER.info(
                () -> String.format("\n!! New Agent started on port : %s for VM : %s !!", port + "", appID + ""));
        final Thread handShakeThread = new Thread(() -> {
            final Consumer<IRemoteApp> consumer = remoteAppInterface -> {
                synchronized (appInterfacesMap) {
                    LOGGER.info(
                            () -> "Initiated hand shake with remote app : " + appID + " on port : " + port);
                    try {
                        remoteAppInterface.handShake();
                        remoteAppInterface.setSelectNode(layoutController.isSelectNode());
                        remoteAppInterface.setBlockPopupHiding(layoutController.isBlockPopupHide());
                        appInterfacesMap.put(appID, remoteAppInterface);
                    } catch (final RemoteException e) {
                        throw new RuntimeException(e);
                    }
                }
            };
            RMIUtils.findApplication(port, consumer);
        });
        handShakeThread.setDaemon(true);
        handShakeThread.start();
    }

    @Override
    public final void selectNode(final int appId, final int windowId, final int nodeId) throws RemoteException {
        LOGGER.info(() -> String.format("Select node in tree for app: %s, window: %s, node: %s", appId + "",
                windowId + "", nodeId + ""));
        layoutController.selectNodeInTree(appId, windowId, nodeId);
    }

    /**
     * Sets the UI controller and its handlers.
     *
     * @param layoutController layout controller
     */
    public final void setUIController(final LayoutController layoutController) {
        this.layoutController = layoutController;
        layoutController.setPopupHideConsumer(blockHiding -> {
            /* Update the apps with the flag. */
            appInterfacesMap.forEach((appId, remote) -> {
                try {
                    remote.setBlockPopupHiding(blockHiding);
                } catch (final RemoteException e) {
                    throw new RuntimeException(e);
                }
            });

            /* If flag is unchecked, remove any holding popup windows in the tree. */
            if (!blockHiding) {
                layoutController.removePopups();
            }
        });

        layoutController.setSelectNodeConsumer(selectNode -> {
            /* Update the apps with the flag. */
            appInterfacesMap.forEach((appId, remote) -> {
                try {
                    remote.setSelectNode(selectNode);
                } catch (final RemoteException e) {
                    throw new RuntimeException(e);
                }
            });
        });

        layoutController.setHighlightNodeConsumer((details, windowId, highlight) -> {
            final IRemoteApp remote = appInterfacesMap.get(details.getVmId());
            if (remote != null) {
                try {
                    if (highlight) {
                        remote.highlightNode(windowId, details.getUId());
                    } else {
                        remote.removeHighlight(windowId);
                    }
                } catch (final RemoteException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        layoutController.setPreviewNodeConsumer((vmId, windowId, nodeId) -> {
            final IRemoteApp remote = appInterfacesMap.get(vmId);
            if (remote != null) {
                try {
                    remote.setPreviewNode(windowId, nodeId);
                } catch (final RemoteException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}
