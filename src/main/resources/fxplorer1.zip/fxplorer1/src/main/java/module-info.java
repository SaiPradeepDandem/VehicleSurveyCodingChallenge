module com.sai.javafx.fxplorer {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;
    requires javafx.swing;
    requires java.logging;
    requires jdk.attach;
    requires java.instrument;
    requires java.rmi;

    opens com.sai.javafx.fxplorer to javafx.fxml;
    opens com.sai.javafx.fxplorer.ui to javafx.fxml;
    opens com.sai.javafx.fxplorer.widgets to javafx.fxml;
    exports com.sai.javafx.fxplorer;
    exports com.sai.javafx.fxplorer.app;
    exports com.sai.javafx.fxplorer.connector to java.rmi;
}