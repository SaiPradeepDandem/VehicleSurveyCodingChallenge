package com.sai.javafx.fxplorer.ui.valuenode;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.utils.ColorUtils;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;

/**
 * Specifies the background value.
 */
public final class BackgroundValueNode implements ValueNode {

    /** Layout to show the background details. */
    private final GridPane layout = new GridPane();

    /** Layout to show the background fills details. */
    private final GridPane fillsGrid = new GridPane();

    /** Layout to show the background images details. */
    private final GridPane imagesGrid = new GridPane();

    /** Layout to preview the background. */
    private final StackPane preview = new StackPane(new Label("Background Preview"));

    /** Label to represent the no background. */
    private final Label noBgLabel = label("No background");

    /** Row constraint with top alignment. */
    private final RowConstraints topAlignRow = new RowConstraints();

    /**
     * Constructor.
     */
    public BackgroundValueNode() {
        fillsGrid.setHgap(15);
        fillsGrid.setVgap(6);
        imagesGrid.setHgap(15);
        imagesGrid.setVgap(6);
        topAlignRow.setValignment(VPos.TOP);
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setMinWidth(50);
        fillsGrid.getColumnConstraints().add(cc);
        imagesGrid.getColumnConstraints().add(cc);

        preview.setPrefSize(400, 150);
        preview.setMinHeight(150);

        layout.setVgap(10);
        layout.getChildren().add(noBgLabel);
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        /* Empty block. */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        layout.getChildren().clear();
        fillsGrid.getChildren().clear();
        fillsGrid.getRowConstraints().clear();
        imagesGrid.getChildren().clear();
        imagesGrid.getRowConstraints().clear();

        final Background background = (Background) propertyDetails.getValue().getValue();
        if (background == null) {
            layout.getChildren().add(noBgLabel);
            return;
        }
        preview.setBackground(background);
        layout.addRow(0, preview);
        if (!background.getFills().isEmpty()) {
            int count = 0;
            int rowIndex = 0;
            for (final BackgroundFill fill : background.getFills()) {
                final Label fillText = label("Fill#" + count + ":");
                final Paint fillPaint = fill.getFill();
                String fillTextStr = "";
                String fillBgStr = "";
                final StackPane fillBox = new StackPane();
                fillBox.setPrefSize(350, 64);
                fillBox.setMaxSize(350, 64);

                if (fillPaint instanceof LinearGradient) {
                    fillBgStr = fillPaint.toString().replaceAll("0x", "#");
                    fillTextStr = fillBgStr;
                } else {
                    final String hexColor = ColorUtils.getHexColor(fillPaint);
                    final String rgbaColor = ColorUtils.getRGBAColor(fillPaint);
                    fillTextStr = rgbaColor + ",    Hex : " + hexColor;
                    fillBgStr = hexColor;
                }
                final Paint constrastColor = ColorUtils.getContrastColor(fillPaint);
                fillBox.setBorder(new Border(new BorderStroke(constrastColor, BorderStrokeStyle.DASHED,
                                                              CornerRadii.EMPTY, new BorderWidths(1))));
                /* fillBox.setStyle("-fx-background-color:" + fillBgStr); */
                fillBox.setBackground(new Background(fill));
                final int firstRow = rowIndex++;
                fillsGrid.add(fillText, 0, firstRow);
                fillsGrid.add(label(fillTextStr), 1, firstRow, 3, 1);

                fillsGrid.addRow(rowIndex++, new Label(), fillBox, buildInsetsGrid(fill.getInsets(), "insets"),
                        buildRadiiGrid(fill.getRadii()));
                fillsGrid.add(new Separator(), 0, rowIndex++, 4, 1);
                count++;
            }
            layout.addRow(1, fillsGrid);
        }
        if (!background.getImages().isEmpty()) {
            int count = 0;
            int rowIndex = 0;
            for (final BackgroundImage image : background.getImages()) {
                final int firstRow = rowIndex++;
                final Label imageText = label("Image#" + count + ":");
                final ImageView imageView = new ImageView(image.getImage());
                imagesGrid.add(imageText, 0, firstRow);
                imagesGrid.add(imageView, 1, firstRow);

                final GridPane repeatGrid = new GridPane();
                repeatGrid.setVgap(5);
                repeatGrid.setHgap(5);
                repeatGrid.add(boldLabel("Repeat"), 0, 0, 2, 1);
                repeatGrid.addRow(1, label("repeatX:"), label(image.getRepeatX().toString()));
                repeatGrid.addRow(2, label("repeatY:"), label(image.getRepeatX().toString()));
                imagesGrid.add(repeatGrid, 2, firstRow);

                final GridPane positionGrid = new GridPane();
                positionGrid.setVgap(5);
                positionGrid.setHgap(5);
                positionGrid.setPadding(new Insets(0, 0, 0, 10));
                positionGrid.add(boldLabel("Position"), 0, 0, 2, 1);
                positionGrid.addRow(1, label("horizontalSide:"),
                        label(image.getPosition().getHorizontalSide().toString()));
                positionGrid.addRow(2, label("horizontalPosition:"),
                        label(image.getPosition().getHorizontalPosition() + ""));
                positionGrid.addRow(3, label("horizontalAsPercentage:"),
                        label(image.getPosition().isHorizontalAsPercentage() + ""));
                positionGrid.addRow(4, label("verticalSide:"),
                        label(image.getPosition().getVerticalSide().toString()));
                positionGrid.addRow(5, label("verticalPosition:"),
                        label(image.getPosition().getVerticalPosition() + ""));
                positionGrid.addRow(6, label("verticalAsPercentage:"),
                        label(image.getPosition().isVerticalAsPercentage() + ""));
                imagesGrid.add(positionGrid, 3, firstRow);

                final GridPane sizeGrid = new GridPane();
                sizeGrid.setVgap(5);
                sizeGrid.setHgap(5);
                sizeGrid.setPadding(new Insets(0, 0, 0, 10));
                sizeGrid.add(boldLabel("Size"), 0, 0, 2, 1);
                sizeGrid.addRow(1, label("width:"), label(image.getSize().getWidth() + ""));
                sizeGrid.addRow(2, label("height:"), label(image.getSize().getHeight() + ""));
                sizeGrid.addRow(3, label("widthAsPercentage:"), label(image.getSize().isWidthAsPercentage() + ""));
                sizeGrid.addRow(4, label("heightAsPercentage:"),
                        label(image.getSize().isHeightAsPercentage() + ""));
                sizeGrid.addRow(5, label("cover:"), label(image.getSize().isCover() + ""));
                sizeGrid.addRow(6, label("contain:"), label(image.getSize().isContain() + ""));
                imagesGrid.add(sizeGrid, 4, firstRow);
                imagesGrid.add(new Separator(), 0, rowIndex++, 5, 1);
                imagesGrid.getRowConstraints().addAll(topAlignRow, topAlignRow);
                count++;
            }
            layout.addRow(2, imagesGrid);
        }
    }

    /**
     * Builds a bold label with provided text.
     *
     * @param text text in label
     * @return label
     */
    private Label boldLabel(final String text) {
        final Label lbl = label(text);
        lbl.setStyle("-fx-font-weight:bold;");
        return lbl;
    }

    /**
     * Builds the grid layout for showing the Insets value with the provided label at the center.
     *
     * @param insets Insets to be shown
     * @param lbl Info label to be displayed at center
     * @return GridPane layout
     */
    private GridPane buildInsetsGrid(final Insets insets, final String lbl) {
        final Label lblText = label(lbl);
        lblText.setStyle("-fx-font-size:12px;-fx-fill:black");
        final GridPane insetGrid = new GridPane();
        insetGrid.setVgap(2);
        insetGrid.setHgap(2);
        insetGrid.addRow(0, new Label(), label(insets.getTop() + ""), new Label());
        insetGrid.addRow(1, label(insets.getLeft() + ""), lblText, label(insets.getRight() + ""));
        insetGrid.addRow(2, new Label(), label(insets.getBottom() + ""), new Label());
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.CENTER);
        insetGrid.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        return insetGrid;
    }

    /**
     * Builds the layout for displaying the corder radius details.
     *
     * @param radii Instance of CornerRadii
     * @return GridPane
     */
    private GridPane buildRadiiGrid(final CornerRadii radii) {
        final Label lblText = label("corner-radius");
        lblText.setStyle("-fx-font-size:12px;-fx-fill:black");
        final GridPane insetGrid = new GridPane();
        insetGrid.setVgap(2);
        insetGrid.setHgap(2);
        insetGrid
            .addRow(0, label(radii.getTopLeftHorizontalRadius() + ""), new Label(),
                    label(radii.getTopRightHorizontalRadius() + ""));
        insetGrid.addRow(1, new Label(), lblText, new Label());
        insetGrid
            .addRow(2, label(radii.getBottomLeftHorizontalRadius() + ""), new Label(),
                    label(radii.getBottomRightHorizontalRadius() + ""));
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.CENTER);
        insetGrid.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        return insetGrid;
    }

    /**
     * Builds a label with the provided text .
     *
     * @param text text
     * @return label
     */
    private Label label(final String text) {
        final Label lbl = new Label(text);
        lbl.setMinWidth(Region.USE_PREF_SIZE);
        return lbl;
    }
}
