package com.sai.javafx.fxplorer.ui;

import java.util.Arrays;
import java.util.List;

import com.sai.javafx.fxplorer.utils.ResizeHelper;
import com.sai.javafx.fxplorer.utils.Utils;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.stage.WindowEvent;

/**
 * A custom control representing a window.
 */
public final class FxplorerWindow extends Stage {

    /**
     * Potential display states for the window
     */
    public enum WindowState {
        /**
         * State if the window is floating
         */
        WINDOWED,
        /**
         * State if the window is minimized
         */
        MINIMIZED,
        /**
         * State if the window is maximized
         */
        MAXIMIZED
    }

    /**
     * Holds the window configuration when minimized or maximized
     */
    final class WindowedStateConfig {

        /**
         * The left offset
         */
        private final double windowX;

        /**
         * The top offset
         */
        private final double windowY;

        /**
         * The width of the window
         */
        private final double windowWidth;

        /**
         * The height of the window
         */
        private final double windowHeight;

        /**
         * Constructor for minimize events
         *
         * @param windowHeightTmp the height of the window
         */
        WindowedStateConfig(final double windowHeightTmp) {
            windowX = -1;
            windowY = -1;
            windowWidth = -1;
            windowHeight = windowHeightTmp;
        }

        /**
         * Constructor for maximize and restoration events
         *
         * @param window with the desired configuration
         */
        WindowedStateConfig(final Window window) {
            windowX = window.getX();
            windowY = window.getY();
            windowWidth = window.getWidth();
            windowHeight = window.getHeight();
        }

        /**
         * Assign the dimensions stored here to the provided window
         */
        final void assignDimensions() {
            if (windowWidth > -1) {
                fxplorerWindow.setWidth(windowWidth);
            }

            if (windowHeight > -1) {
                fxplorerWindow.setHeight(windowHeight);
            }

            if (windowX > -1) {
                fxplorerWindow.setX(windowX);
            }

            if (windowY > -1) {
                fxplorerWindow.setY(windowY);
            }
        }
    }

    /**
     * Id of the window minimize button
     */
    private static final String MINIMIZE_BUTTON_ID = "button-minimize";

    /**
     * Id of the window maximize button
     */
    private static final String MAXIMIZE_BUTTON_ID = "button-maximize";

    /**
     * Id of the window close button
     */
    private static final String CLOSE_BUTTON_ID = "button-close";

    /**
     * List of ids of all window buttons
     */
    private static final List<String> BUTTON_IDS =
            Arrays.asList(MINIMIZE_BUTTON_ID, MAXIMIZE_BUTTON_ID, CLOSE_BUTTON_ID);

    /**
     * Pseudo class for stage focused state
     */
    private static final PseudoClass FOCUSED_PSEUDO_CLASS = PseudoClass.getPseudoClass("focused");

    /**
     * Pseudo class for window button restore state
     */
    private static final PseudoClass RESTORE_PSEUDO_CLASS = PseudoClass.getPseudoClass("restore");

    private final Stage fxplorerWindow;

    private Scene scene;

    private Window windowOwner;

    /**
     * The current display state of the window
     */
    private final ObjectProperty<WindowState> currentWindowState = new SimpleObjectProperty<>();

    private StackPane root;

    /**
     * The primary root content node of a FxplorerWindow
     */
    BorderPane windowPane;

    /**
     * The title bar of any WindowMode::Normal window
     */
    private BorderPane windowTitleBar;

    private CheckMenuItem lightThemeItem;

    private CheckMenuItem darkThemeItem;

    /**
     * The label displaying the window title
     */
    private Label labelTitle;

    /**
     * The panel on which to delegate any header content
     */
    private HBox headerPane;

    /**
     * The minimize, maximize and close button panel
     */
    private HBox buttonPane;

    /**
     * The minimize button
     */
    private Button buttonMinimize;

    /**
     * The maximize button
     */
    private Button buttonMaximize;

    /**
     * The close button
     */
    private Button buttonClose;

    /**
     * Coordinate for moving the FxplorerWindow
     */
    private double sceneXOffset = 0;

    /**
     * Coordinate for moving the FxplorerWindow
     */
    private double sceneYOffset = 0;

    /**
     * Stored configuration for window restoration, if necessary
     */
    private WindowedStateConfig windowedStateConfig;

    private final Insets shadowInsets = new Insets(ResizeHelper.SHADOW_AREA);

    private final ReadOnlyObjectWrapper<Theme> theme = new ReadOnlyObjectWrapper<>();

    /**
     * Constructor
     *
     * @param mainContent Allows the creation of a new window with node already specified
     */
    public FxplorerWindow(final Node mainContent) {
        this(mainContent, -1, -1);
    }

    /**
     * Constructor
     *
     * @param mainContent Allows the creation of a new window with node already specified
     */
    public FxplorerWindow(final Node mainContent, final double width, final double height) {
        fxplorerWindow = this;
        fxplorerWindow.initStyle(StageStyle.TRANSPARENT);
        init(width, height);
        windowPane.setCenter(mainContent);
    }

    public final boolean canDrag(final MouseEvent event) {
        return event.getButton().equals(MouseButton.PRIMARY);
    }

    /**
     * Bring to front or show window
     */
    public final void closeWindow() {
        fireEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSE_REQUEST));
        fxplorerWindow.hide();
        setWindowState(WindowState.WINDOWED);
    }

    public final ObjectProperty<WindowState> currentWindowStateProperty() {
        return currentWindowState;
    }

    /**
     * The button panel
     *
     * @return The panel
     */
    public final Button getButtonClose() {
        return buttonClose;
    }

    /**
     * The maximize button
     *
     * @return The button
     */
    public final Button getButtonMaximize() {
        return buttonMaximize;
    }

    /**
     * The minimize button
     *
     * @return The button
     */
    public final Button getButtonMinimize() {
        return buttonMinimize;
    }

    /**
     * The button panel
     *
     * @return The panel
     */
    public final HBox getButtonPane() {
        return buttonPane;
    }

    /**
     * The current window state
     *
     * @return the state
     */
    public final WindowState getCurrentWindowState() {
        return currentWindowState.get();
    }

    /**
     * Get the current location of this window
     *
     * @return The top left of the window as a {@link Point2D}
     */
    public final Point2D getDragPoint() {
        return new Point2D(fxplorerWindow.getX(), fxplorerWindow.getY());
    }

    /**
     * The header content panel
     *
     * @return the panel
     */
    public final HBox getHeaderPane() {
        return headerPane;
    }

    /**
     * The window title label
     *
     * @return the label
     */
    public final Label getLabelTitle() {
        return labelTitle;
    }

    /**
     * The root node of the FxplorerWindow
     *
     * @return the pane
     */
    public final BorderPane getWindowPane() {
        return windowPane;
    }

    /**
     * The title bar of the window
     *
     * @return the panel
     */
    public final BorderPane getWindowTitleBar() {
        return windowTitleBar;
    }

    /**
     * Determines whether the mouse event target node is on any of the window buttons or not.
     *
     * @param event Mouse event instance
     * @return {@code true} if the mouse event target is any of the window buttons else returns {@code false}.
     */
    public final boolean isWindowButtonTarget(final MouseEvent event) {
        return event.getTarget() instanceof Button && BUTTON_IDS.contains(((Button) event.getTarget()).getId());
    }

    public final void setContent(final Node node) {
        if (node != null) {
            windowPane.setCenter(node);
            BorderPane.setAlignment(node, Pos.TOP_CENTER);
        }
    }

    public final void setWindowContent(final Node mainContent) {
        setWindowContent(mainContent, null);
    }

    public final void setWindowContent(final Node mainContent, final String title) {
        if (mainContent != null) {
            windowPane.setCenter(mainContent);
            BorderPane.setAlignment(mainContent, Pos.TOP_CENTER);
        }
        setTitle(title);
    }

    public final void setWindowOwner(final Window windowOwnerTmp) {
        windowOwner = windowOwnerTmp;
        if (windowOwner != null) {
            fxplorerWindow.initOwner(windowOwner);
        }
    }

    /**
     * Set a new state for the window based on button actions or event triggers
     *
     * @param windowStateTmp The desired window state
     */
    public final void setWindowState(final WindowState windowStateTmp) {
        final WindowState newState;
        if (windowStateTmp == WindowState.MINIMIZED) {
            newState = WindowState.MINIMIZED;
        } else {
            newState = windowStateTmp.equals(currentWindowState) ? WindowState.WINDOWED : windowStateTmp;
        }
        currentWindowState.set(newState);
        final Node center = windowPane.getCenter();
        switch (newState) {
            case MINIMIZED:
                fxplorerWindow.setIconified(true);
                break;
            case MAXIMIZED:
                windowedStateConfig = new WindowedStateConfig(fxplorerWindow);
                final Rectangle2D visualBounds = getScreensForWindow().get(0).getVisualBounds();
                fxplorerWindow.setX(visualBounds.getMinX());
                fxplorerWindow.setY(visualBounds.getMinY());
                fxplorerWindow.setWidth(visualBounds.getWidth());
                fxplorerWindow.setHeight(visualBounds.getHeight());
                fxplorerWindow.setResizable(false);
                break;
            case WINDOWED:
            default:
                fxplorerWindow.setResizable(true);
                if (windowedStateConfig != null) {
                    windowedStateConfig.assignDimensions();
                    windowedStateConfig = null;
                }
        }
        buttonMaximize.pseudoClassStateChanged(RESTORE_PSEUDO_CLASS, newState == WindowState.MAXIMIZED);
        root.setPadding(newState == WindowState.MAXIMIZED ? Insets.EMPTY : shadowInsets);
    }

    /**
     * Bring to front or show window
     */
    public final void showWindow() {
        setWindowState(WindowState.WINDOWED);
        fxplorerWindow.show();
        fxplorerWindow.toFront();
        fxplorerWindow.requestFocus();
    }

    public final ReadOnlyObjectProperty<Theme> themeProperty() {
        return theme.getReadOnlyProperty();
    }

    public final void updateTheme(final Theme t) {
        theme.set(t);
    }

    /**
     * Assign the movement events to the title bar of the window
     * <p>
     * Make the title visible and managed
     */
    private void assignTitleBarEvents() {
        final Node top = windowPane.getTop();
        if (top != null) {
            enableComponent(top, true);
        }

        windowTitleBar.setOnMousePressed(this::recordFxplorerWindowLocation);
        windowTitleBar.setOnMouseDragged(this::moveFxplorerWindow);
        windowTitleBar.setOnMouseReleased(this::resetMousePointer);
    }

    /**
     * Build the default root and title panels for a FxplorerWindow, and assign all default configurations
     */
    private void buildRootNode(final double width, final double height) {
        windowPane = new BorderPane();
        windowPane.getStyleClass().addAll("sv-window-pane");

        headerPane = new HBox();
        headerPane.setAlignment(Pos.CENTER_RIGHT);
        HBox.setHgrow(headerPane, Priority.ALWAYS);

        labelTitle = new Label();
        labelTitle.getStyleClass().add("sv-title-label");
        labelTitle.setMaxHeight(Double.MAX_VALUE);
        labelTitle.textProperty().bind(titleProperty());

        final MenuButton themeButton = new MenuButton();
        themeButton.setFocusTraversable(false);
        themeButton.getStyleClass().add("sv-button-theme");

        lightThemeItem = new CheckMenuItem("LIGHT");
        lightThemeItem.setOnAction(e -> updateTheme(Theme.LIGHT));
        lightThemeItem.setSelected(true);
        darkThemeItem = new CheckMenuItem("DARK");
        darkThemeItem.setOnAction(e -> updateTheme(Theme.DARK));
        themeButton.getItems().addAll(lightThemeItem, darkThemeItem);
        theme.addListener((obs, old, val) -> onThemeChanged(val));

        buttonMinimize = new Button();
        buttonMinimize.setId(MINIMIZE_BUTTON_ID);
        buttonMinimize.setFocusTraversable(false);
        buttonMinimize.getStyleClass().add("sv-button-minimize");
        buttonMinimize.setOnMouseClicked(evt -> setWindowState(WindowState.MINIMIZED));

        buttonMaximize = new Button();
        buttonMaximize.setId(MAXIMIZE_BUTTON_ID);
        buttonMaximize.setFocusTraversable(false);
        buttonMaximize.getStyleClass().add("sv-button-maximize");
        buttonMaximize.setOnMouseClicked(evt -> setWindowState(
                currentWindowState.get() == WindowState.MAXIMIZED ? WindowState.WINDOWED : WindowState.MAXIMIZED));

        buttonClose = new Button();
        buttonClose.setId(CLOSE_BUTTON_ID);
        buttonClose.setFocusTraversable(false);
        buttonClose.getStyleClass().add("sv-button-close");
        buttonClose.setOnMouseClicked(evt -> closeWindow());

        buttonPane = new HBox(themeButton, buttonMinimize, buttonMaximize, buttonClose);

        windowTitleBar = new BorderPane();
        windowTitleBar.setLeft(labelTitle);
        BorderPane.setAlignment(windowTitleBar, Pos.CENTER_LEFT);
        windowTitleBar.setCenter(headerPane);
        BorderPane.setAlignment(windowTitleBar, Pos.CENTER_RIGHT);
        windowTitleBar.setRight(buttonPane);
        BorderPane.setAlignment(windowTitleBar, Pos.CENTER_RIGHT);
        windowTitleBar.setPadding(new Insets(0, 0, 0, 10));
        windowTitleBar.getStyleClass().add("sv-title-bar");
        BorderPane.setAlignment(windowTitleBar, Pos.TOP_CENTER);

        windowPane.setTop(windowTitleBar);
        final StackPane shadowPane = new StackPane();
        shadowPane.getStyleClass().add("sv-shadow-pane");

        root = new StackPane(shadowPane, windowPane);
        root.setStyle("-fx-background-color:transparent;");
        root.setPadding(new Insets(ResizeHelper.SHADOW_AREA));
        root.heightProperty().addListener((obs, oVal, nVal) -> {
            if (oVal.doubleValue() != nVal.doubleValue()
                && nVal.doubleValue() != fxplorerWindow.getHeight()) {
                fxplorerWindow.setHeight(windowPane.getHeight());
            }
        });

        if (width > 0 && height > 0) {
            scene = new Scene(root, width, height, Color.TRANSPARENT);
        } else {
            scene = new Scene(root, Color.TRANSPARENT);
        }
        scene.getStylesheets().addAll(getClass().getResource("/styles/base.css").toExternalForm(),
                getClass().getResource("/styles/base_extras.css").toExternalForm(),
                getClass().getResource("/styles/fxplorer.css").toExternalForm());
        theme.set(Theme.LIGHT);
        fxplorerWindow.setScene(scene);
    }


    /**
     * Handles mouse drag events where the user attempts to move the window to another screen
     *
     * @param event The mouse event
     * @param screensForRectangle The list of screens involved in the mouse event
     */
    private void crossScreenDragEvent(final MouseEvent event, final ObservableList<Screen> screensForRectangle) {
        /* Screen detection seems to be Screen[0] is the screen where the mouse is. Okay. */
        final double mouseLocationX = event.getScreenX();
        final double mouseLocationY = event.getScreenY();
        final Rectangle2D currentScreenMouseBounds = screensForRectangle.get(0).getBounds();
        final Rectangle2D currentScreenVisualBounds = screensForRectangle.get(0).getVisualBounds();
        final Rectangle2D newScreenVisualBounds =
                screensForRectangle.get(screensForRectangle.size() - 1).getVisualBounds();

        if (fxplorerWindow.getY() < currentScreenVisualBounds.getMinY()) {
            double newY = currentScreenVisualBounds.getMinY();
            if (mouseLocationY < currentScreenMouseBounds.getMinY()) {
                newY = newScreenVisualBounds.getMaxY() - fxplorerWindow.getHeight();
            }
            fxplorerWindow.setY(newY);
        } else if (fxplorerWindow.getY() + fxplorerWindow.getHeight() > currentScreenVisualBounds
            .getMaxY()) {
            double newY = currentScreenVisualBounds.getMaxY() - fxplorerWindow.getHeight();
            if (mouseLocationY >= currentScreenMouseBounds.getMaxY()) {
                newY = newScreenVisualBounds.getMinY();
            }
            fxplorerWindow.setY(newY);
        }

        if (fxplorerWindow.getX() + fxplorerWindow.getWidth() > currentScreenVisualBounds.getMaxX()) {
            double newX = currentScreenVisualBounds.getMaxX() - fxplorerWindow.getWidth();
            if (mouseLocationX >= currentScreenMouseBounds.getMaxX()) {
                newX = newScreenVisualBounds.getMinX();
            }
            fxplorerWindow.setX(newX);
        } else if (fxplorerWindow.getX() < currentScreenVisualBounds.getMinX()) {
            double newX = newScreenVisualBounds.getMaxX() - fxplorerWindow.getWidth();
            if (mouseLocationX > currentScreenMouseBounds.getMinX()) {
                newX = currentScreenVisualBounds.getMinX();
            }
            fxplorerWindow.setX(newX);
        }
    }

    /**
     * Disable a component completely from being rendered, clickable or allocated space
     *
     * @param node The node to disable
     * @param isUsable Whether it should be enabled or disabled
     */
    private void enableComponent(final Node node, final Boolean isUsable) {
        node.setVisible(isUsable);
        node.setManaged(isUsable);
        node.setDisable(!isUsable);
    }

    /**
     * Provide the location and dimensions of the window to get a list of intersected screens
     *
     * @return The list of screens
     */
    private ObservableList<Screen> getScreensForWindow() {
        return Screen.getScreensForRectangle(fxplorerWindow.getX(), fxplorerWindow.getY(),
                fxplorerWindow.getWidth(), fxplorerWindow.getHeight());
    }

    /**
     * Initializes the layout.
     *
     * @param width width
     * @param height height
     */
    private void init(final double width, final double height) {
        buildRootNode(width, height);
        currentWindowState.set(WindowState.WINDOWED);
        fxplorerWindow.focusedProperty().addListener(
                (obs, oldValue, focused) -> windowPane.pseudoClassStateChanged(FOCUSED_PSEUDO_CLASS, focused));
        assignTitleBarEvents();
        ResizeHelper.addResizeHandler(this);
        fxplorerWindow.getIcons().addListener((ListChangeListener) e -> updateIcons());
        getIcons().addAll(Utils.getAppIcons());
    }

    /**
     * Move the window relative to the recorded top-left position
     *
     * @param event The drag mouse event
     */
    private final void moveFxplorerWindow(final MouseEvent event) {
        if (canDrag(event)) {
            final double xOffset = event.getScreenX() - sceneXOffset;
            final double yOffset = event.getScreenY() - sceneYOffset;

            fxplorerWindow.setX(xOffset);
            fxplorerWindow.setY(yOffset);

            setWindowState(WindowState.WINDOWED);
            event.consume();
        }
    }

    /**
     * Performs the required actions when the theme is modified.
     *
     * @param newTheme new theme to apply
     */
    private void onThemeChanged(final Theme newTheme) {
        lightThemeItem.setSelected(newTheme == Theme.LIGHT);
        darkThemeItem.setSelected(newTheme == Theme.DARK);

        final ObservableList<String> styleSheets = scene.getStylesheets();
        styleSheets.removeAll(getClass().getResource("/styles/dark_theme.css").toExternalForm(),
                getClass().getResource("/styles/light_theme.css").toExternalForm());
        final int index = styleSheets.size() - 2;
        if (newTheme == Theme.LIGHT) {
            styleSheets.add(index, getClass().getResource("/styles/light_theme.css").toExternalForm());
        } else if (newTheme == Theme.DARK) {
            styleSheets.add(index, getClass().getResource("/styles/dark_theme.css").toExternalForm());
        }
    }

    /**
     * Record the top-left location of the window for drag event handling
     *
     * @param event The drag mouse event
     */
    private final void recordFxplorerWindowLocation(final MouseEvent event) {
        if (canDrag(event)) {
            sceneXOffset = event.getSceneX();
            sceneYOffset = event.getSceneY();
            fxplorerWindow.getScene().setCursor(Cursor.MOVE);
        }
    }

    /**
     * Resets the mouse pointer back to default state
     *
     * @param event The drag mouse event
     */
    private final void resetMousePointer(final MouseEvent event) {
        if (canDrag(event)) {
            fxplorerWindow.getScene().setCursor(Cursor.DEFAULT);
        }
    }

    /**
     * Updates the title icons.
     */
    private void updateIcons() {
        if (!fxplorerWindow.getIcons().isEmpty()) {
            final ImageView icon = new ImageView(fxplorerWindow.getIcons().get(0));
            icon.setFitWidth(24);
            icon.setFitHeight(24);
            labelTitle.setGraphic(icon);
        } else {
            labelTitle.setGraphic(null);
        }
    }
}
