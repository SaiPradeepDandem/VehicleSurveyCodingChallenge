package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BackgroundFill;

public class BackgroundFillValue implements Value, Serializable {

    private PaintValue fill;

    private InsetsValue insets;

    private CornerRadiiValue radii;

    private BackgroundFillValue() {
        /* private for snapshot */
    }

    public BackgroundFillValue(final BackgroundFill bgFill) {
        fill = new PaintValue(bgFill.getFill());
        insets = new InsetsValue(bgFill.getInsets());
        radii = new CornerRadiiValue(bgFill.getRadii());
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BackgroundFillValue that)) {
            return false;
        }
        return Objects.equals(fill, that.fill)
            && Objects.equals(insets, that.insets)
            && Objects.equals(radii, that.radii);
    }

    @Override
    public BackgroundFill getValue() {
        return new BackgroundFill(fill.getValue(), radii.getValue(), insets.getValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(fill, insets, radii);
    }

    @Override
    public BackgroundFillValue snapshot() {
        final BackgroundFillValue snapshot = new BackgroundFillValue();
        snapshot.fill = fill == null ? null : fill.snapshot();
        snapshot.insets = insets == null ? null : insets.snapshot();
        snapshot.radii = radii == null ? null : radii.snapshot();
        return snapshot;
    }

    @Override
    public String toString() {
        return "BackgroundFillValue{"
            +
            "fill="
            + fill
            +
            ", insets="
            + insets
            +
            ", radii="
            + radii
            +
            '}';
    }
}
