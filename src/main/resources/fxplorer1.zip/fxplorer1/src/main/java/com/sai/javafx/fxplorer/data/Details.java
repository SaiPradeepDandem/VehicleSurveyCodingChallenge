package com.sai.javafx.fxplorer.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.util.Pair;

/**
 * Abstract class to hold the basic details of the object.
 */
public abstract class Details implements Serializable, TreeData {

    /** Specifies the type of dispatch event. */
    private DispatchType dispatchType;

    /** Unique id of the details object. */
    private int uId;

    /** VM id of the remote application. */
    private int vmId;

    /** JavaFX id of the node. */
    private String fxId;

    /** Specifies if the details are related to an object in popup. */
    private boolean isPopup;

    /** List of stylesheets. */
    protected List<String> styleSheets = new ArrayList<>();

    /** Map holding the details of all properties of a node/scene/window. */
    protected Map<String, PropertyDetails> fullProperties = new HashMap<>();

    /** Class name of the object that needs to be displayed. */
    protected String className;

    /**
     * Constructor.
     */
    public Details() {
        /* Empty */
    }

    /**
     * Compares the full properties of the provided object to this object, to identify any changes in the values.
     * The changed properties details will be loaded into the provided result map.
     *
     * @param other other object that need to be compared
     * @param result map holding the changes details
     */
    public void compare(final Details other,
            final Map<String, Pair<PropertyDetails, PropertyDetails>> result) {
        final Map<String, PropertyDetails> otherProps = other.getFullProperties();
        getFullProperties().forEach((name, prop) -> {
            if (!prop.equals(otherProps.get(name))) {
                result.put(name, new Pair<>(prop.snapshot(), otherProps.get(name).snapshot()));
            }
        });
    }

    /**
     * Gets the class name of the object to display.
     */
    @Override
    public String getClassName() {
        return className;
    }

    /**
     * Gets the type of dispatch event.
     *
     * @return type of dispatch event
     */
    public final DispatchType getDispatchType() {
        return dispatchType;
    }

    /**
     * Map holding the full properties of the current object.
     *
     * @return map of properties
     */
    public final Map<String, PropertyDetails> getFullProperties() {
        return fullProperties;
    }

    /**
     * JavaFX id of the object.
     *
     * @return id of the object
     */
    public final String getFxId() {
        return fxId;
    }

    /**
     * Gets the list of stylesheets.
     *
     * @return list of stylesheets
     */
    public final List<String> getStyleSheets() {
        return styleSheets;
    }

    @Override
    public final int getUId() {
        return uId;
    }

    /**
     * Returns the VM id of the remote application.
     *
     * @return VM id of the remote application
     */
    public final int getVmId() {
        return vmId;
    }

    @Override
    public boolean isMatched(final String key, final String text) {
        return false;
    }

    /**
     * Specifies if the details are related to an object of a Popup.
     *
     * @return {@code true} if the object is related to a Popup
     */
    public boolean isPopup() {
        return isPopup;
    }

    /**
     * Sets the class name of the object.
     *
     * @param className class name
     */
    public final void setClassName(final String className) {
        this.className = className;
    }

    /**
     * Sets the dispatch type.
     *
     * @param dispatchType dispatch type
     */
    public final void setDispatchType(final DispatchType dispatchType) {
        this.dispatchType = dispatchType;
    }

    /**
     * Sets the JavaFX id of the object.
     *
     * @param fxId id of the object
     */
    public final void setFxId(final String fxId) {
        this.fxId = fxId;
    }

    /**
     * Sets the unique identifier of the object.
     *
     * @param uId unique identifier of the object
     */
    public final void setUId(final int uId) {
        this.uId = uId;
    }

    /**
     * Sets the VM id of the remote application.
     *
     * @param aVmId VM id of the remote application
     */
    public final void setVmId(final int aVmId) {
        this.vmId = aVmId;
    }

    /**
     * Returns the copy of the current object with all its properties and values.
     *
     * @return copy of the current object
     */
    public abstract Details snapshot();

    /**
     * Removes all the listeners added to the properties.
     */
    protected void reset() {
        fullProperties.values().forEach(PropertyDetails::removeListener);
    }

    /**
     * Sets if the current object is related to a Popup or not.
     *
     * @param popup {@code true} if the object is related to a Popup
     */
    protected void setPopup(final boolean popup) {
        isPopup = popup;
    }

    /**
     * Copies the properties of current object to the given object.
     *
     * @param snapshot object to which the details need to be copied to
     */
    protected void snapshot(final Details snapshot) {
        snapshot.vmId = vmId;
        snapshot.uId = uId;
        snapshot.fxId = fxId;
        snapshot.className = className;
        getFullProperties().forEach((name, prop) -> snapshot.getFullProperties().put(name, prop.snapshot()));
    };
}
