package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BorderWidths;

public class BorderWidthsValue implements Value, Serializable {

    private double top;

    private double right;

    private double bottom;

    private double left;

    private boolean topAsPercentage;

    private boolean rightAsPercentage;

    private boolean bottomAsPercentage;

    private boolean leftAsPercentage;

    private BorderWidthsValue() {
        /* private for snapshot */
    }

    public BorderWidthsValue(final BorderWidths bw) {
        top = bw.getTop();
        right = bw.getRight();
        bottom = bw.getBottom();
        left = bw.getLeft();
        topAsPercentage = bw.isTopAsPercentage();
        rightAsPercentage = bw.isRightAsPercentage();
        bottomAsPercentage = bw.isBottomAsPercentage();
        leftAsPercentage = bw.isLeftAsPercentage();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BorderWidthsValue that)) {
            return false;
        }
        return Double.compare(that.top, top) == 0
            && Double.compare(that.right, right) == 0
            && Double.compare(that.bottom, bottom) == 0
            && Double.compare(that.left, left) == 0
            && topAsPercentage == that.topAsPercentage
            && rightAsPercentage == that.rightAsPercentage
            && bottomAsPercentage == that.bottomAsPercentage
            && leftAsPercentage == that.leftAsPercentage;
    }

    @Override
    public BorderWidths getValue() {
        return new BorderWidths(top, right, bottom, left, topAsPercentage, rightAsPercentage, bottomAsPercentage,
                                leftAsPercentage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(top, right, bottom, left, topAsPercentage, rightAsPercentage, bottomAsPercentage,
                leftAsPercentage);
    }

    @Override
    public BorderWidthsValue snapshot() {
        final BorderWidthsValue snapshot = new BorderWidthsValue();
        snapshot.top = top;
        snapshot.right = right;
        snapshot.bottom = bottom;
        snapshot.left = left;
        snapshot.topAsPercentage = topAsPercentage;
        snapshot.rightAsPercentage = rightAsPercentage;
        snapshot.bottomAsPercentage = bottomAsPercentage;
        snapshot.leftAsPercentage = leftAsPercentage;
        return snapshot;
    }

    @Override
    public String toString() {
        return "BorderWidthsValue{"
            +
            "top="
            + top
            +
            ", right="
            + right
            +
            ", bottom="
            + bottom
            +
            ", left="
            + left
            +
            ", topAsPercentage="
            + topAsPercentage
            +
            ", rightAsPercentage="
            + rightAsPercentage
            +
            ", bottomAsPercentage="
            + bottomAsPercentage
            +
            ", leftAsPercentage="
            + leftAsPercentage
            +
            '}';
    }
}
