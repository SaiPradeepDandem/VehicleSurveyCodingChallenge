package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;

public class BackgroundValue implements Value, Serializable {

    private final List<BackgroundFillValue> fills = new ArrayList<>();

    private final List<BackgroundImageValue> images = new ArrayList<>();

    private BackgroundValue() {
        /* private for snapshot */
    }

    public BackgroundValue(final Background background) {
        background.getFills().forEach(fill -> fills.add(new BackgroundFillValue(fill)));
        background.getImages().forEach(image -> images.add(new BackgroundImageValue(image)));
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BackgroundValue that)) {
            return false;
        }
        return Objects.equals(fills, that.fills) && Objects.equals(images, that.images);
    }

    @Override
    public Background getValue() {
        final List<BackgroundFill> bFills = new ArrayList<>();
        final List<BackgroundImage> bImages = new ArrayList<>();
        fills.forEach(fill -> bFills.add(fill.getValue()));
        images.forEach(image -> bImages.add(image.getValue()));
        return new Background(bFills, bImages);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fills, images);
    }

    @Override
    public BackgroundValue snapshot() {
        final BackgroundValue snapshot = new BackgroundValue();
        fills.forEach(fill -> snapshot.fills.add(fill.snapshot()));
        images.forEach(image -> snapshot.images.add(image.snapshot()));
        return snapshot;
    }

    @Override
    public String toString() {
        return "BackgroundValue{"
            +
            "fills="
            + fills
            +
            ", images="
            + images
            +
            '}';
    }
}
