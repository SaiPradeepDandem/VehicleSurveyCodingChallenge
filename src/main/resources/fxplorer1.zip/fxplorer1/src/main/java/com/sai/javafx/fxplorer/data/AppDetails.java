package com.sai.javafx.fxplorer.data;

import java.util.Map;

import com.sai.javafx.fxplorer.utils.Utils;

import javafx.util.Pair;

/**
 * Details related to the application.
 */
public final class AppDetails extends Details {

    /**
     * Constructor.
     *
     * @param vmId VM id of the application
     */
    public AppDetails(final int vmId) {
        setVmId(vmId);
        setUId(vmId);
    }

    @Override
    public final void compare(final Details other,
            final Map<String, Pair<PropertyDetails, PropertyDetails>> result) {
        throw new IllegalStateException("Cannot compare application");
    }

    @Override
    public final String getClassName() {
        return Utils.VM_CLASS_NAME;
    }

    @Override
    public final String getDisplayName() {
        return "VM - " + getVmId();
    }

    @Override
    public final void reset() {
        super.reset();
    }

    @Override
    public final Details snapshot() {
        throw new IllegalStateException("Cannot take snapshot of application");
    }
}
