package com.sai.javafx.fxplorer.utils;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;

/**
 * Utility class for the colors.
 */
public final class ColorUtils {

    /**
     * Constructor.
     */
    public ColorUtils() {
        /* Empty */
    }

    /**
     * Returns the contrast color of the provided {@link Color}. The return value will be in gray/white.
     *
     * @param paint Color reference object
     * @return Contrast color
     */
    public static Paint getContrastColor(final Paint paint) {
        if (paint instanceof Color) {
            final Color color = (Color) paint;
            final double base = (color.getRed() + color.getGreen() + color.getBlue()) / 3 > 0.5 ? 0 : 1;
            final int val = (int) (255 * base);

            return Color.rgb(val, val, val);
        } else if (paint instanceof LinearGradient) {
            final String grd = paint.toString().replaceAll("0x", "#");
            final List<String> tokens = new ArrayList<>();
            String s = grd;
            while (s.indexOf("#") > -1) {
                tokens.add(s.substring(0, s.indexOf("#")));
                s = s.substring(s.indexOf("#"));
                tokens.add(s.substring(0, 9));
                s = s.substring(9);
            }
            tokens.add(s);
            String newColor = "";
            for (final String tkn : tokens) {
                if (tkn.startsWith("#")) {
                    newColor += getOppositeColor(tkn);
                } else {
                    newColor += tkn;
                }
            }
            return LinearGradient.valueOf(newColor);
        }
        return paint;
    }

    /**
     * Returns the contrast color provided hex color.
     *
     * @param hex hex color code
     * @return contrast color code
     */
    public static String getContrastColor(final String hex) {
        final Color color = Color.web(hex);
        /* Calculate the luminance of the color */
        final double luminance = 0.2126 * color.getRed() + 0.7152 * color.getGreen() + 0.0722 * color.getBlue();

        /* Determine the contrast color */
        if (luminance >= 0.5) {
            return "#000000";
        } else {
            return "#FFFFFF";
        }
    }

    /**
     * Returns the hex color value for the provided {@link Color}.
     *
     * @param paint Color reference object
     * @return Hex Color value in {@link Color}
     */
    public static String getHexColor(final Paint paint) {
        if (paint instanceof Color) {
            final Color color = (Color) paint;
            return "#"
                + colorChannelToHex(color.getRed())
                + colorChannelToHex(color.getGreen())
                + colorChannelToHex(color.getBlue())
                + colorChannelToHex(color.getOpacity());
        }
        return "-";
    }

    /**
     * Returns the opposite color of the provided color.
     *
     * @param color color instance
     * @return opposite color
     */
    public static Color getOppositeColor(final Color color) {
        /* Get the hue value of the original color */
        final double hue = color.getHue();
        /* Get the saturation value of the original color */
        final double saturation = color.getSaturation();
        /* Get the brightness value of the original color */
        final double brightness = color.getBrightness();
        /* Invert the hue value by adding 180 degrees and wrapping around if necessary */
        final double invertedHue = (hue + 180) % 360;
        /* Create a new color with the inverted HSB values */
        return Color.hsb(invertedHue, saturation, brightness);
    }

    /**
     * Returns the opposite color of the provided hex color.
     *
     * @param hex hex color value
     * @return opposite color
     */
    public static String getOppositeColor(final String hex) {
        return getHexColor(getOppositeColor(Color.web(hex)));
    }

    /**
     * Returns the RGBA color values for the provided {@link Color}.
     *
     * @param paint Color reference object
     * @return RGBA color values in {@link Color}
     */
    public static String getRGBAColor(final Paint paint) {
        if (paint instanceof Color) {
            final Color color = (Color) paint;
            final int r = (int) Math.round(color.getRed() * 255.0);
            final int g = (int) Math.round(color.getGreen() * 255.0);
            final int b = (int) Math.round(color.getBlue() * 255.0);
            final int a = (int) Math.round(color.getOpacity() * 255.0);
            return String.format("RGBA : (%s, %s, %s, %s)", r, g, b, a);
        }
        return "-";
    }

    /**
     * Converts the provided hex color code to the Color instance.
     *
     * @param hex hex color code
     * @return color instance
     */
    public static Color hexToColor(String hex) {
        if (hex.startsWith("#") && hex.length() == 9) {
            hex = hex.substring(0, 7);
        }
        return Color.web(hex);
    }

    /**
     * Changes the given color value to hex value.
     *
     * @param channelValue color channel value
     * @return Hex value of color channel
     */
    private static String colorChannelToHex(final double channelValue) {
        String hex = Integer.toHexString((int) Math.min(Math.round(channelValue * 255), 255));
        if (hex.length() == 1) {
            hex = "0" + hex;
        }
        return hex.toUpperCase();
    }
}
