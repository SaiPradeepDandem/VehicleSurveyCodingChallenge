package com.sai.javafx.fxplorer.connector;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import com.sai.javafx.fxplorer.data.DetailsFactory;
import com.sai.javafx.fxplorer.data.DispatchType;
import com.sai.javafx.fxplorer.data.WindowDetails;
import com.sai.javafx.fxplorer.utils.Utils;
import com.sai.javafx.fxplorer.widgets.NodeHighlighter;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventDispatcher;
import javafx.scene.Node;
import javafx.scene.input.InputEvent;
import javafx.stage.PopupWindow;
import javafx.stage.Window;

/**
 * Implementation for the interface for remote applications to communicate with fxplorer.
 */
public class RemoteAppImpl extends UnicastRemoteObject implements IRemoteApp {

    /** Logger. */
    private static final Logger LOGGER = Logger.getLogger(RemoteAppImpl.class.getName());

    /** Port number of the remote application. */
    private final int port;

    /** Port number of the server. */
    private final int serverPort;

    /** VM id of the remote application. */
    private final int appId;

    /** Instance of dispatcher. */
    private Dispatcher dispatcher;

    /** Specifies whether to block the dispatching of Popup hiding or not. */
    private boolean blockHiding;

    /** Specifies whether to highlight and select the node in the remote application. */
    private boolean selectNode;

    /** Specifies the node id that is currently previewed in the fxplorer. */
    private int previewNodeId;

    /** NodeHighlighter instance for the remote application. */
    private NodeHighlighter highlighter;

    /** Map holding the details of all windows in the current application. */
    private final Map<Integer, WindowDetails> windowDetailsMap = new HashMap<>();

    /** Shutdown hook of the application. */
    private final Thread shutdownHook = new Thread(() -> {
        LOGGER.info(() -> "Closing the connection from shutdown hook.");
        dispatcher.close();
    });

    /** Listener for windows add/delete in the application. */
    private final ListChangeListener<? super Window> windowListener = p -> {
        while (p.next()) {
            p.getAddedSubList().forEach(w -> dispatchWindow(w, DispatchType.WINDOW_ADDED));
            p.getRemoved().forEach(w -> dispatchWindow(w, DispatchType.WINDOW_DELETED));
        }
        if (Window.getWindows().isEmpty()) {
            LOGGER.info(() -> "Closing the connection as no windows are open.");
            dispatcher.close();
            /* Remove the shutdown hook as the connection is closed. */
            Runtime.getRuntime().removeShutdownHook(shutdownHook);
        }
    };

    /**
     * Constructor.
     *
     * @param aPort port number of the application
     * @param aServerPort port number of the server
     * @param aAppId VM id of the application
     * @throws RemoteException
     */
    public RemoteAppImpl(final int aPort, final int aServerPort, final int aAppId) throws RemoteException {
        port = aPort;
        serverPort = aServerPort;
        appId = aAppId;
        try {
            RMIUtils.bindApplication(this, port);
            Runtime.getRuntime().addShutdownHook(shutdownHook);
        } catch (final Exception e) {
            throw new RemoteException("Error starting remote agent", e);
        }

        RMIUtils.findFxplorer(serverPort, fxplorerInterface -> {
            dispatcher = new Dispatcher(aPort, fxplorerInterface, this);
            LOGGER.info(() -> "Fxplorer (a.k.a server) found:" + fxplorerInterface);

            /* Intimate the server that a new connection is established */
            dispatcher.onAgentStarted(aPort, aAppId);
        });
    }

    /**
     * Gets the id of the preview node.
     *
     * @return id of the preview node
     */
    public final int getPreviewNodeId() {
        return previewNodeId;
    }

    @Override
    public final void handShake() {
        LOGGER.info(() -> "Application is ready to be inspected in Fxplorer !!");

        /* Send windows details */
        final ObservableList<Window> windows = Window.getWindows();
        windows.forEach(w -> dispatchWindow(w, DispatchType.WINDOW_ADDED));
        windows.addListener(windowListener);

        /* Hold for a while to let the things settle. */
        try {
            Thread.sleep(2000);
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }

        /* Start polling for delivering property updates */
        dispatcher.start();
    }

    @Override
    public final void highlightNode(final int windowId, final int nodeId) throws RemoteException {
        LOGGER.info(() -> "Highlight node in window : " + windowId + " , node : " + nodeId);
        final Node node = findNodeInWindow(windowId, nodeId);
        if (node != null) {
            Platform.runLater(() -> getHighlighter().applyOn(node));
        }
    }

    @Override
    public final void removeHighlight(final int windowId) throws RemoteException {
        LOGGER.info(() -> "Remove highlight in window : " + windowId);
        final WindowDetails wd = windowDetailsMap.get(windowId);
        if (wd != null) {
            Platform.runLater(() -> getHighlighter().clear(wd.getWindow().getScene()));
        }
    }

    @Override
    public final void setBlockPopupHiding(final boolean blockHiding) throws RemoteException {
        this.blockHiding = blockHiding;
    }

    @Override
    public final void setPreviewNode(final int windowId, final int nodeId) throws RemoteException {
        previewNodeId = nodeId;
        /* If there is no need of any preview, then clear the current registered preview events */
        if (previewNodeId == -1) {
            dispatcher.clearPreviewEvents();
        } else {
            /* If there is a preview node, then update the preview back to the fxplorer */
            final Node node = findNodeInWindow(windowId, nodeId);
            if (node != null) {
                dispatcher.dispatchPreview(appId, windowId, true, node);
            }
        }
    }

    @Override
    public final void setSelectNode(final boolean selectNode) throws RemoteException {
        this.selectNode = selectNode;
    }

    /**
     * Removes all the listeners added to the window.
     */
    final void removeListeners() {
        windowDetailsMap.values().forEach(WindowDetails::reset);
        windowDetailsMap.clear();
        Window.getWindows().removeListener(windowListener);
    }

    /**
     * Dispatches the window details.
     *
     * @param window window instance
     * @param dispatchType dispatch type
     */
    private void dispatchWindow(final Window window, final DispatchType dispatchType) {
        if (dispatchType == DispatchType.WINDOW_ADDED) {

            Platform.runLater(() -> {
                final WindowDetails wd = DetailsFactory.fromWindow(dispatcher, appId, window, dispatchType);
                installNodeSelectListeners(wd);

                if (window instanceof final PopupWindow popupWindow) {
                    final EventDispatcher eventDispatcher = popupWindow.getEventDispatcher();
                    wd.setOrigEventDispatcher(eventDispatcher);
                    popupWindow.setEventDispatcher((event, tail) -> {
                        /* Blocking the auto hide of popup for inspecting. */
                        if (blockHiding && !(event instanceof InputEvent)) {
                            return null;
                        }
                        return eventDispatcher.dispatchEvent(event, tail);
                    });
                    wd.setPopup(true);
                }

                windowDetailsMap.put(window.hashCode(), wd);
                dispatcher.dispatchWindow(appId, wd);
            });
        } else {
            final WindowDetails wd = windowDetailsMap.remove(window.hashCode());
            if (wd != null) {
                wd.reset();
                if (!(wd.isPopup() && blockHiding)) {
                    wd.setDispatchType(DispatchType.WINDOW_DELETED);
                    dispatcher.dispatchWindow(appId, wd);
                } else {
                    /* Send the preview of the popup scenegraph instantly */
                    dispatcher.dispatchPopupPreview(appId, wd.getUId(), window.getScene().getRoot());
                }
            }
        }
    }

    /**
     * Finds the provided node in the given window.
     *
     * @param windowId id of the window
     * @param nodeId id of the node
     * @return node matching the provided id
     */
    private Node findNodeInWindow(final int windowId, final int nodeId) {
        final WindowDetails wd = windowDetailsMap.get(windowId);
        if (wd != null) {
            return Utils.findNode(wd.getWindow().getScene().getRoot(), nodeId);
        }
        return null;
    }

    /**
     * Returns the highlighter instance for the application.
     *
     * @return node highlighter
     */
    private NodeHighlighter getHighlighter() {
        if (highlighter == null) {
            highlighter = new NodeHighlighter();
        }
        return highlighter;
    }

    /**
     * Installs the listeners for node highlighting and selecting.
     *
     * @param windowDetails window details
     */
    private void installNodeSelectListeners(final WindowDetails windowDetails) {
        final Window window = windowDetails.getWindow();
        windowDetails.setPressedHandler(e -> {
            if (selectNode && e.getTarget() instanceof final Node node) {
                dispatcher.selectNode(appId, window.hashCode(), node.hashCode());
                getHighlighter().clear(window.getScene());
                e.consume();
            }
        });
        windowDetails.setMovedHandler(e -> {
            if (selectNode && e.getTarget() instanceof final Node node) {
                getHighlighter().applyOn(node);
            }
        });
        windowDetails.setExitHandler(e -> {
            if (selectNode) {
                getHighlighter().clear(window.getScene());
            }
        });
        windowDetails.setHideHandler(e -> {
            if (selectNode) {
                getHighlighter().clear(window.getScene());
            }
        });
    }
}
