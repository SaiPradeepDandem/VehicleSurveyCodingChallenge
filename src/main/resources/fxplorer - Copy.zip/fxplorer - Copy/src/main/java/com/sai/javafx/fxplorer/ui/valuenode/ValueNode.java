package com.sai.javafx.fxplorer.ui.valuenode;

import com.sai.javafx.fxplorer.data.PropertyDetails;

import javafx.scene.Node;

/**
 * Interface for representing the node value details.
 */
public interface ValueNode {

    /**
     * Returns the layout node the displays the value.
     *
     * @return the layout node
     */
    Node getNode();

    /**
     * Highlights the layout.
     */
    void highlight();

    /**
     * Builds the layout to display the property details.
     *
     * @param propertyDetails property details
     */
    void setValue(PropertyDetails propertyDetails);
}
