package com.sai.javafx.fxplorer.ui.valuenode;

import static com.sai.javafx.fxplorer.utils.Utils.px;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.values.InsetsValue;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

/**
 * Specifies the insets value.
 */
public final class InsetsValueNode implements ValueNode {

    /** GridPane to show the insets. */
    private final GridPane insetGrid = new GridPane();

    /** Label to show the top insets value. */
    private final Label top = new Label();

    /** Label to show the right insets value. */
    private final Label right = new Label();

    /** Label to show the bottom insets value. */
    private final Label bottom = new Label();

    /** Label to show the left insets value. */
    private final Label left = new Label();

    /**
     * Constructor.
     */
    public InsetsValueNode() {
        final StackPane content = new StackPane(new Label("Content"));
        content.getStyleClass().add("content-node");
        GridPane.setMargin(insetGrid, new Insets(5, 0, 0, 0));
        insetGrid.getStyleClass().add("insets-grid");
        insetGrid.setVgap(2);
        insetGrid.setHgap(2);
        insetGrid.addRow(0, new Text(), top, new Text());
        insetGrid.addRow(1, left, content, right);
        insetGrid.addRow(2, new Text(), bottom, new Text());
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.CENTER);
        insetGrid.getColumnConstraints().addAll(new ColumnConstraints(), cc);
        insetGrid.setMaxWidth(Region.USE_PREF_SIZE);
    }

    @Override
    public final Node getNode() {
        return insetGrid;
    }

    @Override
    public final void highlight() {
        /* Empty */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        final Insets insets = ((InsetsValue) propertyDetails.getValue()).getValue();
        top.setText(px(insets.getTop()));
        left.setText(px(insets.getLeft()));
        right.setText(px(insets.getRight()));
        bottom.setText(px(insets.getBottom()));
    }
}
