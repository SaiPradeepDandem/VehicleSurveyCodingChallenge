package com.sai.javafx.fxplorer.values;

import java.util.Objects;

public class StringValue implements Value {

    private String value;

    private StringValue() {
        /* private for snapshot */
    }

    public StringValue(final String v) {
        value = v;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final StringValue that)) {
            return false;
        }
        return Objects.equals(value, that.value);
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public StringValue snapshot() {
        final StringValue snapshot = new StringValue();
        snapshot.value = value;
        return snapshot;
    }

    @Override
    public String toString() {
        return "StringValue{"
            +
            "value='"
            + value
            + '\''
            +
            '}';
    }
}
