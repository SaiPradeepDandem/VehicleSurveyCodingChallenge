package com.sai.javafx.fxplorer.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.ui.valuenode.ValueNode;
import com.sai.javafx.fxplorer.utils.LabelUtils;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.util.Pair;

/**
 * Controller for snapshot functionality.
 */
public final class SnapshotController {

    @FXML
    private BorderPane snapshotsRoot;

    @FXML
    private ListView<String> snapshotsListView;

    /** Reference for layout controller. */
    private final LayoutController layoutController;

    /** Reference for details controller. */
    private final DetailsController detailsController;

    /** Current selected tree item to which the snapshot to be applied. */
    private FxplorerTreeItem fxplorerTreeItem;

    /**
     * Constructor.
     *
     * @param layoutController instance of layout controller
     */
    public SnapshotController(final LayoutController layoutController) {
        this.layoutController = layoutController;
        load();
        detailsController = new DetailsController(null);
        snapshotsRoot.setCenter(detailsController.getDetailsContainer());
    }

    /**
     * Returns the root node of the snapshot page.
     *
     * @return snapshotsRoot
     */
    public final BorderPane getSnapshotsRoot() {
        return snapshotsRoot;
    }

    /**
     * Applies the provided theme styling.
     *
     * @param theme new theme to apply
     */
    public final void onThemeUpdate(final Theme theme) {
        detailsController.onThemeUpdate(theme);
    }

    /**
     * Updates the snapshot details of the provided current selected tree item.
     *
     * @param item current tree item
     */
    public final void update(final FxplorerTreeItem item) {
        fxplorerTreeItem = item;
        if (item != null) {
            layoutController.updateSnapshotsTab(item.getSnapshotCount());

            /* Take backup of current selection */
            final String selected = snapshotsListView.getSelectionModel().getSelectedItem();

            /* Repopulate the tree */
            snapshotsListView.getItems().clear();
            item.getSnapshots().keySet().stream().sorted().forEach(key -> {
                snapshotsListView.getItems().add(key);
            });

            /* Select the previous selection if exists */
            if (selected != null) {
                snapshotsListView.getSelectionModel().select(selected);
            }
        } else {
            layoutController.updateSnapshotsTab(0);
        }
    }

    @FXML
    final void initialize() {
        final ContextMenu contextMenu = new ContextMenu();
        final MenuItem compareItem = new MenuItem("Compare");
        compareItem.setOnAction(e1 -> compareSnapshots());
        contextMenu.getItems().add(compareItem);

        final EventHandler<MouseEvent> clickedEvent = e -> {
            if (e.getButton() == MouseButton.SECONDARY
                && snapshotsListView.getSelectionModel().getSelectedItems().size() == 2) {
                contextMenu.show((Node) e.getTarget(), Side.BOTTOM, 0, 0);
            }
        };
        snapshotsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        snapshotsListView.getSelectionModel().selectedItemProperty().addListener((obs, old, sel) -> {
            if (sel != null) {
                detailsController.showDetails(fxplorerTreeItem.getSnapshot(sel));
            } else {
                detailsController.showDetails(null);
            }
        });
        snapshotsListView.setCellFactory(param -> new ListCell<>() {

            private final GridPane pane = new GridPane();

            private final Label number = LabelUtils.bold("");

            private final Label time = new Label();

            {
                final ColumnConstraints cc = new ColumnConstraints();
                cc.setPrefWidth(30);
                pane.getColumnConstraints().add(cc);
                pane.addRow(0, number, time);
            }

            @Override
            protected final void updateItem(final String item, final boolean empty) {
                super.updateItem(item, empty);
                removeEventHandler(MouseEvent.MOUSE_CLICKED, clickedEvent);
                if (item != null) {
                    number.setText(fxplorerTreeItem.getSnapshotIndex(item) + 1 + ".");
                    time.setText(item);
                    setGraphic(pane);
                    addEventHandler(MouseEvent.MOUSE_CLICKED, clickedEvent);
                } else {
                    setGraphic(null);
                }
            }
        });
    }

    /**
     * Builds the comparison node for the provided details.
     *
     * @param title1 first node title (snapshot time)
     * @param title2 second node title (snapshot time)
     * @param results details of both the nodes
     * @return scroll pane
     */
    private ScrollPane buildCompareNode(final String title1, final String title2,
            final Map<String, Pair<PropertyDetails, PropertyDetails>> results) {
        final GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(20);
        grid.setVgap(8);
        final ColumnConstraints cc = new ColumnConstraints();
        cc.setHalignment(HPos.RIGHT);
        grid.getColumnConstraints().add(cc);
        grid.addRow(0, new Text(), buildHeaderLabel(title1), buildHeaderLabel(title2));
        if (results.isEmpty()) {
            grid.add(new Label("Both snapshots are identical"), 0, 1, 3, 1);
        } else {
            final RowConstraints rc = new RowConstraints();
            rc.setValignment(VPos.TOP);
            final AtomicInteger i = new AtomicInteger(1);
            results.keySet().stream().sorted().forEach(prop -> {

                final PropertyDetails p1 = results.get(prop).getKey();
                final ValueNode p1ValueNode = LayoutBuilder.buildValueNode(p1);
                p1ValueNode.setValue(p1);

                final PropertyDetails p2 = results.get(prop).getValue();
                final ValueNode p2ValueNode = LayoutBuilder.buildValueNode(p2);
                p2ValueNode.setValue(p2);

                final Label propLbl = LayoutBuilder.buildPropLabel(prop);
                propLbl.setMinWidth(Region.USE_PREF_SIZE);
                propLbl.setAlignment(Pos.CENTER_RIGHT);
                propLbl.setTextAlignment(TextAlignment.RIGHT);

                grid.addRow(i.getAndIncrement(), propLbl, p1ValueNode.getNode(), p2ValueNode.getNode());
                final Separator sep = new Separator();
                sep.getStyleClass().add("row-separator");
                grid.add(sep, 0, i.getAndIncrement(), 3, 1);
                grid.getRowConstraints().add(rc);
            });
        }
        final ScrollPane root = new ScrollPane();
        root.setContent(grid);
        root.setFitToHeight(true);
        root.setFitToWidth(true);
        return root;
    }

    /**
     * Builds the header label.
     *
     * @param title title
     * @return label
     */
    private Label buildHeaderLabel(final String title) {
        final Label lbl = LabelUtils.bold(title);
        lbl.getStyleClass().add("comparison-title");
        return lbl;
    }

    /**
     * Compares the selected snapshots in the listView.
     */
    private void compareSnapshots() {
        final String snp1 = snapshotsListView.getSelectionModel().getSelectedItems().get(0);
        final String snp2 = snapshotsListView.getSelectionModel().getSelectedItems().get(1);
        final Details details1 = fxplorerTreeItem.getSnapshot(snp1);
        final Details details2 = fxplorerTreeItem.getSnapshot(snp2);
        final Map<String, Pair<PropertyDetails, PropertyDetails>> result = new HashMap<>();
        details1.compare(details2, result);

        final ScrollPane root = buildCompareNode(snp1, snp2, result);
        final FxplorerWindow window = new FxplorerWindow(root, 800, 700);
        window.setWindowOwner(snapshotsListView.getScene().getWindow());
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(snp1 + " vs " + snp2);
        window.updateTheme(((FxplorerWindow) snapshotsListView.getScene().getWindow()).themeProperty().get());
        window.showWindow();
    }

    /**
     * Loads the snapshots layout.
     */
    private void load() {
        try {
            final FXMLLoader loader = new FXMLLoader(getClass().getResource("snapshots.fxml"));
            loader.setController(this);
            loader.load();
        } catch (final Exception e) {
            e.printStackTrace();
            throw new IllegalStateException("Unable to load the snapshots fxml");
        }
    }
}
