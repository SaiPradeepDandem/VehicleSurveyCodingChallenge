package com.sai.javafx.fxplorer.widgets;

import java.io.File;
import java.io.IOException;
import java.net.URI;

import javax.imageio.ImageIO;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ScreenshotStage extends Stage {

	private final Screen screen;
	private final Canvas mainCanvas = new Canvas();
	private double clickX, clickY, dragX, dragY;

	private enum Status {
		waitForSelection, selectArea
	};

	private Status status = Status.waitForSelection;
	private File snapshotFile;

	private final URI storeURI;

	public ScreenshotStage(Screen screen, URI storeURI) {
		this.screen = screen;
		this.storeURI = storeURI;
		this.initStyle(StageStyle.TRANSPARENT);
		setAlwaysOnTop(true);

		final StackPane stackPane = new StackPane();
		stackPane.setStyle("-fx-background-color:transparent;");
		stackPane.getChildren().add(mainCanvas);

		Rectangle2D screenBounds = screen.getVisualBounds();
		final Scene scene = new Scene(stackPane, screenBounds.getWidth(), screenBounds.getHeight(), Color.TRANSPARENT);
		scene.setFill(Color.TRANSPARENT);
		setScene(scene);
		setX(screenBounds.getMinX());
		setY(screenBounds.getMinY());

		scene.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
			if (e.getCode() == KeyCode.ESCAPE) {
				ScreenshotStage.this.close();
			}
		});
		mainCanvas.setWidth(screenBounds.getWidth());
		mainCanvas.setHeight(screenBounds.getHeight());
		mainCanvas.setOnMouseMoved(e -> {
			clickX = e.getX();
			clickY = e.getY();
			repaintCanvas();
		});
		mainCanvas.setOnMousePressed(e -> {
			if (e.getButton() == MouseButton.PRIMARY) {
				clickX = e.getX();
				clickY = e.getY();
			}
		});
		mainCanvas.setOnMouseDragged(m -> {
			if (m.getButton() == MouseButton.PRIMARY) {
				status = Status.selectArea;
				dragX = m.getX();
				dragY = m.getY();
				repaintCanvas();
			}
		});
		mainCanvas.setOnMouseReleased(m -> {
			if (status == Status.selectArea) {
				takeSnapshot();
				ScreenshotStage.this.close();
			}
		});
		Platform.runLater(this::repaintCanvas);
	}

	private boolean takeSnapshot() {
		double x = Math.min(clickX, dragX);
		double y = Math.min(clickY, dragY);
		double width = Math.abs(dragX - clickX - 1);
		double height = Math.abs(dragY - clickY - 1);
		if (width > 0 && height > 0) {
			final Bounds bounds = mainCanvas.localToScreen(new BoundingBox(x, y, width, height));
			final WritableImage image = new javafx.scene.robot.Robot().getScreenCapture(null, bounds.getMinX(),
					bounds.getMinY(), bounds.getWidth(), bounds.getHeight(), false);
			File file;
			int i = 0;
			while ((file = new File(storeURI.resolve("snapshot_" + i + ".png"))).exists()) {
				i++;
			}
			try {
				ImageIO.setUseCache(false);
				ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
				snapshotFile = file;
			} catch (IOException ex) {
				System.out.println(ex);
				// Log.error(ex);
//                new Alert(Alert.AlertType.ERROR).
//                        withOwner(getScene()).
//                        withTitle("Error").
//                        withContextText(ex.toString()).
//                        withException(ex).
//                        show();
			}
			return true;
		}
		return false;
	}

	private void repaintCanvas() {
		if (mainCanvas.isVisible() && mainCanvas.getScene() != null) {
			GraphicsContext gc = mainCanvas.getGraphicsContext2D();
			// gc.setFont(Font.font("null", FontWeight.BOLD, 14));

			gc.clearRect(0, 0, mainCanvas.getWidth(), mainCanvas.getHeight());
			gc.setFill(Color.rgb(0, 0, 0, 0.2));
			gc.fillRect(0, 0, mainCanvas.getWidth(), mainCanvas.getHeight());

			if (status == Status.waitForSelection) {
				gc.setStroke(Color.web("#672824"));
				gc.setFill(Color.web("#672824"));
				gc.setLineWidth(1d);
				gc.strokeLine(clickX, 0, clickX, mainCanvas.getHeight());
				gc.strokeLine(0, clickY, mainCanvas.getWidth(), clickY);
				// gc.setStroke( Color.WHITE);
				gc.fillText("Drag to Select Screen Area", clickX + 10, clickY - 15);
			} else {
				gc.clearRect(clickX, clickY, Math.abs(dragX - clickX), Math.abs(dragY - clickY));
				gc.setStroke(Color.RED);
				gc.setLineWidth(1d);
				gc.strokeRect(clickX - 1, clickY - 1, Math.abs(dragX - clickX) + 2, Math.abs(dragY - clickY) + 2);
			}
		}
	}

	File getSnapshotFile() {
		return snapshotFile;
	}

}