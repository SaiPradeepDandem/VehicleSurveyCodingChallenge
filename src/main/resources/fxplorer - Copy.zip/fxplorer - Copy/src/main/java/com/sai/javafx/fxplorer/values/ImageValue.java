package com.sai.javafx.fxplorer.values;

import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;

import com.sai.javafx.fxplorer.utils.ImageUtils;

import javafx.scene.image.Image;

public class ImageValue implements Value, Serializable {

    private byte[] image;

    private ImageValue() {
        /* private for snapshot */
    }

    public ImageValue(final Image img) {
        try {
            image = ImageUtils.toByteArray(img, "png");
        } catch (final IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final ImageValue that)) {
            return false;
        }
        return Arrays.equals(image, that.image);
    }

    @Override
    public Image getValue() {
        try {
            return ImageUtils.fromByteArray(image, "png");
        } catch (final IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(image);
    }

    @Override
    public ImageValue snapshot() {
        final ImageValue snapshot = new ImageValue();
        snapshot.image = image;
        return snapshot;
    }

    @Override
    public String toString() {
        return "ImageValue{"
            +
            "image="
            + Arrays.toString(image)
            +
            '}';
    }
}
