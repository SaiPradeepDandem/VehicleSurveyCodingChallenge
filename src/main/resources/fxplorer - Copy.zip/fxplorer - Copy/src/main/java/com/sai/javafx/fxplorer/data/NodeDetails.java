package com.sai.javafx.fxplorer.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.sai.javafx.fxplorer.utils.ImageUtils;
import com.sai.javafx.fxplorer.utils.Utils;
import com.sai.javafx.fxplorer.values.ImageValue;
import com.sai.javafx.fxplorer.values.NullValue;

import javafx.collections.ListChangeListener;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.Region;

/**
 * Class for providing the node details.
 */
public class NodeDetails extends Details implements Serializable {

    /** Snapshot image of the node. */
    private ImageValue preview;

    /** Child node details of the current node. */
    private List<NodeDetails> children = new ArrayList<>();

    /** Actual reference to the node object. */
    private transient final Node node;

    /** Listeners added to the node. */
    private transient ListChangeListener<? super Node> childrenListener;

    /**
     * Constructor.
     *
     * @param n node
     */
    public NodeDetails(final Node n) {
        node = n;
        setClassName(Utils.nodeClass(n));
        setUId(n.hashCode());
        setFxId(n.getId());
        if (n instanceof final Region region) {
            getStyleSheets().addAll(region.getStylesheets());
        }
    }

    /**
     * Constructor.
     */
    private NodeDetails() {
        /* private for snapshot */
        node = null;
    }

    /**
     * Provides the child node details matching to the provided id.
     *
     * @param childId child node id
     * @return node details
     */
    public final NodeDetails getChildDetails(final int childId) {
        for (final NodeDetails child : getChildren()) {
            if (child.getUId() == childId) {
                return child;
            }
        }
        return null;
    }

    /**
     * Returns the list of child node details.
     *
     * @return list of child node details
     */
    public final List<NodeDetails> getChildren() {
        return children;
    }

    @Override
    public final String getDisplayName() {
        return Utils.nodeDisplay(this, true);
    }

    /**
     * Returns the snapshot image of the node.
     *
     * @return snapshot image of the node
     */
    public final ImageValue getPreview() {
        return preview;
    }

    /**
     * Specifies if the node has any children or not.
     *
     * @return {@code true} if the node has any children
     */
    public final boolean hasChildren() {
        return !children.isEmpty();
    }

    @Override
    public final boolean isMatched(final String key, final String searchText) {
        final PropertyDetails details = getFullProperties().get(key);
        return details != null
            &&
            !(details.getValue() instanceof NullValue)
            &&
            details.getValue().toString().toLowerCase().contains(searchText.toLowerCase());
    }

    @Override
    public final void reset() {
        super.reset();
        if (node instanceof final Parent parent) {
            parent.getChildrenUnmodifiable().removeListener(childrenListener);
        }
        children.forEach(NodeDetails::reset);
    }

    /**
     * Sets the child nodes list.
     *
     * @param children child nodes list
     */
    public final void setChildren(final List<NodeDetails> children) {
        this.children = children;
    }

    /**
     * Sets the listener to the children if the current node is an instance of Parent.
     *
     * @param childrenListener listener to set
     */
    public final void setChildrenListener(final ListChangeListener<? super Node> childrenListener) {
        this.childrenListener = childrenListener;
        if (node instanceof final Parent parent) {
            parent.getChildrenUnmodifiable().addListener(this.childrenListener);
        }
    }

    @Override
    public final void setPopup(final boolean popup) {
        super.setPopup(popup);
        if (popup) {
            /*
             * We need to take preview of nodes instantly in popup, as they will not be available at the time of
             * inspection.
             */
            setPreview(new ImageValue(node.snapshot(ImageUtils.getSnapshotParameters(), null)));
        }
    }

    /**
     * Sets the snapshot image of the node.
     *
     * @param preview snapshot image value
     */
    public final void setPreview(final ImageValue preview) {
        this.preview = preview;
    }

    @Override
    public final NodeDetails snapshot() {
        final NodeDetails snapshot = new NodeDetails();
        super.snapshot(snapshot);
        if (preview != null) {
            snapshot.preview = preview.snapshot();
        }
        return snapshot;
    }
}
