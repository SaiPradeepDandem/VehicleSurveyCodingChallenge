package com.sai.javafx.fxplorer.widgets;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.util.Duration;

/**
 * Custom split menu widget for taking the snapshots.
 */
public final class SnapshotButton extends SplitMenuButton {

    /** Duration of 5 seconds. */
    private final Duration FIVE_SECONDS = Duration.seconds(5);

    /** Duration of 10 seconds. */
    private final Duration TEN_SECONDS = Duration.seconds(10);

    /** Specifies the progress of timer for the snapshot. */
    private final IntegerProperty progress = new SimpleIntegerProperty();

    /** Pseudo class for indicating the progress. */
    private final PseudoClass PROGRESS_PSEUDOCLASS = PseudoClass.getPseudoClass("progress");

    /** Current duration of timer in the progress. */
    private final ObjectProperty<Duration> currentDuration = new SimpleObjectProperty<>(Duration.ZERO);

    /** Action to be performed when the timer is finished. */
    private Runnable actionHandler;

    /** Timeline for executing the action. */
    private Timeline timeline;

    /**
     * Constructor.
     */
    public SnapshotButton() {
        setText("Take Snapshot");
        getStyleClass().add("snapshot");

        final MenuItem defaultItem = new MenuItem("Instant");
        final MenuItem fiveSecItem = new MenuItem("5 seconds");
        final MenuItem tenSecItem = new MenuItem("10 seconds");
        defaultItem.setOnAction(e -> currentDuration.set(Duration.ZERO));
        fiveSecItem.setOnAction(e -> currentDuration.set(FIVE_SECONDS));
        tenSecItem.setOnAction(e -> currentDuration.set(TEN_SECONDS));
        getItems().addAll(defaultItem, fiveSecItem, tenSecItem);

        currentDuration.addListener((obs, old, val) -> {
            getStyleClass().removeAll("s0", "s5", "s10");
            getStyleClass().add(val == FIVE_SECONDS ? "s5" : val == TEN_SECONDS ? "s10" : "s0");
        });

        progress.addListener((obs, old, val) -> {
            setStyle("-fx-progress-color: linear-gradient(to right, -fx-progress-base-color "
                + val
                + "% , button_background_color 1% );");
        });

        final EventHandler<ActionEvent> onFinished = t -> {
            reset();
            setDisable(false);
            actionHandler.run();
        };

        setOnAction(e -> {
            if (actionHandler == null || timeline != null && timeline.getStatus() == Animation.Status.RUNNING) {
                return;
            }
            if (currentDuration.get() == Duration.ZERO) {
                onFinished.handle(null);
            } else {
                setDisable(true);
                progress.set(0);
                pseudoClassStateChanged(PROGRESS_PSEUDOCLASS, true);
                timeline =
                        new Timeline(new KeyFrame(currentDuration.get(), onFinished, new KeyValue(progress, 100)));
                timeline.playFromStart();
            }
        });
    }

    /**
     * Sets the handler to execute when the timer is finished.
     *
     * @param actionHandler runnable to execute
     */
    public final void setActionHandler(final Runnable actionHandler) {
        this.actionHandler = actionHandler;
    }

    /**
     * Updates the status of the widget.
     *
     * @param disable {@code true} to disable
     */
    public final void update(final boolean disable) {
        if (timeline != null && timeline.getStatus() == Animation.Status.RUNNING) {
            timeline.stop();
            reset();
        }
        setDisable(disable);
    }

    /**
     * Resets the widget state.
     */
    private void reset() {
        pseudoClassStateChanged(PROGRESS_PSEUDOCLASS, false);
        progress.set(0);
        setStyle("-fx-progress-color: button_background_color;");
    }
}
