package com.sai.javafx.fxplorer.ui;

import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.TreeData;

import javafx.scene.control.TreeItem;

/**
 * Tree item of the fxplorer tree view.
 */
public final class FxplorerTreeItem extends TreeItem<TreeData> {

    /** Snapshots of the tree item. */
    private final Map<String, Details> snapshots = new HashMap<>();

    /** List of snapshot keys. */
    private final List<String> keys = new ArrayList<>();

    /**
     * Constructor.
     *
     * @param data tree item data type
     */
    public FxplorerTreeItem(final TreeData data) {
        super(data);
    }

    /**
     * Creates the snapshot of the tree item data.
     */
    public final void createSnapshot() {
        final Instant instant = Instant.ofEpochMilli(System.currentTimeMillis());
        final LocalTime time = instant.atZone(ZoneId.systemDefault()).toLocalTime();
        final String key = time.format(DateTimeFormatter.ISO_LOCAL_TIME);

        snapshots.put(key, ((Details) getValue()).snapshot());
        keys.add(key);
    }

    /**
     * Returns the snapshot for the provided snapshot key.
     *
     * @param key snapshot time
     * @return snapshot details
     */
    public final Details getSnapshot(final String key) {
        return snapshots.get(key);
    }

    /**
     * Returns the count of the snapshots of the tree item.
     *
     * @return count of snapshots
     */
    public final int getSnapshotCount() {
        return snapshots.size();
    }

    /**
     * Returns the index of the snapshot in the list.
     *
     * @param key snapshot time
     * @return index
     */
    public final int getSnapshotIndex(final String key) {
        return keys.indexOf(key);
    }

    public final Map<String, Details> getSnapshots() {
        return snapshots;
    }
}
