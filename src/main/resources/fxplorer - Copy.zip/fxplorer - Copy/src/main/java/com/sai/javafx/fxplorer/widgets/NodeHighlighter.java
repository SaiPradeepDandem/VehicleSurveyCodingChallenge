package com.sai.javafx.fxplorer.widgets;

import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;

/**
 * Highlights the node in the remote application.
 */
public final class NodeHighlighter extends Group {

    /** Overlay on the highlighter. */
    private final StackPane fill;

    /**
     * Constructor.
     */
    public NodeHighlighter() {
        setMouseTransparent(true);
        setManaged(false);
        /*
         * Style set through inline rather than css file. This is because the highlighter is applied on the remote
         * application.
         */
        final String style =
                "-fx-background-color:#FF6EC766;"
                    + "-fx-border-color:green;"
                    + "-fx-border-width:1px;"
                    + "-fx-border-style: segments(5, 5, 5, 5)  line-cap round ;";
        fill = new StackPane();
        fill.setMouseTransparent(true);
        fill.setStyle(style);
        fill.minWidthProperty().bind(fill.prefWidthProperty());
        fill.minHeightProperty().bind(fill.prefHeightProperty());
        getChildren().add(fill);
    }

    /**
     * Applies the highlighter over the provided node.
     *
     * @param node node to be highlighted
     */
    public final void applyOn(final Node node) {
        final Scene scene = node.getScene();
        final Pane root = (Pane) scene.getRoot();
        final Bounds bounds =
                root.sceneToLocal(node.localToScene(node.getBoundsInLocal()));
        if (!scene.getRoot().getChildrenUnmodifiable().contains(this)) {
            ((Pane) scene.getRoot()).getChildren().add(this);
        }
        fill.setPrefWidth(bounds.getWidth());
        fill.setPrefHeight(bounds.getHeight());
        setLayoutX(bounds.getMinX());
        setLayoutY(bounds.getMinY());
    }

    /**
     * Clears the highlighter from the scene.
     *
     * @param scene scene
     */
    public final void clear(final Scene scene) {
        ((Pane) scene.getRoot()).getChildren().remove(this);
    }
}
