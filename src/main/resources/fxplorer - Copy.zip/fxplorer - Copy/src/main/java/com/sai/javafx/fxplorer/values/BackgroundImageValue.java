package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundRepeat;

public class BackgroundImageValue implements Value, Serializable {

    private ImageValue image;

    private BackgroundRepeat repeatX;

    private BackgroundRepeat repeatY;

    private BackgroundPositionValue position;

    private BackgroundSizeValue size;

    private BackgroundImageValue() {
        /* private for snapshot */
    }

    public BackgroundImageValue(final BackgroundImage bi) {
        image = new ImageValue(bi.getImage());
        repeatX = bi.getRepeatX();
        repeatY = bi.getRepeatY();
        position = new BackgroundPositionValue(bi.getPosition());
        size = new BackgroundSizeValue(bi.getSize());
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BackgroundImageValue that)) {
            return false;
        }
        return Objects.equals(image, that.image)
            && repeatX == that.repeatX
            && repeatY == that.repeatY
            && Objects.equals(position, that.position)
            && Objects.equals(size, that.size);
    }

    @Override
    public BackgroundImage getValue() {
        return new BackgroundImage(image.getValue(), repeatX, repeatY, position.getValue(), size.getValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(image, repeatX, repeatY, position, size);
    }

    @Override
    public BackgroundImageValue snapshot() {
        final BackgroundImageValue snapshot = new BackgroundImageValue();
        snapshot.image = image == null ? null : image.snapshot();
        snapshot.repeatX = repeatX;
        snapshot.repeatY = repeatY;
        snapshot.position = position == null ? null : position.snapshot();
        snapshot.size = size == null ? null : size.snapshot();
        return snapshot;
    }

    @Override
    public String toString() {
        return "BackgroundImageValue{"
            +
            "image="
            + image
            +
            ", repeatX="
            + repeatX
            +
            ", repeatY="
            + repeatY
            +
            ", position="
            + position
            +
            ", size="
            + size
            +
            '}';
    }
}
