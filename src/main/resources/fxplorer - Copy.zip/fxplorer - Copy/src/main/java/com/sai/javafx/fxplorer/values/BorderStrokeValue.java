package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.BorderStroke;

public class BorderStrokeValue implements Value, Serializable {

    private PaintValue topStroke;

    private PaintValue rightStroke;

    private PaintValue bottomStroke;

    private PaintValue leftStroke;

    private BorderStrokeStyleValue topStyle;

    private BorderStrokeStyleValue rightStyle;

    private BorderStrokeStyleValue bottomStyle;

    private BorderStrokeStyleValue leftStyle;

    private CornerRadiiValue radii;

    private BorderWidthsValue widths;

    private InsetsValue insets;

    private BorderStrokeValue() {
        /* private for snapshot */
    }

    public BorderStrokeValue(final BorderStroke bs) {
        topStroke = new PaintValue(bs.getTopStroke());
        rightStroke = new PaintValue(bs.getRightStroke());
        bottomStroke = new PaintValue(bs.getBottomStroke());
        leftStroke = new PaintValue(bs.getLeftStroke());
        topStyle = new BorderStrokeStyleValue(bs.getTopStyle());
        rightStyle = new BorderStrokeStyleValue(bs.getRightStyle());
        bottomStyle = new BorderStrokeStyleValue(bs.getBottomStyle());
        leftStyle = new BorderStrokeStyleValue(bs.getLeftStyle());
        radii = new CornerRadiiValue(bs.getRadii());
        widths = new BorderWidthsValue(bs.getWidths());
        insets = new InsetsValue(bs.getInsets());

    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BorderStrokeValue that)) {
            return false;
        }
        return Objects.equals(topStroke, that.topStroke)
            && Objects.equals(rightStroke, that.rightStroke)
            && Objects.equals(bottomStroke, that.bottomStroke)
            && Objects.equals(leftStroke, that.leftStroke)
            && Objects.equals(topStyle, that.topStyle)
            && Objects.equals(rightStyle, that.rightStyle)
            && Objects.equals(bottomStyle, that.bottomStyle)
            && Objects.equals(leftStyle, that.leftStyle)
            && Objects.equals(radii, that.radii)
            && Objects.equals(widths, that.widths)
            && Objects.equals(insets, that.insets);
    }

    @Override
    public BorderStroke getValue() {
        return new BorderStroke(topStroke.getValue(), rightStroke.getValue(), bottomStroke.getValue(),
                                leftStroke.getValue(),
                                topStyle.getValue(), rightStyle.getValue(), bottomStyle.getValue(),
                                leftStyle.getValue(),
                                radii.getValue(), widths.getValue(), insets.getValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(topStroke, rightStroke, bottomStroke, leftStroke, topStyle, rightStyle, bottomStyle,
                leftStyle, radii, widths, insets);
    }

    @Override
    public BorderStrokeValue snapshot() {
        final BorderStrokeValue snapshot = new BorderStrokeValue();
        snapshot.topStroke = topStroke == null ? null : topStroke.snapshot();
        snapshot.rightStroke = rightStroke == null ? null : rightStroke.snapshot();
        snapshot.bottomStroke = bottomStroke == null ? null : bottomStroke.snapshot();
        snapshot.leftStroke = leftStroke == null ? null : leftStroke.snapshot();
        snapshot.topStyle = topStyle == null ? null : topStyle.snapshot();
        snapshot.rightStyle = rightStyle == null ? null : rightStyle.snapshot();
        snapshot.bottomStyle = bottomStyle == null ? null : bottomStyle.snapshot();
        snapshot.leftStyle = leftStyle == null ? null : leftStyle.snapshot();
        snapshot.radii = radii == null ? null : radii.snapshot();
        snapshot.widths = widths == null ? null : widths.snapshot();
        snapshot.insets = insets == null ? null : insets.snapshot();
        return snapshot;
    }

    @Override
    public String toString() {
        return "BorderStrokeValue{"
            +
            "topStroke="
            + topStroke
            +
            ", rightStroke="
            + rightStroke
            +
            ", bottomStroke="
            + bottomStroke
            +
            ", leftStroke="
            + leftStroke
            +
            ", topStyle="
            + topStyle
            +
            ", rightStyle="
            + rightStyle
            +
            ", bottomStyle="
            + bottomStyle
            +
            ", leftStyle="
            + leftStyle
            +
            ", radii="
            + radii
            +
            ", widths="
            + widths
            +
            ", insets="
            + insets
            +
            '}';
    }
}
