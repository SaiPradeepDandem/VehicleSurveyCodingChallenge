package com.sai.javafx.fxplorer.ui.valuenode;

import com.sai.javafx.fxplorer.data.PropertyDetails;

import javafx.scene.Node;
import javafx.scene.layout.GridPane;

/**
 * Specifies the image value.
 */
public final class ImageValueNode implements ValueNode {

    /** Layout to which the image is rendered. */
    private final GridPane layout = new GridPane();

    /**
     * Constructor.
     */
    public ImageValueNode() {
        /* Empty */
    }

    @Override
    public final Node getNode() {
        return layout;
    }

    @Override
    public final void highlight() {
        /* Empty */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        /* Empty */
    }
}
