package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.layout.CornerRadii;

public class CornerRadiiValue implements Value, Serializable {

    private double topLeftHorizontalRadius;

    private double topLeftVerticalRadius;

    private double topRightVerticalRadius;

    private double topRightHorizontalRadius;

    private double bottomRightHorizontalRadius;

    private double bottomRightVerticalRadius;

    private double bottomLeftVerticalRadius;

    private double bottomLeftHorizontalRadius;

    private boolean topLeftHorizontalRadiusAsPercentage;

    private boolean topLeftVerticalRadiusAsPercentage;

    private boolean topRightVerticalRadiusAsPercentage;

    private boolean topRightHorizontalRadiusAsPercentage;

    private boolean bottomRightHorizontalRadiusAsPercentage;

    private boolean bottomRightVerticalRadiusAsPercentage;

    private boolean bottomLeftVerticalRadiusAsPercentage;

    private boolean bottomLeftHorizontalRadiusAsPercentage;

    private CornerRadiiValue() {
        /* private for snapshot */
    }

    public CornerRadiiValue(final CornerRadii cr) {
        topLeftHorizontalRadius = cr.getTopLeftHorizontalRadius();
        topLeftVerticalRadius = cr.getTopLeftVerticalRadius();
        topRightVerticalRadius = cr.getTopRightVerticalRadius();
        topRightHorizontalRadius = cr.getTopRightHorizontalRadius();
        bottomRightHorizontalRadius = cr.getBottomRightHorizontalRadius();
        bottomRightVerticalRadius = cr.getBottomRightVerticalRadius();
        bottomLeftVerticalRadius = cr.getBottomLeftVerticalRadius();
        bottomLeftHorizontalRadius = cr.getBottomLeftHorizontalRadius();

        topLeftHorizontalRadiusAsPercentage = cr.isTopLeftHorizontalRadiusAsPercentage();
        topLeftVerticalRadiusAsPercentage = cr.isTopLeftVerticalRadiusAsPercentage();
        topRightVerticalRadiusAsPercentage = cr.isTopRightVerticalRadiusAsPercentage();
        topRightHorizontalRadiusAsPercentage = cr.isTopRightHorizontalRadiusAsPercentage();
        bottomRightHorizontalRadiusAsPercentage = cr.isBottomRightHorizontalRadiusAsPercentage();
        bottomRightVerticalRadiusAsPercentage = cr.isBottomRightVerticalRadiusAsPercentage();
        bottomLeftVerticalRadiusAsPercentage = cr.isBottomLeftVerticalRadiusAsPercentage();
        bottomLeftHorizontalRadiusAsPercentage = cr.isBottomLeftHorizontalRadiusAsPercentage();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final CornerRadiiValue that)) {
            return false;
        }
        return Double.compare(that.topLeftHorizontalRadius, topLeftHorizontalRadius) == 0
            && Double.compare(that.topLeftVerticalRadius, topLeftVerticalRadius) == 0
            && Double.compare(that.topRightVerticalRadius, topRightVerticalRadius) == 0
            && Double.compare(that.topRightHorizontalRadius, topRightHorizontalRadius) == 0
            && Double.compare(that.bottomRightHorizontalRadius, bottomRightHorizontalRadius) == 0
            && Double.compare(that.bottomRightVerticalRadius, bottomRightVerticalRadius) == 0
            && Double.compare(that.bottomLeftVerticalRadius, bottomLeftVerticalRadius) == 0
            && Double.compare(that.bottomLeftHorizontalRadius, bottomLeftHorizontalRadius) == 0
            && topLeftHorizontalRadiusAsPercentage == that.topLeftHorizontalRadiusAsPercentage
            && topLeftVerticalRadiusAsPercentage == that.topLeftVerticalRadiusAsPercentage
            && topRightVerticalRadiusAsPercentage == that.topRightVerticalRadiusAsPercentage
            && topRightHorizontalRadiusAsPercentage == that.topRightHorizontalRadiusAsPercentage
            && bottomRightHorizontalRadiusAsPercentage == that.bottomRightHorizontalRadiusAsPercentage
            && bottomRightVerticalRadiusAsPercentage == that.bottomRightVerticalRadiusAsPercentage
            && bottomLeftVerticalRadiusAsPercentage == that.bottomLeftVerticalRadiusAsPercentage
            && bottomLeftHorizontalRadiusAsPercentage == that.bottomLeftHorizontalRadiusAsPercentage;
    }

    @Override
    public CornerRadii getValue() {
        return new CornerRadii(topLeftHorizontalRadius, topLeftVerticalRadius, topRightVerticalRadius,
                               topRightHorizontalRadius,
                               bottomRightHorizontalRadius, bottomRightVerticalRadius, bottomLeftVerticalRadius,
                               bottomLeftHorizontalRadius,
                               topLeftHorizontalRadiusAsPercentage, topLeftVerticalRadiusAsPercentage,
                               topRightVerticalRadiusAsPercentage, topRightHorizontalRadiusAsPercentage,
                               bottomRightHorizontalRadiusAsPercentage, bottomRightVerticalRadiusAsPercentage,
                               bottomLeftVerticalRadiusAsPercentage, bottomLeftHorizontalRadiusAsPercentage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topLeftHorizontalRadius, topLeftVerticalRadius, topRightVerticalRadius,
                topRightHorizontalRadius, bottomRightHorizontalRadius, bottomRightVerticalRadius,
                bottomLeftVerticalRadius, bottomLeftHorizontalRadius, topLeftHorizontalRadiusAsPercentage,
                topLeftVerticalRadiusAsPercentage, topRightVerticalRadiusAsPercentage,
                topRightHorizontalRadiusAsPercentage, bottomRightHorizontalRadiusAsPercentage,
                bottomRightVerticalRadiusAsPercentage, bottomLeftVerticalRadiusAsPercentage,
                bottomLeftHorizontalRadiusAsPercentage);
    }

    @Override
    public CornerRadiiValue snapshot() {
        final CornerRadiiValue snapshot = new CornerRadiiValue();
        snapshot.topLeftHorizontalRadius = topLeftHorizontalRadius;
        snapshot.topLeftVerticalRadius = topLeftVerticalRadius;
        snapshot.topRightVerticalRadius = topRightVerticalRadius;
        snapshot.topRightHorizontalRadius = topRightHorizontalRadius;
        snapshot.bottomRightHorizontalRadius = bottomRightHorizontalRadius;
        snapshot.bottomRightVerticalRadius = bottomRightVerticalRadius;
        snapshot.bottomLeftVerticalRadius = bottomLeftVerticalRadius;
        snapshot.bottomLeftHorizontalRadius = bottomLeftHorizontalRadius;

        snapshot.topLeftHorizontalRadiusAsPercentage = topLeftHorizontalRadiusAsPercentage;
        snapshot.topLeftVerticalRadiusAsPercentage = topLeftVerticalRadiusAsPercentage;
        snapshot.topRightVerticalRadiusAsPercentage = topRightVerticalRadiusAsPercentage;
        snapshot.topRightHorizontalRadiusAsPercentage = topRightHorizontalRadiusAsPercentage;
        snapshot.bottomRightHorizontalRadiusAsPercentage = bottomRightHorizontalRadiusAsPercentage;
        snapshot.bottomRightVerticalRadiusAsPercentage = bottomRightVerticalRadiusAsPercentage;
        snapshot.bottomLeftVerticalRadiusAsPercentage = bottomLeftVerticalRadiusAsPercentage;
        snapshot.bottomLeftHorizontalRadiusAsPercentage = bottomLeftHorizontalRadiusAsPercentage;
        return snapshot;
    }

    @Override
    public String toString() {
        return "CornerRadiiValue{"
            +
            "topLeftHorizontalRadius="
            + topLeftHorizontalRadius
            +
            ", topLeftVerticalRadius="
            + topLeftVerticalRadius
            +
            ", topRightVerticalRadius="
            + topRightVerticalRadius
            +
            ", topRightHorizontalRadius="
            + topRightHorizontalRadius
            +
            ", bottomRightHorizontalRadius="
            + bottomRightHorizontalRadius
            +
            ", bottomRightVerticalRadius="
            + bottomRightVerticalRadius
            +
            ", bottomLeftVerticalRadius="
            + bottomLeftVerticalRadius
            +
            ", bottomLeftHorizontalRadius="
            + bottomLeftHorizontalRadius
            +
            ", topLeftHorizontalRadiusAsPercentage="
            + topLeftHorizontalRadiusAsPercentage
            +
            ", topLeftVerticalRadiusAsPercentage="
            + topLeftVerticalRadiusAsPercentage
            +
            ", topRightVerticalRadiusAsPercentage="
            + topRightVerticalRadiusAsPercentage
            +
            ", topRightHorizontalRadiusAsPercentage="
            + topRightHorizontalRadiusAsPercentage
            +
            ", bottomRightHorizontalRadiusAsPercentage="
            + bottomRightHorizontalRadiusAsPercentage
            +
            ", bottomRightVerticalRadiusAsPercentage="
            + bottomRightVerticalRadiusAsPercentage
            +
            ", bottomLeftVerticalRadiusAsPercentage="
            + bottomLeftVerticalRadiusAsPercentage
            +
            ", bottomLeftHorizontalRadiusAsPercentage="
            + bottomLeftHorizontalRadiusAsPercentage
            +
            '}';
    }
}
