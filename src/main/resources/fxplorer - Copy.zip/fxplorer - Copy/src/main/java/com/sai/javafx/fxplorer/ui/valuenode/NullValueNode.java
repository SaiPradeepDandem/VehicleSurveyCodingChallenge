package com.sai.javafx.fxplorer.ui.valuenode;

import com.sai.javafx.fxplorer.data.PropertyDetails;

/**
 * Specifies the null value.
 */
public final class NullValueNode extends StringValueNode {

    /**
     * Constructor.
     */
    public NullValueNode() {
        /* Empty */
    }

    @Override
    public final void setValue(final PropertyDetails propertyDetails) {
        label.setText("-");
    }
}
