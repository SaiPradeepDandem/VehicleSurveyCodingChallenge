package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;

public class BoundsValue implements Value, Serializable {

    private double minX;

    private double minY;

    private double minZ;

    private double width;

    private double height;

    private double depth;

    private String display;

    private BoundsValue() {
        /* private for snapshot */
    }

    public BoundsValue(final Bounds bounds) {
        minX = bounds.getMinX();
        minY = bounds.getMinY();
        minZ = bounds.getMinZ();
        width = bounds.getWidth();
        height = bounds.getHeight();
        depth = bounds.getDepth();
        display = bounds.toString();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final BoundsValue that)) {
            return false;
        }
        return Double.compare(that.minX, minX) == 0
            && Double.compare(that.minY, minY) == 0
            && Double.compare(that.minZ, minZ) == 0
            && Double.compare(that.width, width) == 0
            && Double.compare(that.height, height) == 0
            && Double.compare(that.depth, depth) == 0
            && Objects.equals(display, that.display);
    }

    @Override
    public Bounds getValue() {
        return new BoundingBox(minX, minY, minZ, width, height, depth);
    }

    @Override
    public int hashCode() {
        return Objects.hash(minX, minY, minZ, width, height, depth, display);
    }

    @Override
    public BoundsValue snapshot() {
        final BoundsValue snapshot = new BoundsValue();
        snapshot.minX = minX;
        snapshot.minY = minY;
        snapshot.minZ = minZ;
        snapshot.width = width;
        snapshot.height = height;
        snapshot.depth = depth;
        snapshot.display = display;
        return snapshot;
    }

    @Override
    public String toString() {
        return display;
    }
}
