package com.sai.javafx.fxplorer.data;

import java.io.Serializable;
import java.util.Collection;
import java.util.Objects;
import java.util.function.Consumer;

import com.sai.javafx.fxplorer.values.BackgroundValue;
import com.sai.javafx.fxplorer.values.BorderValue;
import com.sai.javafx.fxplorer.values.BoundsValue;
import com.sai.javafx.fxplorer.values.InsetsValue;
import com.sai.javafx.fxplorer.values.NullValue;
import com.sai.javafx.fxplorer.values.StringValue;
import com.sai.javafx.fxplorer.values.Value;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.collections.SetChangeListener;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;

/**
 * Property details object.
 */
public class PropertyDetails implements Serializable {

    /** UID. */
    private static final long serialVersionUID = -2556951288718105816L;

    /** Name of the property. */
    private String name;

    /** Property value type. */
    private ValueType type;

    /** Value of the property */
    private Value value;

    /** Consumer to accept the property details. */
    private transient Consumer<PropertyDetails> dispatcher;

    /** Observable instance of the property. */
    private transient Observable observable;

    /** Listener for property. */
    private final transient InvalidationListener propListener = v -> updateAndDispatch();

    /** List change listener for property. */
    private final transient ListChangeListener listChangeListener = p -> updateAndDispatch();

    /** Set change listener for property. */
    private final transient SetChangeListener setChangeListener = p -> updateAndDispatch();

    /**
     * Constructor.
     *
     * @param dispatcher consumer to accept the property details
     * @param name name of the property
     * @param obsValue observable value of the property
     */
    public PropertyDetails(final Consumer<PropertyDetails> dispatcher, final String name,
            final Observable obsValue) {
        this.dispatcher = dispatcher;
        this.name = name;
        observable = obsValue;
        observable.addListener(propListener);
        if (observable instanceof final ObservableList<?> list) {
            list.addListener(listChangeListener);
        } else if (observable instanceof final ObservableSet<?> set) {
            set.addListener(setChangeListener);
        }
        updateValue();
    }

    /**
     * Constructor.
     *
     * @param name name of the property
     * @param type type of the property
     * @param value value of the property
     */
    public PropertyDetails(final String name, final ValueType type, final Value value) {
        this.name = name;
        this.type = type;
        this.value = value;
    }

    /**
     * Constructor.
     */
    private PropertyDetails() {
        /* private for snapshot */
    }

    /**
     * Removes all the listeners added to the property.
     */
    public final void clear() {
        removeListener();
        observable = null;
    }

    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final PropertyDetails that)) {
            return false;
        }
        return type == that.type && Objects.equals(value, that.value);
    }

    /**
     * Returns the name of the property.
     *
     * @return name of the property
     */
    public final String getName() {
        return name;
    }

    /**
     * Returns the value type of the property.
     *
     * @return value type of the property
     */
    public final ValueType getType() {
        return type;
    }

    /**
     * Returns the value of the property.
     *
     * @return value of the property
     */
    public final Value getValue() {
        return value;
    }

    @Override
    public final int hashCode() {
        return Objects.hash(type, value);
    }

    /**
     * Removes all the listeners added to the property.
     */
    public final void removeListener() {
        observable.removeListener(propListener);
        if (observable instanceof final ObservableList<?> list) {
            list.removeListener(listChangeListener);
        } else if (observable instanceof final ObservableSet<?> set) {
            set.removeListener(setChangeListener);
        }
    }

    /**
     * Sets the name of the property.
     *
     * @param name name of the property
     */
    public final void setName(final String name) {
        this.name = name;
    }

    /**
     * Sets the type of the property.
     *
     * @param type type of the property
     */
    public final void setType(final ValueType type) {
        this.type = type;
    }

    /**
     * Sets the value of the property.
     *
     * @param value value of the property
     */
    public final void setValue(final Value value) {
        this.value = value;
    }

    /**
     * Returns the copy of the property details.
     *
     * @return copy of the property details
     */
    public final PropertyDetails snapshot() {
        final PropertyDetails snapshot = new PropertyDetails();
        snapshot.name = name;
        snapshot.type = type;
        snapshot.value = value.snapshot();
        return snapshot;
    }

    @Override
    public final String toString() {
        return "PropertyDetails{"
            +
            "name='"
            + name
            + '\''
            +
            ", type="
            + type
            +
            ", value="
            + value
            +
            '}';
    }

    /**
     * Updates the value object from the observable and dispatches the details.
     */
    private void updateAndDispatch() {
        updateValue();
        dispatcher.accept(this);
    }

    /**
     * Updates the value object from the observable.
     */
    private void updateValue() {
        if (observable instanceof ObservableValue<?>) {
            final Object propValue = ((ObservableValue<?>) observable).getValue();
            if (propValue == null) {
                type = ValueType.NULL;
                value = new NullValue();
            } else if (propValue instanceof final Background background) {
                type = ValueType.BACKGROUND;
                value = new BackgroundValue(background);
            } else if (propValue instanceof final Border border) {
                type = ValueType.BORDER;
                value = new BorderValue(border);
            } else if (propValue instanceof final Insets insets) {
                type = ValueType.INSETS;
                value = new InsetsValue(insets);
            } else if (propValue instanceof final Bounds bounds) {
                type = ValueType.BOUNDS;
                value = new BoundsValue(bounds);
            } else {
                type = ValueType.STRING;
                value = new StringValue(propValue.toString());
            }
        } else {
            type = ValueType.STRING;
            String text = observable.toString();
            if (observable instanceof final Collection<?> collection) {
                text = "";
                for (final Object item : collection) {
                    text = text + item + ", ";
                }
                if (!collection.isEmpty()) {
                    text = text.substring(0, text.length() - 2);
                }
            }
            value = new StringValue(text);
        }
    }
}
