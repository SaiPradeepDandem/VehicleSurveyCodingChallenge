package com.sai.javafx.fxplorer.utils;

/**
 * A tri-consumer interface.
 *
 * @param <T> the first input argument
 * @param <U> the second input argument
 * @param <V> the third input argument
 */
@FunctionalInterface
public interface TriConsumer<T, U, V> {

    /**
     * Performs this operation on the given arguments.
     *
     * @param t the first input argument
     * @param u the second input argument
     * @param v the third input argument
     */
    public void accept(T t, U u, V v);
}
