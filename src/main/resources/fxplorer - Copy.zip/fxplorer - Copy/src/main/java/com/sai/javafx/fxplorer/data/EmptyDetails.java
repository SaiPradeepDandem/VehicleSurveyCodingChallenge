package com.sai.javafx.fxplorer.data;

import java.util.Map;

import javafx.util.Pair;

/**
 * An empty details object. Mostly used for the root item of the treeView.
 */
public final class EmptyDetails extends Details {

    /**
     * Constructor.
     */
    public EmptyDetails() {
        /* Empty */
    }

    @Override
    public final void compare(final Details other,
            final Map<String, Pair<PropertyDetails, PropertyDetails>> result) {
        throw new IllegalStateException("Cannot compare empty details");
    }

    @Override
    public final String getDisplayName() {
        return null;
    }

    @Override
    public final void reset() {
        /* Nothing to remove */
    }

    @Override
    public final Details snapshot() {
        throw new IllegalStateException("Cannot take snapshot of empty details");
    }
}
