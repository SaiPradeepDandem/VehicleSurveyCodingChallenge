package com.sai.javafx.fxplorer.ui.valuenode;

import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.ui.LayoutBuilder;
import com.sai.javafx.fxplorer.values.NullValue;
import com.sai.javafx.fxplorer.values.StringValue;
import com.sai.javafx.fxplorer.values.Value;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;

/**
 * Specifies the string value.
 */
public class StringValueNode implements ValueNode {

    /** Label to show the string value. */
    protected Label label = new Label();

    /**
     * Constructor.
     */
    public StringValueNode() {
        label.setMaxWidth(900);
        label.setWrapText(true);
        label.setMinHeight(Region.USE_PREF_SIZE);
    }

    @Override
    public final Node getNode() {
        return label;
    }

    @Override
    public final void highlight() {
        label.getStyleClass().add("highlight");
    }

    @Override
    public void setValue(final PropertyDetails propertyDetails) {
        final Value value = propertyDetails.getValue();
        if (value instanceof NullValue) {
            label.setText("");
        } else {
            String text = ((StringValue) value).getValue();
            if (LayoutBuilder.SIZE_PROPS.contains(propertyDetails.getName())) {
                final double val = Double.parseDouble(text);
                if (val == Region.USE_COMPUTED_SIZE) {
                    text = "USE_COMPUTED_SIZE";
                } else if (val == Region.USE_PREF_SIZE) {
                    text = "USE_PREF_SIZE";
                } else if (val == Double.MAX_VALUE) {
                    text = "Double.MAX_VALUE";
                } else if (val == Double.POSITIVE_INFINITY) {
                    text = "INFINITY";
                } else if (val == Double.NEGATIVE_INFINITY) {
                    text = "-INFINITY";
                }
            }
            label.setText(text);
        }
    }
}
