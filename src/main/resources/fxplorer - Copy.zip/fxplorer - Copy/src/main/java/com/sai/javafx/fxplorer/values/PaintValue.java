package com.sai.javafx.fxplorer.values;

import java.io.Serializable;
import java.util.Objects;

import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.paint.RadialGradient;

public class PaintValue implements Value, Serializable {

    private double red;

    private double green;

    private double blue;

    private double opacity;

    private ImagePatternValue imagePattern;

    private String gradient;

    private PaintValue() {
        /* private for snapshot */
    }

    public PaintValue(final Paint paint) {
        if (paint instanceof final Color c) {
            red = c.getRed();
            green = c.getGreen();
            blue = c.getBlue();
            opacity = c.getOpacity();
        } else if (paint instanceof final ImagePattern ip) {
            imagePattern = new ImagePatternValue(ip);
        } else {
            gradient = paint.toString();
        }
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof final PaintValue that)) {
            return false;
        }
        return Double.compare(that.red, red) == 0
            && Double.compare(that.green, green) == 0
            && Double.compare(that.blue, blue) == 0
            && Double.compare(that.opacity, opacity) == 0
            && Objects.equals(imagePattern, that.imagePattern)
            && Objects.equals(gradient, that.gradient);
    }

    @Override
    public Paint getValue() {
        if (gradient == null && imagePattern == null) {
            return new Color(red, green, blue, opacity);
        } else if (imagePattern != null) {
            return imagePattern.getValue();
        } else if (gradient.contains("linear")) {
            return LinearGradient.valueOf(gradient);
        } else {
            return RadialGradient.valueOf(gradient);
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(red, green, blue, opacity, imagePattern, gradient);
    }

    @Override
    public PaintValue snapshot() {
        final PaintValue snapshot = new PaintValue();
        snapshot.red = red;
        snapshot.green = green;
        snapshot.blue = blue;
        snapshot.opacity = opacity;
        snapshot.gradient = gradient;
        snapshot.imagePattern = imagePattern == null ? null : imagePattern.snapshot();
        return snapshot;
    }

    @Override
    public String toString() {
        return "PaintValue{"
            +
            "red="
            + red
            +
            ", green="
            + green
            +
            ", blue="
            + blue
            +
            ", opacity="
            + opacity
            +
            ", imagePattern="
            + imagePattern
            +
            ", gradient='"
            + gradient
            + '\''
            +
            '}';
    }
}
