package com.sai.javafx.fxplorer.widgets;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;

/**
 * Custom widget for search by text functionality.
 *
 * @param <T>- type of search results
 */
public final class SearchBox<T> extends HBox {

    /**
     * List holding the search results.
     */
    private final List<T> searchResults;

    /**
     * Current index of the search results.
     */
    private final IntegerProperty searchIndex;

    /** Filter for search operation. */
    private Function<String, List<T>> searchFilter;

    /** Current selected item in the results. */
    private Consumer<T> selectItem;

    /** Prompt text in the search field. */
    private final StringProperty promptText;

    /**
     * Constructor.
     */
    public SearchBox() {
        searchIndex = new SimpleIntegerProperty(-1);
        promptText = new SimpleStringProperty();
        searchResults = new ArrayList<>();
        setSpacing(10);
        setPadding(new Insets(0, 10, 2, 2));
        getStyleClass().add("search-box");
        setAlignment(Pos.CENTER);
        /* Disabling the widget unless searchFilter & selectItem are set */
        setDisable(true);
        init();
    }

    /**
     * Gets the prompt text.
     *
     * @return prompt text
     */
    public final String getPromptText() {
        return promptText.get();
    }

    /**
     * Observable property of the prompt text.
     *
     * @return observable property
     */
    public final StringProperty promptTextProperty() {
        return promptText;
    }

    /**
     * Sets the prompt text of the field.
     *
     * @param promptText prompt text
     */
    public final void setPromptText(final String promptText) {
        this.promptText.set(promptText);
    }

    /**
     * Sets the filter function to the widget.
     *
     * @param searchFilter filter function
     */
    public final void setSearchFilter(final Function<String, List<T>> searchFilter) {
        this.searchFilter = searchFilter;
        setDisable(searchFilter == null || selectItem == null);
    }

    /**
     * Sets the selected item in the filtered results.
     *
     * @param selectItem item to select
     */
    public final void setSelectItem(final Consumer<T> selectItem) {
        this.selectItem = selectItem;
        setDisable(searchFilter == null || selectItem == null);
    }

    /**
     * Initializes the setup.
     */
    private void init() {
        final TextField searchField = new TextField();
        searchField.promptTextProperty().bind(promptText);
        searchField.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(searchField, Priority.ALWAYS);
        searchField.focusedProperty()
            .addListener((obs, old, val) -> pseudoClassStateChanged(PseudoClass.getPseudoClass("focused"), val));

        final StackPane searchIcon = new StackPane();
        searchIcon.getStyleClass().setAll("search-magnifying-glass");
        searchField.textProperty().addListener((ov, oldStr, newStr) -> {
            if (newStr.isEmpty()) {
                searchIcon.getStyleClass().setAll("search-magnifying-glass");
            } else {
                searchIcon.getStyleClass().setAll("search-clear");
            }
        });
        HBox.setHgrow(searchIcon, Priority.NEVER);

        final HBox fieldPane = new HBox(searchField, searchIcon);
        fieldPane.setAlignment(Pos.CENTER);
        HBox.setHgrow(fieldPane, Priority.ALWAYS);

        final Label searchResult = new Label("0/0");
        searchResult.setPrefWidth(Region.USE_COMPUTED_SIZE);
        searchResult.setMinWidth(Region.USE_PREF_SIZE);
        HBox.setHgrow(searchResult, Priority.NEVER);
        searchResult.getStyleClass().add("search-result");

        final Button upButton = new Button();
        upButton.getStyleClass().add("up-arrow");
        upButton.setDisable(true);
        upButton.setFocusTraversable(false);
        HBox.setHgrow(upButton, Priority.NEVER);

        final Button downButton = new Button();
        downButton.getStyleClass().add("down-arrow");
        downButton.setDisable(true);
        downButton.setFocusTraversable(false);
        HBox.setHgrow(downButton, Priority.NEVER);

        upButton.setOnAction(e -> searchIndex.set(searchIndex.get() - 1));
        downButton.setOnAction(e -> searchIndex.set(searchIndex.get() + 1));

        getChildren().addAll(fieldPane, searchResult, upButton, downButton);

        searchField.setOnAction(e -> {
            searchResults.clear();
            final String t = searchField.getText();
            if (!t.isEmpty()) {
                searchResults.addAll(searchFilter.apply(t));
            }
            /* Resetting the index to trigger the listener when search is changed */
            searchIndex.set(-1);
            if (!searchResults.isEmpty()) {
                searchIndex.set(0);
            }
        });

        searchField.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                searchField.clear();
            }
        });

        searchIcon.setOnMouseClicked(t -> {
            searchField.clear();
            searchField.getOnAction().handle(null);
        });

        searchIndex.addListener((obs, old, ind) -> {
            final int i = ind.intValue();
            upButton.setDisable(i < 1);
            downButton.setDisable(i < 0 || i > searchResults.size() - 2);
            if (i < -1) {
                searchResult.setText("0/0");
            } else {
                searchResult.setText(i + 1 + "/" + searchResults.size());
            }
            if (i > -1 && i < searchResults.size()) {
                final T item = searchResults.get(i);
                selectItem.accept(item);
            }
        });
    }
}
