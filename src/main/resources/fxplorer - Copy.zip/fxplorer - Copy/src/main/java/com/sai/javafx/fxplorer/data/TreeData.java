package com.sai.javafx.fxplorer.data;

/**
 * Interface that required for providing details in the tree.
 */
public interface TreeData {

    /**
     * Class name of the object.
     *
     * @return class name
     */
    String getClassName();

    /**
     * Display name that needs to be displayed in the tree.
     *
     * @return display name
     */
    String getDisplayName();

    /**
     * Unique identifier of the object.
     *
     * @return
     */
    int getUId();

    /**
     * Specifies if the provided text matches to any of the properties related the provided key.
     *
     * @param key string to match the property
     * @param text string to match the value
     * @return {@code true} if the text matches the value
     */
    boolean isMatched(String key, String text);
}
