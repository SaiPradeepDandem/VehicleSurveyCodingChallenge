package com.sai.javafx.fxplorer.values;

public final class NullValue implements Value {

    /**
     * Constructor.
     */
    public NullValue() {
        /* Empty */
    }

    @Override
    public final boolean equals(final Object obj) {
        return true;
    }

    @Override
    public final String getValue() {
        return null;
    }

    @Override
    public final NullValue snapshot() {
        return new NullValue();
    }

    @Override
    public final String toString() {
        return "NullValue{}";
    }
}
