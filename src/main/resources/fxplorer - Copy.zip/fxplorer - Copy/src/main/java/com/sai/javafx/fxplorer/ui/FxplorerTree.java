package com.sai.javafx.fxplorer.ui;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.sai.javafx.fxplorer.data.AppDetails;
import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.EmptyDetails;
import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.TreeData;
import com.sai.javafx.fxplorer.data.WindowDetails;
import com.sai.javafx.fxplorer.values.ImageValue;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

/**
 * TreeView of the fxplorer.
 */
public class FxplorerTree extends TreeView<TreeData> {

    /** LayoutController of the application. */
    private LayoutController layoutController;

    /**
     * Constructor.
     */
    public FxplorerTree() {
        setCellFactory(param -> new FxplorerTreeCell());
        final FxplorerTreeItem root = new FxplorerTreeItem(new EmptyDetails());
        setRoot(root);
        setShowRoot(false);
        getSelectionModel().selectedItemProperty().addListener((obs, old, val) -> {
            if (val != null && !(val.getValue() instanceof AppDetails)) {
                final Details details = (Details) val.getValue();
                if (!details.isPopup() && details instanceof final NodeDetails node) {
                    node.setPreview(null);
                }
                layoutController.showDetails(details, val);
            } else {
                layoutController.showDetails(null, null);
            }
        });
    }

    /**
     * Gets the map of style sheets set at different levels of node hierarchy.
     *
     * @param item tree item
     * @return map of style sheets to node
     */
    public static LinkedHashMap<String, List<String>> getStyleSheetHierarchy(final TreeItem<TreeData> item) {
        final LinkedHashMap<String, List<String>> styleSheets = new LinkedHashMap<>();
        TreeItem<TreeData> current = item;
        while (!(current.getValue() instanceof WindowDetails)) {
            final Details details = (Details) current.getValue();
            if (!details.getStyleSheets().isEmpty()) {
                final List<String> list = new ArrayList<>();
                list.addAll(details.getStyleSheets());
                styleSheets.put(details.getDisplayName(), list);
            }
            current = current.getParent();
        }
        return styleSheets;
    }

    /**
     * Adds the application tree item.
     *
     * @param appItem tree item
     */
    public final void addAppItem(final FxplorerTreeItem appItem) {
        getRoot().getChildren().add(appItem);
        appItem.setExpanded(true);
    }

    /**
     * Get the tree item associated with the provided application id.
     *
     * @param appId application id
     * @return tree item
     */
    public final FxplorerTreeItem getAppTreeItem(final int appId) {
        for (final TreeItem<TreeData> appItem : getRoot().getChildren()) {
            final AppDetails appDetails = (AppDetails) appItem.getValue();
            if (appDetails.getVmId() == appId) {
                return (FxplorerTreeItem) appItem;
            }
        }
        return null;
    }

    /**
     * Returns the tree item of the provided node details.
     *
     * @param appId application id
     * @param windowId window id
     * @param nodeId node id
     * @return tree item
     */
    public final FxplorerTreeItem getNodeTreeItem(final int appId, final int windowId, final int nodeId) {
        final FxplorerTreeItem windowItem = getWindowTreeItem(appId, windowId);
        /* The window might have been closed and removed */
        if (windowItem != null) {
            final FxplorerTreeItem nodeItem = findItem(windowItem, nodeId);
            return nodeItem;
        }
        return null;
    }

    /**
     * Returns the scene tree item of the provided window details
     *
     * @param appId application id
     * @param windowId window id
     * @return tree item
     */
    public final FxplorerTreeItem getSceneTreeItem(final int appId, final int windowId) {
        final FxplorerTreeItem windowItem = getWindowTreeItem(appId, windowId);
        return (FxplorerTreeItem) windowItem.getChildren().get(0);
    }

    /**
     * Returns the window id of the provided details object.
     *
     * @param current details instance
     * @return window id
     */
    public final int getWindowId(final Details current) {
        final FxplorerTreeItem appItem = getAppTreeItem(current.getVmId());
        for (final TreeItem<TreeData> window : appItem.getChildren()) {
            final boolean hasItem = hasItem((FxplorerTreeItem) window, current.getUId());
            if (hasItem) {
                return window.getValue().getUId();
            }
        }
        return -1;
    }

    /**
     * Returns the tree item of the provided window id.
     *
     * @param appId application id
     * @param windowId window id
     * @return tree item
     */
    public final FxplorerTreeItem getWindowTreeItem(final int appId, final int windowId) {
        final FxplorerTreeItem appItem = getAppTreeItem(appId);
        for (final TreeItem<TreeData> winItem : appItem.getChildren()) {
            final WindowDetails windowDetails = (WindowDetails) winItem.getValue();
            if (windowDetails.getUId() == windowId) {
                return (FxplorerTreeItem) winItem;
            }
        }
        return null;
    }

    /**
     * Selects the tree item matching the providing details
     *
     * @param appId application id
     * @param windowId window id
     * @param nodeId node id
     */
    public final void selectNode(final int appId, final int windowId, final int nodeId) {
        final FxplorerTreeItem nodeItem = getNodeTreeItem(appId, windowId, nodeId);
        getSelectionModel().select(nodeItem);
        scrollTo(getSelectionModel().getSelectedIndex());
        requestFocus();
    }

    /**
     * Sets the layout controller.
     *
     * @param layoutController layout controller instance
     */
    public final void setLayoutController(final LayoutController layoutController) {
        this.layoutController = layoutController;
    }

    /**
     * Updates the property of the provided owner item.
     *
     * @param appId application id
     * @param windowId window id
     * @param ownerId owner
     * @param propDetails property details to update
     */
    public final void updateProperty(final int appId, final int windowId, final int ownerId,
            final PropertyDetails propDetails) {
        final FxplorerTreeItem nodeItem = getNodeTreeItem(appId, windowId, ownerId);
        if (nodeItem != null) {
            final String propName = propDetails.getName();
            if (propName.equals("preview")) {
                final NodeDetails nodeDetails = (NodeDetails) nodeItem.getValue();
                nodeDetails.setPreview((ImageValue) propDetails.getValue());
            } else {
                final Details details = (Details) nodeItem.getValue();
                details.getFullProperties().put(propName, propDetails);
            }
        }
    }

    /**
     * Finds the item matching the unique id in all child hierarchy of the provided tree item.
     *
     * @param item tree item
     * @param uId unique id
     * @return matching tree item
     */
    private FxplorerTreeItem findItem(final FxplorerTreeItem item, final int uId) {
        if (item.getValue().getUId() == uId) {
            return item;
        }
        for (final TreeItem<? extends TreeData> child : item.getChildren()) {
            final FxplorerTreeItem matchItem = findItem((FxplorerTreeItem) child, uId);
            if (matchItem != null) {
                return matchItem;
            }
        }
        return null;
    }

    /**
     * Checks if provided tree item has a matching child item with the provided unique id.
     *
     * @param item tree item
     * @param id unique id
     * @return {@code true} if it has a matching child item
     */
    private boolean hasItem(final FxplorerTreeItem item, final int id) {
        if (item.getValue().getUId() == id) {
            return true;
        }
        for (final TreeItem<TreeData> child : item.getChildren()) {
            final boolean hasNode = hasItem((FxplorerTreeItem) child, id);
            if (hasNode) {
                return true;
            }
        }
        return false;
    }
}
