package com.sai.javafx.fxplorer.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import com.sai.javafx.fxplorer.data.Details;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.ValueType;
import com.sai.javafx.fxplorer.ui.valuenode.BackgroundValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.BorderValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.BoundsValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.ConstraintsValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.FontValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.ImageValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.InsetsValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.NullValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.StringValueNode;
import com.sai.javafx.fxplorer.ui.valuenode.ValueNode;

import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.util.Pair;

/**
 * Delegate for the building the layout.
 */
public final class LayoutBuilder {

    /** Properties that needs to be highlighted. */
    private static List<String> HIGHLIGHT_PROPS = List.of("id", "x", "y", "width", "height", "layoutBounds");

    /** Properties that can be displayed in node details section. */
    private static List<String> NODE_PROPS = List.of("screenBounds", "styleClass", "pseudoClassStates", "style",
            "visible", "managed", "font", "vgap", "hgap", "spacing", "padding", "columnConstraints", "rowConstraints", "styleSheets");

    /** Properties that have size constants. */
    public static List<String> SIZE_PROPS =
            List.of("minWidth", "minHeight", "prefWidth", "prefHeight", "maxWidth", "maxHeight");

    /** Pseudo class for null value. */
    private static final PseudoClass NULL_PSEUDOCLASS = PseudoClass.getPseudoClass("null-value");

    /** Layout for node details titled pane. */
    private GridPane nodeDetailsLayout;

    /** Layout for full properties titled pane. */
    private GridPane fullPropertiesLayout;

    /** Layout for border properties titled pane. */
    private GridPane borderPropertiesLayout;

    /** Layout for background properties titled pane. */
    private GridPane backgroundPropertiesLayout;

    /** Map to hold all the properties labels and the value nodes for reusing. */
    private final Map<String, Pair<Label, ValueNode>> fullProperties = new HashMap<>();

    /** Map to hold the node properties labels and the value nodes for reusing. */
    private final Map<String, Pair<Label, ValueNode>> nodeProperties = new HashMap<>();

    /** Row constraint for each property row. */
    private final RowConstraints propRowConstraint = new RowConstraints();

    /** Details controller instance. */
    private final DetailsController detailsController;

    /**
     * Constructor.
     *
     * @param detailsController details controller
     */
    public LayoutBuilder(final DetailsController detailsController) {
        this.detailsController = detailsController;
        propRowConstraint.setValignment(VPos.TOP);
    }

    /**
     * Builds label for displaying the property.
     *
     * @param name
     * @return
     */
    public static Label buildPropLabel(final String name) {
        final Label propLabel = new Label(name);
        propLabel.getStyleClass().add("prop-label");
        return propLabel;
    }

    /**
     * Builds the value node for the property details.
     *
     * @param propertyDetails property details
     * @return value node
     */
    public static ValueNode buildValueNode(final PropertyDetails propertyDetails) {
        switch (propertyDetails.getType()) {
            case INSETS:
                return new InsetsValueNode();
            case BACKGROUND:
                return new BackgroundValueNode();
            case BORDER:
                return new BorderValueNode();
            case BOUNDS:
                return new BoundsValueNode();
            case IMAGE:
                return new ImageValueNode();
            case STRING:
                final String propName = propertyDetails.getName();
                if (propName.equals("font")) {
                    return new FontValueNode();
                } else if (propName.endsWith("Constraints")) {
                    return new ConstraintsValueNode();
                } else {
                    return new StringValueNode();
                }
            case NULL:
            default:
                return new NullValueNode();
        }
    }

    /**
     * Clears the properties layout.
     */
    public final void clearLayout() {
        getNodeDetailsLayout().getChildren().clear();
        getNodeDetailsLayout().getRowConstraints().clear();
        getBackgroundPropertiesLayout().getChildren().clear();
        getBorderPropertiesLayout().getChildren().clear();
        getFullPropertiesLayout().getChildren().clear();
        getFullPropertiesLayout().getRowConstraints().clear();
    }

    /**
     * Displays the properties for the provided object details.
     *
     * @param details object details
     */
    public final void displayProperties(final Details details) {
        /* First reset the layout */
        clearLayout();

        /* Get the full properties of the window/scene/node */
        final Map<String, PropertyDetails> props = details.getFullProperties();

        /* Display all important/special properties in the node details section */
        final AtomicInteger nodeDetailsRowIndex = new AtomicInteger();
        Stream.of(HIGHLIGHT_PROPS, NODE_PROPS).flatMap(List::stream).forEach(prop -> {
            final PropertyDetails propertyDetails = props.get(prop);
            if (propertyDetails != null) {
                final int rowIndex = nodeDetailsRowIndex.getAndIncrement();
                addOrUpdatePropertyRow(getNodeDetailsLayout(), nodeProperties, rowIndex, propertyDetails);
            }
        });

        final PropertyDetails bgPropDetails = props.get("background");
        if (bgPropDetails != null) {
            addOrUpdatePropertyRow(getBackgroundPropertiesLayout(), fullProperties, 0, bgPropDetails);
        }

        final PropertyDetails borderPropDetails = props.get("border");
        if (borderPropDetails != null) {
            addOrUpdatePropertyRow(getBorderPropertiesLayout(), fullProperties, 0, borderPropDetails);
        }
        detailsController.getBackgroundTP().setVisible(bgPropDetails != null || borderPropDetails != null);

        /* Display all properties in the full properties section */
        final AtomicInteger fullPropsRowIndex = new AtomicInteger();
        details.getFullProperties().keySet().stream().sorted()
            .filter(propName -> !propName.equals("border") && !propName.equals("background"))
            .forEach((propName) -> {
                final PropertyDetails propDetails = details.getFullProperties().get(propName);
                final int rowIndex = fullPropsRowIndex.getAndIncrement();
                addOrUpdatePropertyRow(getFullPropertiesLayout(), fullProperties, rowIndex, propDetails);
            });
    }

    /**
     * Gets the layout to display the background properties details titledPane.
     *
     * @return GridPane
     */
    public final GridPane getBackgroundPropertiesLayout() {
        if (backgroundPropertiesLayout == null) {
            backgroundPropertiesLayout = buildPropertiesLayout();
        }
        return backgroundPropertiesLayout;
    }

    /**
     * Gets the layout to display the border properties details titledPane.
     *
     * @return GridPane
     */
    public final GridPane getBorderPropertiesLayout() {
        if (borderPropertiesLayout == null) {
            borderPropertiesLayout = buildPropertiesLayout();
        }
        return borderPropertiesLayout;
    }

    /**
     * Gets the layout to display the full properties details titledPane.
     *
     * @return GridPane
     */
    public final GridPane getFullPropertiesLayout() {
        if (fullPropertiesLayout == null) {
            fullPropertiesLayout = buildPropertiesLayout();
        }
        return fullPropertiesLayout;
    }

    /**
     * Gets the layout to display the node details titledPane.
     *
     * @return GridPane
     */
    public final GridPane getNodeDetailsLayout() {
        if (nodeDetailsLayout == null) {
            nodeDetailsLayout = buildPropertiesLayout();
        }
        return nodeDetailsLayout;
    }

    /**
     * Updates the provided property details.
     *
     * @param propertyDetails property details
     */
    public final void updateProperty(final PropertyDetails propertyDetails) {
        Platform.runLater(() -> {
            addOrUpdatePropertyRow(getNodeDetailsLayout(), nodeProperties, -1, propertyDetails);
            addOrUpdatePropertyRow(getFullPropertiesLayout(), fullProperties, -1, propertyDetails);
        });
    }

    /**
     * Adds or updates the property row in the provided grid layout.
     *
     * @param layout grid layout
     * @param propertiesNodeMap properties details
     * @param rowIndex row index
     * @param propertyDetails property details
     */
    private void addOrUpdatePropertyRow(final GridPane layout,
            final Map<String, Pair<Label, ValueNode>> propertiesNodeMap, final int rowIndex,
            final PropertyDetails propertyDetails) {
        /* Get the label-node pair of the property for the layout. If it doesn't exist it will create one. */
        final Pair<Label, ValueNode> labelValueNodePair =
                propertiesNodeMap.computeIfAbsent(propertyDetails.getName(), name -> {
                    final Label propLabel = buildPropLabel(name);
                    final ValueNode propValue = buildValueNode(propertyDetails);
                    /* Highlight the important properties in the full list */
                    if (HIGHLIGHT_PROPS.contains(name) && propertiesNodeMap == fullProperties) {
                        propValue.highlight();
                    }
                    return new Pair<>(propLabel, propValue);
                });

        final Label propLabel = labelValueNodePair.getKey();
        ValueNode valueNode = labelValueNodePair.getValue();

        /*
         * If the value is updated from null to valid value, we replace the value node as well. After this
         * valueNode of the property will not change.
         */
        if (valueNode instanceof NullValueNode && propertyDetails.getType() != ValueType.NULL) {
            valueNode = buildValueNode(propertyDetails);
            propertiesNodeMap.put(propertyDetails.getName(), new Pair<>(propLabel, valueNode));
        }

        /* Update the value in the value node */
        valueNode.setValue(propertyDetails);

        /* Let's include some visual difference to properties with null value */
        propLabel.pseudoClassStateChanged(NULL_PSEUDOCLASS, valueNode instanceof NullValueNode);

        /* If rowIndex exists, it means the property is added to layout. */
        if (rowIndex > -1) {
            layout.addRow(rowIndex, propLabel, valueNode.getNode());
            layout.getRowConstraints().add(propRowConstraint);
        }
    }

    /**
     * Builds the layout template that will be displayed in different TitlePanes. This will ensure that the layout
     * is aligned correctly in different titledPanes.
     *
     * @return GridPane template
     */
    private GridPane buildBaseLayout() {
        final GridPane basePane = new GridPane();
        basePane.setPadding(new Insets(8));
        basePane.setVgap(5);
        basePane.setHgap(8);
        return basePane;
    }

    /**
     * Builds the properties layout template that will be displayed in different TitlePanes. This will ensure that
     * the layout is aligned correctly in different titledPanes.
     *
     * @return GridPane template
     */
    private GridPane buildPropertiesLayout() {
        final GridPane propertiesPane = buildBaseLayout();
        final ColumnConstraints c = new ColumnConstraints();
        c.setMinWidth(200);
        c.setMaxWidth(200);
        c.setHalignment(HPos.RIGHT);
        propertiesPane.getColumnConstraints().add(c);
        return propertiesPane;
    }
}
