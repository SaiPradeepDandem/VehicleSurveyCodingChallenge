package com.sai.javafx.fxplorer.connector;

import java.rmi.Remote;
import java.rmi.RemoteException;

import com.sai.javafx.fxplorer.data.NodeDetails;
import com.sai.javafx.fxplorer.data.PropertyDetails;
import com.sai.javafx.fxplorer.data.WindowDetails;

/**
 * Interface for communication to the Fxplorer from the remote application.
 */
public interface IFxplorer extends Remote {

    /**
     * Specifies that the application is closed.
     *
     * @throws RemoteException
     */
    void close() throws RemoteException;

    /**
     * Dispatches the node details when a child node is added or deleted.
     *
     * @param appId application id
     * @param windowId window id
     * @param nodeDetails child node details
     * @throws RemoteException
     */
    void dispatchChildrenUpdate(int appId, int windowId, NodeDetails nodeDetails) throws RemoteException;

    /**
     * Dispatches the property details of a node/scene/window.
     *
     * @param appId application id
     * @param windowId window id
     * @param ownerId id of a node/scene/window
     * @param propDetails property details
     * @throws RemoteException
     */
    void dispatchPropertyDetail(int appId, int windowId, int ownerId, PropertyDetails propDetails)
            throws RemoteException;

    /**
     * Dispatch the window details.
     *
     * @param appId application id
     * @param windowDetails window details
     * @throws RemoteException
     */
    void dispatchWindow(int appId, WindowDetails windowDetails) throws RemoteException;

    /**
     * Specifies the fxplorer that the remote agent is started.
     *
     * @param port port of the remote application
     * @param appID id of the remote application
     * @throws RemoteException
     */
    void onAgentStarted(int port, int appID) throws RemoteException;

    /**
     * Specifies the fxplorer to select the given node in the tree.
     *
     * @param appId application id
     * @param windowId window id
     * @param nodeId node id
     * @throws RemoteException
     */
    void selectNode(int appId, int windowId, int nodeId) throws RemoteException;
}
